const express = require('express');
const router = express.Router();
const User = require('../models/User');
const GameRule = require('../models/rulemodel');

router.get('/game-rules/:userId/:gameSlug', async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ 
                success: false,
                message: 'User not found' 
            });
        }

        const gameRule = await GameRule.findOne({ 
            game_slug: req.params.gameSlug 
        });

        if (!gameRule) {
            return res.status(404).json({ 
                success: false,
                message: 'Game rules not found for the specified slug' 
            });
        }

        res.json({ 
            success: true,
            data: gameRule 
        });

    } catch (error) {
        console.error('Error fetching game rules:', error);
        res.status(500).json({ 
            success: false,
            message: 'Server error',
            error: error.message 
        });
    }
});

module.exports = router;