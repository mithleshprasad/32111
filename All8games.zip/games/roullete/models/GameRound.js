const mongoose = require('mongoose');

const GameRoundSchema = new mongoose.Schema({
  roundNumber: {
    type: Number,
    required: true,
    unique: true,
  },
  status: {
    type: String,
    enum: ['accepting_bets', 'no_more_bets', 'result'],
    default: 'accepting_bets',
  },
  bettingEndTime: Date,
  bets: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'RouletteBet',
  }],
  winningNumber: {
    type: Number,
    min: 0,
    max: 36,
  },
  winningColor: {
    type: String,
    enum: ['red', 'black', 'green'],
  },
  resultTime: Date,
}, { timestamps: true });

module.exports = mongoose.model('RouletteGameRound', GameRoundSchema);