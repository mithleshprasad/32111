const mongoose = require('mongoose');

const BetSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  gameRoundId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'RouletteGameRound',
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  type: {
    type: String,
    enum: ['number', 'color', 'oddeven'],
    required: true,
  },
  selectedNumber: {
    type: Number,
    min: 0,
    max: 36,
  },
  selectedColor: {
    type: String,
    enum: ['red', 'black'],
  },
  selectedOddEven: {
    type: String,
    enum: ['odd', 'even'],
  },
  odds: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
    enum: ['pending', 'won', 'lost'],
    default: 'pending',
  },
  payout: {
    type: Number,
    default: 0,
  },
}, { timestamps: true });

module.exports = mongoose.model('RouletteBet', BetSchema);