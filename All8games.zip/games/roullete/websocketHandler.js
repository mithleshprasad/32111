const GameRound = require('./models/GameRound');
const Bet = require('./models/Bet');
const User = require('../../models/User');
const WebSocket = require('ws');
let activeConnections = 0;
let gamesInitialized = false;
function setupWebSocket(wss, game = 'roullete') {
  wss.on('connection', (ws) => {
    activeConnections++;
    if (activeConnections > 0 && !gamesInitialized) {
      gamesInitialized = true;
    }
    broadcastActiveCount(wss, game);
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message);
        if (data.game !== game || data.type !== 'placeBet') return;

        const round = await GameRound.findOne({ status: 'accepting_bets' }).sort({ createdAt: -1 });
        if (!round) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'No active betting round',
          }));
        }
        const user = await User.findById(data.userId);
        if (!user) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'User not found',
          }));
        }
        if (data.amount > user.balance) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'Insufficient balance',
          }));
        }
        if (![1, 2].includes(data.selectedPlayer)) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'Invalid player selected',
          }));
        }
        user.balance -= data.amount;
        await user.save();

        const bet = new Bet({
          userId: data.userId,
          gameRoundId: round._id,
          amount: data.amount,
          type: 'player',
          selectedPlayer: data.selectedPlayer,
          odds: 1,
        });
        await bet.save();
        // round.bets.push(bet._id);
        // await round.save();

        ws.send(JSON.stringify({
          game,
          type: 'betPlaced',
          betId: bet._id,
          roundNumber: round.roundNumber,
          selectedPlayer: data.selectedPlayer,
          amount: data.amount,
        }));
      } catch (error) {
        console.error(`Error handling ${game} WebSocket message:`, error);
        ws.send(JSON.stringify({
          game,
          type: 'error',
          message: error.message,
        }));
      }
    });

    ws.on('close', () => {
      activeConnections--;
      console.log(`Connection closed. Active connections: ${activeConnections}`);

      if (activeConnections === 0) {
        gamesInitialized = false;
      }
      broadcastActiveCount(wss, game);

    });
  });
}
function broadcastActiveCount(wss, game) {
  const message = JSON.stringify({
    game,
    type: 'activeUsers',
    count: activeConnections
  });

  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}
module.exports = { setupWebSocket };