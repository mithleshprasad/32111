const GameRound = require('./models/GameRound');
const Bet = require('./models/Bet');
const User = require('../../models/User');
const WebSocket = require('ws');

// Roulette wheel: European (0-36), with red/black colors
const rouletteWheel = [
  { number: 0, color: 'green' },
  { number: 1, color: 'red' },
  { number: 2, color: 'black' },
  { number: 3, color: 'red' },
  { number: 4, color: 'black' },
  { number: 5, color: 'red' },
  { number: 6, color: 'black' },
  { number: 7, color: 'red' },
  { number: 8, color: 'black' },
  { number: 9, color: 'red' },
  { number: 10, color: 'black' },
  { number: 11, color: 'black' },
  { number: 12, color: 'red' },
  { number: 13, color: 'black' },
  { number: 14, color: 'red' },
  { number: 15, color: 'black' },
  { number: 16, color: 'red' },
  { number: 17, color: 'black' },
  { number: 18, color: 'red' },
  { number: 19, color: 'red' },
  { number: 20, color: 'black' },
  { number: 21, color: 'red' },
  { number: 22, color: 'black' },
  { number: 23, color: 'red' },
  { number: 24, color: 'black' },
  { number: 25, color: 'red' },
  { number: 26, color: 'black' },
  { number: 27, color: 'red' },
  { number: 28, color: 'black' },
  { number: 29, color: 'black' },
  { number: 30, color: 'red' },
  { number: 31, color: 'black' },
  { number: 32, color: 'red' },
  { number: 33, color: 'black' },
  { number: 34, color: 'red' },
  { number: 35, color: 'black' },
  { number: 36, color: 'red' },
];

function broadcast(wss, message, game = 'roulette') {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ ...message, game }));
    }
  });
}

async function processBets(roundId, winningNumberObj) {
  try {
    const bets = await Bet.find({ gameRoundId: roundId, status: 'pending' });
    for (const bet of bets) {
      let payout = 0;
      if (bet.type === 'number' && bet.selectedNumber === winningNumberObj.number) {
        payout = bet.amount * 35; // 35:1 for straight-up number bet
        bet.payout = payout;
        bet.status = 'won';
        await User.findByIdAndUpdate(bet.userId, { $inc: { balance: payout + bet.amount } });
        console.log(`Roulette Bet ${bet._id} won: Number ${bet.selectedNumber}, payout: ${payout}`);
      } else if (bet.type === 'color' && bet.selectedColor === winningNumberObj.color) {
        payout = bet.amount * 1; // 1:1 for color bet
        bet.payout = payout;
        bet.status = 'won';
        await User.findByIdAndUpdate(bet.userId, { $inc: { balance: payout + bet.amount } });
        console.log(`Roulette Bet ${bet._id} won: Color ${bet.selectedColor}, payout: ${payout}`);
      } else if (bet.type === 'oddeven' && bet.selectedOddEven === (winningNumberObj.number === 0 ? null : winningNumberObj.number % 2 === 0 ? 'even' : 'odd')) {
        payout = bet.amount * 1; // 1:1 for odd/even bet
        bet.payout = payout;
        bet.status = 'won';
        await User.findByIdAndUpdate(bet.userId, { $inc: { balance: payout + bet.amount } });
        console.log(`Roulette Bet ${bet._id} won: Odd/Even ${bet.selectedOddEven}, payout: ${payout}`);
      } else {
        bet.payout = 0;
        bet.status = 'lost';
        console.log(`Roulette Bet ${bet._id} lost: ${bet.type}`);
      }
      await bet.save();
    }
  } catch (error) {
    console.error('Error processing roulette bets:', error);
  }
}

async function startNewRound(wss) {
  try {
    const lastRound = await GameRound.findOne().sort({ roundNumber: -1 });
    const roundNumber = lastRound ? lastRound.roundNumber + 1 : 1;

    const currentRound = new GameRound({
      roundNumber,
      status: 'accepting_bets',
      bettingEndTime: new Date(Date.now() + 30000),
    });
    await currentRound.save();
    console.log(`Starting new roulette round: ${roundNumber}`);

    broadcast(wss, {
      type: 'newRound',
      roundNumber: currentRound.roundNumber,
      status: currentRound.status,
      bettingEndTime: currentRound.bettingEndTime,
    });

    setTimeout(async () => {
      currentRound.status = 'no_more_bets';
      await currentRound.save();

      broadcast(wss, {
        type: 'bettingClosed',
        roundNumber: currentRound.roundNumber,
      });

      // Simulate roulette wheel spin
      const winningNumberObj = rouletteWheel[Math.floor(Math.random() * rouletteWheel.length)];

      currentRound.status = 'result';
      currentRound.winningNumber = winningNumberObj.number;
      currentRound.winningColor = winningNumberObj.color;
      currentRound.resultTime = new Date();
      await currentRound.save();

      await processBets(currentRound._id, winningNumberObj);

      broadcast(wss, {
        type: 'roundResult',
        roundNumber: currentRound.roundNumber,
        winningNumber: winningNumberObj.number,
        winningColor: winningNumberObj.color,
        resultTime: currentRound.resultTime,
      });

      setTimeout(() => startNewRound(wss), 10000);
    }, 30000);
  } catch (error) {
    console.error(`Error in roulette round ${roundNumber}:`, error);
    broadcast(wss, {
      type: 'error',
      message: 'Error in game round',
    });
    setTimeout(() => startNewRound(wss), 5000);
  }
}

module.exports = { startNewRound, processBets, broadcast };