
const GameRound = require('./models/GameRound');
const Bet = require('./models/Bet');
const User = require('../../models/User');
const { cardValues, resetDeck, getDeck } = require('./deck');
const WebSocket = require('ws');

function broadcast(wss, message, game = 'chickenroad') {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ ...message, game }));
    }
  });
}

function evaluateHand(cards) {
  const values = cards.map(card => cardValues[card.value]).sort((a, b) => b - a);
  const suits = cards.map(card => card.suit);
  const isSameSuit = suits.every(suit => suit === suits[0]);
  const isSequence = values[0] - values[2] === 2 && values[1] === values[0] - 1;
  const isPureSequence = isSequence && isSameSuit;
  const isPair = values[0] === values[1] || values[1] === values[2];
  const isTrail = values[0] === values[1] && values[1] === values[2];

  if (isTrail) return { rank: 'Trail', highCard: values[0] };
  if (isPureSequence) return { rank: 'Pure Sequence', highCard: values[0] };
  if (isSequence) return { rank: 'Sequence', highCard: values[0] };
  if (isSameSuit) return { rank: 'Color', highCard: values[0] };
  if (isPair) return { rank: 'Pair', highCard: Math.max(...values.filter((v, i, arr) => arr.indexOf(v) !== arr.lastIndexOf(v))) };
  return { rank: 'High Card', highCard: values[0] };
}

function compareHands(hand1, hand2) {
  const rankOrder = ['Trail', 'Pure Sequence', 'Sequence', 'Color', 'Pair', 'High Card'];
  const rank1 = rankOrder.indexOf(hand1.rank);
  const rank2 = rankOrder.indexOf(hand2.rank);
  if (rank1 !== rank2) return rank1 - rank2;
  return hand2.highCard - hand1.highCard;
}

async function processBets(roundId, winningPlayer) {
  try {
    const bets = await Bet.find({ gameRoundId: roundId, status: 'pending' });
    for (const bet of bets) {
      if (bet.selectedPlayer === winningPlayer) {
        const payout = bet.amount * (bet.odds + 1);
        bet.payout = payout;
        bet.status = 'won';
        await User.findByIdAndUpdate(bet.userId, { $inc: { balance: payout } });
        console.log(`chickenroad Bet ${bet._id} won: Player ${bet.selectedPlayer}, payout: ${payout}`);
      } else {
        bet.payout = 0;
        bet.status = 'lost';
        console.log(`chickenroad Bet ${bet._id} lost: Player ${bet.selectedPlayer}`);
      }
      await bet.save();
    }
  } catch (error) {
    console.error('Error processing chickenroad bets:', error);
  }
}

async function startNewRound(wss) {
  try {
    const lastRound = await GameRound.findOne().sort({ roundNumber: -1 });
    const roundNumber = lastRound ? lastRound.roundNumber + 1 : 1;

    resetDeck();
    const currentRound = new GameRound({
      roundNumber,
      status: 'accepting_bets',
      bettingEndTime: new Date(Date.now() + 30000),
    });
    await currentRound.save();
    console.log(`Starting new chickenroad round: ${roundNumber}`);
    console.log(`Starting  ${wss.clients.size}`);

    broadcast(wss, {
      type: 'newRound',
      roundNumber: currentRound.roundNumber,
      status: currentRound.status,
      bettingEndTime: currentRound.bettingEndTime,

    });

    setTimeout(async () => {
      currentRound.status = 'no_more_bets';
      await currentRound.save();

      broadcast(wss, {
        type: 'bettingClosed',
        roundNumber: currentRound.roundNumber,
      });

      const deck = getDeck();
      const playerCards = {
        1: deck.splice(0, 3), // Player A
        2: deck.splice(0, 3), // Player B
      };

      const playerHands = {};
      for (const [playerNum, cards] of Object.entries(playerCards)) {
        const hand = evaluateHand(cards);
        playerHands[playerNum] = { cards, hand };
      }

      currentRound.status = 'dealing';
      currentRound.cards = Object.entries(playerCards).map(([playerNum, cards]) => ({
        player: parseInt(playerNum),
        cards,
        handRank: playerHands[playerNum].hand.rank,
        highCard: playerHands[playerNum].hand.highCard,
      }));
      await currentRound.save();

      broadcast(wss, {
        type: 'cardsDealt',
        roundNumber: currentRound.roundNumber,
        cards: currentRound.cards,
      });

      setTimeout(async () => {
        let winner = null;
        let bestHand = null;
        for (const [playerNum, handData] of Object.entries(playerHands)) {
          if (!bestHand || compareHands(bestHand, handData.hand) > 0) {
            bestHand = handData.hand;
            winner = parseInt(playerNum);
          }
        }

        currentRound.status = 'result';
        currentRound.winner = winner;
        currentRound.resultTime = new Date();
        await currentRound.save();

        await processBets(currentRound._id, winner);

        broadcast(wss, {
          type: 'roundResult',
          roundNumber: currentRound.roundNumber,
          winner,
          cards: currentRound.cards,
          resultTime: currentRound.resultTime,
        });
      

          setTimeout(() => startNewRound(wss), 10000);
      }, 5000);
    }, 30000);
  } catch (error) {
    console.error(`Error in chickenroad round ${roundNumber}:`, error);
    broadcast(wss, {
      type: 'error',
      message: 'Error in game round',
    });
    setTimeout(() => startNewRound(wss), 5000);
  }
}

module.exports = { startNewRound, processBets, broadcast };