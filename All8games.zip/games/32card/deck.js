const cardValues = {
  '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14,
};
const suits = ['S', 'H', 'D', 'C'];
const values = ['7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

let deck = [];

function resetDeck() {
  deck = [];
  for (const suit of suits) {
    for (const value of values) {
      deck.push({ value, suit });
    }
  }
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

module.exports = { cardValues, suits, values, resetDeck, getDeck: () => deck };