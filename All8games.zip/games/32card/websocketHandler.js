const GameRound = require('./models/GameRound');
const Bet = require('./models/Bet');
const User = require('../../models/User');

function setupWebSocket(wss, game = '32card') {
  wss.on('connection', (ws) => {
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message);
        if (data.game !== game || data.type !== 'placeBet') return;

        const round = await GameRound.findOne({ status: 'accepting_bets' }).sort({ createdAt: -1 });
        if (!round) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'No active betting round',
          }));
        }
        const user = await User.findById(data.userId);
        if (!user) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'User not found',
          }));
        }
        if (data.amount > user.balance) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'Insufficient balance',
          }));
        }
        if (![8, 9, 10, 11].includes(data.selectedPlayer)) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'Invalid player selected',
          }));
        }
        user.balance -= data.amount;
        await user.save();

        const bet = new Bet({
          userId: data.userId,
          gameRoundId: round._id,
          amount: data.amount,
          type: 'player',
          selectedPlayer: data.selectedPlayer,
          odds: 1,
        });
        await bet.save();
        round.bets.push(bet._id);
        await round.save();

        ws.send(JSON.stringify({
          game,
          type: 'betPlaced',
          betId: bet._id,
          roundNumber: round.roundNumber,
          selectedPlayer: data.selectedPlayer,
          amount: data.amount,
        }));
      } catch (error) {
        console.error(`Error handling ${game} WebSocket message:`, error);
        ws.send(JSON.stringify({
          game,
          type: 'error',
          message: error.message,
        }));
      }
    });
  });
}

module.exports = { setupWebSocket };