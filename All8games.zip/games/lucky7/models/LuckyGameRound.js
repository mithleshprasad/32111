const mongoose = require('mongoose');

const LuckyGameRoundSchema = new mongoose.Schema({
  roundNumber: {
    type: Number,
    required: true,
    unique: true,
  },
  status: {
    type: String,
    enum: ['accepting_bets', 'no_more_bets', 'dealing', 'result'],
    default: 'accepting_bets',
  },
  bettingEndTime: Date,
  cards: [{
    value: String,
    suit: String,
  }],
  total: Number,
  result: String,
  winnerAnnouncedTime: Date,
}, { timestamps: true });

module.exports = mongoose.model('LuckyGameRound', LuckyGameRoundSchema);