const mongoose = require('mongoose');

const GameRoundSchema = new mongoose.Schema({
  roundNumber: {
    type: Number,
    required: true,
    unique: true,
  },
  status: {
    type: String,
    enum: ['accepting_bets', 'no_more_bets', 'dealing', 'result'],
    default: 'accepting_bets',
  },
  bettingEndTime: Date,
  bets: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bet',
  }],
  cards: [{
    player: Number,
    cards: [{ value: String, suit: String }],
    handRank: String,
    highCard: Number,
  }],
  winner: Number,
  resultTime: Date,
}, { timestamps: true });

module.exports = mongoose.model('MuflisGameRound', GameRoundSchema);