const GameRound = require('./models/GameRound');
const Bet = require('./models/Bet');
const User = require('../../models/User');

function setupWebSocket(wss, game = 'dragontiger') {
  wss.on('connection', (ws) => {
    console.log(`New client connected to ${game}`);
    ws.send(JSON.stringify({
      game,
      type: 'connection',
      message: `Welcome to Dragon Tiger WebSocket Server`,
    }));

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message);
        if (data.game !== game || data.type !== 'placeBet') return;

        const round = await GameRound.findOne({ status: 'accepting_bets' }).sort({ createdAt: -1 });
        if (!round) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'No active betting round',
          }));
        }
        const user = await User.findById(data.userId);
        if (!user) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'User not found',
          }));
        }
        if (data.amount > user.balance || data.amount < 10) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: data.amount < 10 ? 'Minimum bet is 10' : 'Insufficient balance',
          }));
        }
        const validBetTypes = ['dragon', 'tiger', 'tie'];
        if (!validBetTypes.includes(data.betType.toLowerCase())) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'Invalid bet type',
          }));
        }
        user.balance -= data.amount;
        await user.save();

        const odds = data.betType.toLowerCase() === 'tie' ? 8 : 1;
        const bet = new Bet({
          userId: data.userId,
          gameRoundId: round._id,
          roundNumber: round.roundNumber,
          amount: data.amount,
          betType: data.betType.toLowerCase(),
          odds,
          status: 'pending',
        });
        await bet.save();

        ws.send(JSON.stringify({
          game,
          type: 'betPlaced',
          betId: bet._id,
          roundNumber: round.roundNumber,
          amount: data.amount,
          betType: data.betType,
        }));
      } catch (error) {
        console.error(`Error handling ${game} WebSocket message:`, error);
        ws.send(JSON.stringify({
          game,
          type: 'error',
          message: error.message,
        }));
      }
    });
  });
}

module.exports = { setupWebSocket };