const User = require('../models/User');
const Bet = require('../models/Bet');
const GameRound = require('../models/GameRound');

// Get all users
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find({}, '-password'); // Exclude password from response
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get user details by ID
exports.getUserDetails = async (req, res) => {
  const { userId } = req.params;
  try {
    const user = await User.findById(userId).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update user status
exports.updateUserStatus = async (req, res) => {
  const { userId } = req.params;
  const { user_status } = req.body; // 1 for active, 0 for inactive
  try {
    const user = await User.findByIdAndUpdate(userId, { user_status }, { new: true });
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.status(200).json({ message: 'User status updated', user });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Delete user
exports.deleteUser = async (req, res) => {
  const { userId } = req.params;
  try {
    const user = await User.findByIdAndDelete(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.status(200).json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get all bets
exports.getAllBets = async (req, res) => {
  try {
    const bets = await Bet.find({}).populate('userId', 'name email');
    res.status(200).json(bets);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get bet details by ID
exports.getBetDetails = async (req, res) => {
  const { betId } = req.params;
  try {
    const bet = await Bet.findById(betId).populate('userId', 'name email');
    if (!bet) return res.status(404).json({ message: 'Bet not found' });
    res.status(200).json(bet);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update bet status
exports.updateBetStatus = async (req, res) => {
  const { betId } = req.params;
  const { betStatus } = req.body; // 'active', 'canceled', 'cashed out'
  try {
    const bet = await Bet.findByIdAndUpdate(betId, { betStatus }, { new: true });
    if (!bet) return res.status(404).json({ message: 'Bet not found' });
    res.status(200).json({ message: 'Bet status updated', bet });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get all game rounds
exports.getAllGameRounds = async (req, res) => {
  try {
    const rounds = await GameRound.find({});
    res.status(200).json(rounds);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get game round details by ID
exports.getGameRoundDetails = async (req, res) => {
  const { roundId } = req.params;
  try {
    const round = await GameRound.findById(roundId);
    if (!round) return res.status(404).json({ message: 'Game round not found' });
    res.status(200).json(round);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update game round status
exports.updateGameRoundStatus = async (req, res) => {
  const { roundId } = req.params;
  const { roundStatus } = req.body; // 'active', 'start', 'crashed'
  try {
    const round = await GameRound.findByIdAndUpdate(roundId, { roundStatus }, { new: true });
    if (!round) return res.status(404).json({ message: 'Game round not found' });
    res.status(200).json({ message: 'Game round status updated', round });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.getSystemStats = async (req, res) => {
    try {
      const userCount = await User.countDocuments({});
      const activeUserCount = await User.countDocuments({ user_status: 1 }); // Count active users
      const betCount = await Bet.countDocuments({});
      const activeBetCount = await Bet.countDocuments({ betStatus: 'active' }); // Count active bets
      const roundCount = await GameRound.countDocuments({});
      const activeRoundCount = await GameRound.countDocuments({ roundStatus: 'active' }); // Count active rounds
  
      res.status(200).json({
        userCount,
        activeUserCount,
        betCount,
        activeBetCount,
        roundCount,
        activeRoundCount
      });
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  };
  
// Fetch active users
exports.getActiveUsers = async (req, res) => {
    try {
      const activeUsers = await User.find({ user_status: 1 });
      res.status(200).json(activeUsers);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  };
  
  // Fetch inactive users
  exports.getInactiveUsers = async (req, res) => {
    try {
      const inactiveUsers = await User.find({ user_status: { $ne: 1 } });
      res.status(200).json(inactiveUsers);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  };
  
  // Fetch active bets
  exports.getActiveBets = async (req, res) => {
    try {
      const activeBets = await Bet.find({ betStatus: 'active' });
      res.status(200).json(activeBets);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  };
  
  // Fetch inactive bets
  exports.getInactiveBets = async (req, res) => {
    try {
      const inactiveBets = await Bet.find({ betStatus: { $ne: 'active' } });
      res.status(200).json(inactiveBets);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  };
  
  // Fetch active game rounds
  exports.getActiveGameRounds = async (req, res) => {
    try {
      const activeGameRounds = await GameRound.find({ roundStatus: 'active' });
      res.status(200).json(activeGameRounds);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  };
  
  // Fetch inactive game rounds
  exports.getInactiveGameRounds = async (req, res) => {
    try {
      const inactiveGameRounds = await GameRound.find({ roundStatus: { $ne: 'active' } });
      res.status(200).json(inactiveGameRounds);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  };
  