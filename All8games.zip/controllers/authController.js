const User = require('../models/User');
const jwt = require('jsonwebtoken');

exports.signup = async (req, res) => {
  const { name, email, password, mobile, role = 'user' } = req.body;

  if (!name) {
    return res.status(400).json({ message: 'Name are required' });
  }
  if (!email) {
    return res.status(400).json({ message: 'email are required' });
  }
  if (!password) {
    return res.status(400).json({ message: 'password are required' });
  }
  if (!mobile) {
    return res.status(400).json({ message: 'Mobile Number are required' });
  }
  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already in use' });
    }


    const user = new User({ name, email, password, mobile });
    await user.save();

    res.status(201).json({ message: 'User created successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};




exports.login = async (req, res) => {
  try {
    const { email, Password } = req.body;
    
    // Basic validation
    if (!email || !Password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    // Find admin and compare plain text password
    const admin = await User.findOne({ email });
    
    if (!admin || admin.Password !== Password) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate simple token
    const token = jwt.sign({ id: admin._id }, 'your-secret-key', { expiresIn: '1h' });

    res.json({ token, userId: admin._id });
    
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};
exports.getUserProfile = async (req, res) => {
  const { userId } = req.body;
  if (!userId) {
    return res.status(400).json({ message: 'userId are required' });
  }
  try {
    const user = await User.findById(userId).select('-Password');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    return res.status(200).json({
      success: true,
      user
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Error retrieving user profile', error: error.message });
  }
};