import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react';
import { IoMdAdd } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEdit } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';
const AddSupSubCat = () => {
  const [gameSubCategory, setGameSubCategory] = useState([]);
  const [loading, setLoading] = useState(false);
  const user_id = localStorage.getItem("user_id");
  const isLoading = useRef(false); 
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const cat_slug = localStorage.getItem("Category_slug");
  const sub_cat_slug = localStorage.getItem("subcat_slug");

  const fetchGameSupSubCategory = async () => {
    try {
      setLoading(true);

      const url = `https://apicolorgame.a2logicgroup.com/api/admin/game-super-sub-category-list`;

      const response = await axios.post(url, { user_id});

      if (response.data?.success && Array.isArray(response.data.data)) {
        setGameSubCategory(response.data.data);
        console.log("Fetched data:", response.data.data);
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error fetching data:", error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGameSupSubCategory();
  }, []);

  const fetchDelete = async (slug) => {
    try {
      isLoading.current = true;
      setLoading(true);
  
      const url = `https://apicolorgame.a2logicgroup.com/api/admin/delete-Supsubcategory/${slug}`;
  
      const config = {
        method: "POST", 
        url: url,
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          user_id: user_id, 
        },
      };
  
      const response = await axios(config);
  
      if (response.data?.success === true) {  
        setMessage(response.data.message);
        alert(response.data.message);
        fetchGameSupSubCategory();  
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error fetching data:", error.message);
    } finally {
      setLoading(false);  
      isLoading.current = false;
    }
  };
  
  const handleEdit = (slug) => {
    navigate(`/UpdateSupSubCat/${slug}`);
  };

  return (
    <>
      <CRow>
        <CCol xs>
          <CCard className="mb-4">
            <CCardBody>
              <h4 className="d-inline">Sub Category List</h4>
              <Link to="/AddSupSubCategory">
                <CButton color="primary" className="float-end">
                  <IoMdAdd className="me-2" />
                  Add Super Sub Category
                </CButton>
              </Link>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
      
      <CRow>
        <CCol xs>
          <CCard className="mb-4">
            <CCardBody>
              <CTable align="middle" className="mb-0 border" hover responsive>
                <CTableHead className="text-nowrap">
                  <CTableRow>
                    <CTableHeaderCell className="text-center">Type Name</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">Bet Multiple</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">IntervalM</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">Scope</CTableHeaderCell>
                    {/* <CTableHeaderCell className="text-center">Slug</CTableHeaderCell> */}
                    <CTableHeaderCell className="text-center">TypeID</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">Status</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">Actions</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                
                <CTableBody>
                  {gameSubCategory.map((item, index) => (
                    <CTableRow key={index}>
                      {/* Type Name */}
                      <CTableDataCell className="text-center">{item.typeName}</CTableDataCell>
                      {/* Bet Multiple */}
                      <CTableDataCell className="text-center">{item.betMultiple}</CTableDataCell>
                      {/* IntervalM */}
                      <CTableDataCell className="text-center">{item.intervalM}</CTableDataCell>
                      {/* Scope */}
                      <CTableDataCell className="text-center">{item.scope}</CTableDataCell>
                      {/* Slug */}
                      {/* <CTableDataCell className="text-center">{item.slug}</CTableDataCell> */}
                      {/* TypeID */}
                      <CTableDataCell className="text-center">{item.typeID}</CTableDataCell>
                      {/* Status */}
                      <CTableDataCell className="text-center">
                        <span style={{ color: item.status === "1" ? "green" : "red" }}>
                          {item.status === "1" ? "Active" : "Inactive"}
                        </span>
                      </CTableDataCell>
                      
                      {/* Actions */}
                      <CTableDataCell className="text-center">
                        <CButton color="warning" size="sm" 
                        className="me-2 text-white"
                        onClick={() => handleEdit(item.slug)}
                        >
                          <FaEdit />
                        </CButton>
                        <CButton 
                          color="danger" 
                          size="sm" 
                          className="me-2 text-white"
                          onClick={() => fetchDelete(item.slug)}  
                        >
                          <RiDeleteBin6Line />
                        </CButton>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  );
};

export default AddSupSubCat;
