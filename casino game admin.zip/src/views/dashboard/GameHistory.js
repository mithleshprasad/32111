import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { CButton, CCard, CCardBody, CCol, CRow, CTable, CTableBody, CTableDataCell, CTableHead, CTableHeaderCell, CTableRow } from '@coreui/react';
import { RiArrowRightSLine, RiArrowLeftSLine } from "react-icons/ri";
import { CBadge } from '@coreui/react';

const GameRounds = () => {
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const game = queryParams.get('game');
    const [roundsData, setRoundsData] = useState({ rounds: [], total: 0 });
    const [loading, setLoading] = useState(false);
    const userId = localStorage.getItem("userId");

    // Pagination State
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    useEffect(() => {
        fetchGameRounds();
    }, [game, currentPage]);

    const fetchGameRounds = async () => {
        console.log("Fetching game rounds for game:", itemsPerPage, "on page:", currentPage);
        try {
            setLoading(true);
            const url = `http://localhost:5000/api/admin/game-rounds/${game}`;
            const response = await axios.post(url, {

                page: currentPage,
                limit: itemsPerPage,
                userId: userId

            });

            console.log("Game Rounds Response:", response.data);

            if (response.data) {
                setRoundsData({
                    rounds: response.data.rounds || [],
                    total: response.data.totalRounds || 0
                });
            }
        } catch (error) {
            console.error("Error fetching game rounds:", error.message);
        } finally {
            setLoading(false);
        }
    };

    // Format date to display
    const formatDate = (dateString) => {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        return new Date(dateString).toLocaleDateString(undefined, options);
    };

    // Determine the result of the round
    const getRoundResult = (round) => {
        if (!round.winningPosition) return "Pending";
        return round.winningPosition === "andar" ? "Andar" : "Bahar";
    };

    // Pagination Logic
    const totalPages = Math.ceil(roundsData.total );

    return (
        <>
            <CRow className="mt-4">
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            {loading ? (
                                <p>Loading...</p>
                            ) : (
                                <>
                                    <CTable align="middle" className="mb-0 border" hover responsive>
                                        <CTableHead>
                                            <CTableRow>
                                                <CTableHeaderCell className="text-center">Round Number</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Status</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Result</CTableHeaderCell>
                                               
                                                <CTableHeaderCell className="text-center">Total Bets</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Total Amount</CTableHeaderCell>
                                            </CTableRow>
                                        </CTableHead>

                                        <CTableBody>
                                            {roundsData.rounds.map((round, index) => (
                                                <CTableRow key={index}>
                                                    <CTableDataCell className="text-center">{round.roundNumber || "NA"}</CTableDataCell>
                                                    <CTableDataCell className="text-center">
                                                        {round.status && (
                                                            <>
                                                                {/* General statuses */}
                                                                {round.status === "in-progress" && <CBadge color="warning">In Progress</CBadge>}
                                                                {round.status === "pending" && <CBadge color="info">Pending</CBadge>}
                                                                {round.status === "cancelled" && <CBadge color="danger">Cancelled</CBadge>}

                                                                {/* Card game specific statuses */}
                                                                {round.status === "accepting_bets" && <CBadge color="info">Accepting Bets</CBadge>}
                                                                {round.status === "no_more_bets" && <CBadge color="success">No More Bets</CBadge>}
                                                                {round.status === "joker_dealt" && <CBadge color="success">Joker Dealt</CBadge>}
                                                                {round.status === "playing" && <CBadge color="warning">Playing</CBadge>}
                                                                {round.status === "dealing" && <CBadge color="warning">Dealing</CBadge>}
                                                                {round.status === "result" && <CBadge color="success">Result</CBadge>}
                                                            </>
                                                        )}
                                                    </CTableDataCell>
                                                    <CTableDataCell className="text-center">
                                                        {/* {getRoundResult(round)} */}
                                                        {round.winner? round.winner : round.result }
                                                    </CTableDataCell>
                                                
                                                    <CTableDataCell className="text-center">{round.totalBets || 0}</CTableDataCell>
                                                    <CTableDataCell className="text-center">₹{round.totalAmount || 0}</CTableDataCell>
                                                </CTableRow>
                                            ))}
                                        </CTableBody>
                                    </CTable>

                                    {/* Pagination Controls */}
                                    <div className="d-flex justify-content-between pagination-controls align-items-center mt-3">
                                        <CButton
                                            color="warning"
                                            disabled={currentPage === 1}
                                            onClick={() => setCurrentPage(currentPage - 1)}
                                        >
                                            <RiArrowLeftSLine size={20} />
                                        </CButton>

                                        <span>Page {currentPage} of {totalPages}</span>

                                        <CButton
                                            color="warning"
                                            disabled={currentPage === totalPages || roundsData.rounds.length < itemsPerPage}
                                            onClick={() => setCurrentPage(currentPage + 1)}
                                        >
                                            <RiArrowRightSLine size={20} />
                                        </CButton>
                                    </div>
                                </>
                            )}
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    );
};

export default GameRounds;