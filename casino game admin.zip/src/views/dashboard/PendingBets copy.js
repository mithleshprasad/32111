import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CRow,
    CTable,
    CTableBody,
    CTableDataCell,
    CTableHead,
    CTableHeaderCell,
    CTableRow,
} from '@coreui/react';
import { IoIosClock } from "react-icons/io";

const Category = () => {
    const [loading, setLoading] = useState(false);
    const [bets, setBets] = useState([]);
    const [selectedColor, setSelectedColor] = useState(null);
    const [userBetData, setUserBetData] = useState(null);
    const user_id = localStorage.getItem("user_id");
    const category_slug = localStorage.getItem("Category_slug");
    const subcategory_slug = localStorage.getItem("subcat_slug");

    const fetchGameSupSubCategory = async () => {
        try {
            setLoading(true);

            const url = `https://apicolorgame.a2logicgroup.com/api/admin/game-super-sub-category-list`;

            const response = await axios.post(url, { user_id });

            const responseData1 = response.data.data;
            setUserBetData(responseData1);
            if (responseData1.length > 0) {
                const firstItem = responseData1[0];
                const scopeString = firstItem.scope;
                const betMultipleString = firstItem.betMultiple;
                const typeName = firstItem.typeName;
                const slug = firstItem.slug;
                const intervalM = firstItem.intervalM;
                const typeIds = firstItem.typeID;

                const scopes = scopeString.split("|").map(Number);
                const betMultiples = betMultipleString.split("|").map(Number);
                localStorage.setItem("super_sub_cat_name", typeName);
                localStorage.setItem("super_sub_cat_slug", slug);
                localStorage.setItem("intervalM", intervalM);
                localStorage.setItem("typeID", typeIds);
                setScopeValues(scopes);
                setBetMultipleValues(betMultiples);

                console.log("Fetched data:", response.data.data);
            } else {
                console.error("Unexpected response structure:", response.data);
            }
        } catch (error) {
            console.error("Error fetching data:", error.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchGameSupSubCategory();
    }, []);

    // Fetch pending bets from API
    const fetchPendingBets = async () => {
        try {
            setLoading(true);
            const url = `https://apicolorgame.a2logicgroup.com/api/admin/pending-bet-list`;
            const response = await axios.post(url, { user_id, category_slug, subcategory_slug, type: 1 });

            if (response.data?.success === "1" && Array.isArray(response.data?.data)) {
                setBets(response.data.data);
            } else {
                setBets([]);
            }
        } catch (error) {
            console.error("Error fetching pending bets:", error.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchPendingBets();
    }, [user_id, category_slug, subcategory_slug]);

    // Ball numbers with colors
    const balls = [
        { number: "0", colorName: "red violet", color: "linear-gradient(to right, violet, #fd565c)" },
        { number: "1", color: "green" },
        { number: "2", color: "red" },
        { number: "3", color: "green" },
        { number: "4", color: "red" },
        { number: "5", colorName: "green violet", color: "linear-gradient(to right, #40ad72, violet)" },
        { number: "6", color: "red" },
        { number: "7", color: "green" },
        { number: "8", color: "red" },
        { number: "9", color: "green" },
    ];

    const normalizeColor = (color) => {
        if (color.includes("linear-gradient")) {
            if (color.includes("violet, #fd565c")) return "red violet";
            if (color.includes("#40ad72, violet")) return "green violet";
        }
        return color;
    };


    const selectColors = [
        { name: "Green", color: "green" },
        { name: "Violet", color: "violet" },
        { name: "Red", color: "red" },
    ];

    const tabs = [
        { label: "Win Go", time: "1 Min" },
        { label: "Win Go", time: "3 Min" },
        { label: "Win Go", time: "5 Min" },
        { label: "Win Go", time: "10 Min" },
    ];

    return (
        <>
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            <h4 className="d-inline">Pending Bet List</h4>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {/* Tabs Section */}
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            <div className="d-flex justify-content-between gap-3 w-100">
                                {tabs.map((tab, index) => (
                                    <div key={index} className="tabs_windgo">
                                        <div className="d-flex justify-content-center align-items-center icon_rounded">
                                            <IoIosClock size={50} />
                                        </div>
                                        <p>
                                            {tab.label} <span>{tab.time}</span>
                                        </p>
                                    </div>
                                ))}
                            </div>

                            {/* Color Selection Buttons */}
                            <div className="d-flex align-items-center justify-content-between mt-5">
                                <div className="d-flex gap-2">
                                    {selectColors.map((item, index) => (
                                        <button
                                            key={index}
                                            className={`button_color_game ${selectedColor === item.color ? "selected" : ""}`}
                                            style={{ backgroundColor: item.color, color: "#fff", fontWeight: "bold" }}
                                            onClick={() => setSelectedColor(item.color)}
                                        >
                                            {item.name}
                                        </button>
                                    ))}
                                </div>
                                <div className="timer">
                                    <span>00:00 Time Remaining</span>
                                </div>
                            </div>

                            {/* Color Number Buttons with Amount */}
                            <div className="d-flex justify-content-between flex-wrap gap-2 mt-5">
                                {balls
                                    .filter((item) => !selectedColor || item.color === selectedColor)
                                    .map((item, index) => {
                                        const matchingBet = bets.find(
                                            (bet) =>
                                                bet.number == item.number &&
                                                normalizeColor(bet.color) === normalizeColor(item.color)
                                        );

                                        return (
                                            <button
                                                key={index}
                                                className="button_color_game_number"
                                                style={{
                                                    background: item.color,
                                                    position: "relative",
                                                    padding: " 10px 31px",
                                                    borderRadius: "5px",
                                                    color: "white",
                                                    fontWeight: "bold",
                                                    minWidth: "50px",
                                                }}
                                            >
                                                {item.number}
                                                {matchingBet && (
                                                    <span
                                                        style={{
                                                            position: "absolute",
                                                            bottom: "-20px",
                                                            left: "50%",
                                                            transform: "translateX(-50%)",
                                                            fontSize: "12px",
                                                            color: "#fff",
                                                            background: "rgba(0,0,0,0.5)",
                                                            padding: "2px 5px",
                                                            borderRadius: "3px",
                                                        }}
                                                    >
                                                        ₹{matchingBet.amount}
                                                    </span>
                                                )}
                                            </button>
                                        );
                                    })}
                            </div>

                            {/* <div className="d-flex justify-content-end mt-5">
                                {selectedColor && (
                                    (() => {
                                        // Find all matching bets for the selected color
                                        const totalAmount = bets
                                            .filter((bet) => bet.color === selectedColor)
                                            .reduce((sum, bet) => sum + (bet.amount || 0), 0);

                                        return totalAmount > 0 ? (
                                            <span
                                                style={{
                                                    fontSize: "18px",
                                                    fontWeight: "bold",
                                                    color: "#fff",
                                                    background: "rgba(0,0,0,0.5)",
                                                    padding: "5px 10px",
                                                    borderRadius: "5px",
                                                }}
                                            >
                                                Total ₹{totalAmount} for {selectedColor}
                                            </span>
                                        ) : null;
                                    })()
                                )}
                            </div> */}


                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {/* Pending Bets Table */}
            <CRow className="mt-1">
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            {loading ? (
                                <p>Loading...</p>
                            ) : (
                                <CTable align="middle" className="mb-0 border" hover responsive>
                                    <CTableHead className="text-nowrap">
                                        <CTableRow>
                                            <CTableHeaderCell className="text-center">Period Id</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Game Type Time</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Color</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Number</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Quantity</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Amount</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Status</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">DateTime</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Result</CTableHeaderCell>
                                        </CTableRow>
                                    </CTableHead>

                                    <CTableBody>
                                        {bets.map((item, index) => (
                                            <CTableRow key={index}>
                                                <CTableDataCell className="text-center">{item.period_id}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.game_type_time}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.color}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.number || "-"}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.quantity}</CTableDataCell>
                                                <CTableDataCell className="text-center">₹{item.amount}</CTableDataCell>
                                                <CTableDataCell className="text-center">
                                                    <span style={{ color: "orange" }}>Pending</span>
                                                </CTableDataCell>
                                                <CTableDataCell className="text-center">{item.datetime}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.result || "-"}</CTableDataCell>
                                            </CTableRow>
                                        ))}
                                    </CTableBody>
                                </CTable>
                            )}
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    );
};

export default Category;
