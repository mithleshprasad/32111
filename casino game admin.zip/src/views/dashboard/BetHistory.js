import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { CButton, CCard, CCardBody, CCol, CRow, CTable, CTableBody, CTableDataCell, CTableHead, CTableHeaderCell, CTableRow } from '@coreui/react';
import { RiArrowRightSLine, RiArrowLeftSLine } from "react-icons/ri";
import { CBadge } from '@coreui/react';

const AllBets = () => {
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const game = queryParams.get('game');
    const [betsData, setBetsData] = useState({ bets: [], total: 0 });
    const [loading, setLoading] = useState(false);
    const user_id = localStorage.getItem("user_id");
    const userId = localStorage.getItem("userId");

    // Pagination State
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    useEffect(() => {
        fetchAllBets();
    }, [game]);

    const fetchAllBets = async () => {
        try {
            setLoading(true);
            const url = `http://localhost:5000/api/admin/bets/${game}`;
            const response = await axios.post(url, { userId });
            if (response.data) {
                setBetsData({
                    bets: response.data.bets || [],
                    total: response.data.total || 0
                });
            }
        } catch (error) {
            console.error("Error fetching data:", error.message);
        } finally {
            setLoading(false);
        }
    };

    // Format date to display
    const formatDate = (dateString) => {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        return new Date(dateString).toLocaleDateString(undefined, options);
    };

    // Pagination Logic
    const totalPages = Math.ceil(betsData.total / itemsPerPage);
    const currentBets = betsData.bets.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    return (
        <>
            <CRow className="mt-4">
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            {loading ? (
                                <p>Loading...</p>
                            ) : (
                                <>
                                    <CTable align="middle" className="mb-0 border" hover responsive>
                                        <CTableHead>
                                            <CTableRow>
                                                <CTableHeaderCell className="text-center">Round Number</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Bet Type</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Amount</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Odds</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Payout</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Status</CTableHeaderCell>
                                                <CTableHeaderCell className="text-center">Date/Time</CTableHeaderCell>
                                            </CTableRow>
                                        </CTableHead>

                                        <CTableBody>
                                            {currentBets.map((item, index) => (
                                                <CTableRow key={index}>
                                                    <CTableDataCell className="text-center">{item.roundNumber || 'NA'}</CTableDataCell>
                                                    <CTableDataCell className="text-center">{item.betType  || "NA"}</CTableDataCell>
                                                    <CTableDataCell className="text-center">₹{item.amount || 0}</CTableDataCell>
                                                    <CTableDataCell className="text-center">{item.odds || 0}</CTableDataCell>
                                                    <CTableDataCell className="text-center">₹{item.payout || 0}</CTableDataCell>
                                                    <CTableDataCell className="text-center">
                                                        {item.status === "won" && <CBadge color="success">Win</CBadge>}
                                                        {item.status === "pending" && <CBadge color="warning">Pending</CBadge>}
                                                        {item.status === "lost" && <CBadge color="danger">Loss</CBadge>}
                                                    </CTableDataCell>
                                                    <CTableDataCell className="text-center">{formatDate(item.createdAt)}</CTableDataCell>
                                                </CTableRow>
                                            ))}
                                        </CTableBody>
                                    </CTable>

                                    {/* Pagination Controls */}
                                    <div className="d-flex justify-content-between pagination-controls align-items-center mt-3">
                                        <CButton 
                                            color="warning" 
                                            disabled={currentPage === 1} 
                                            onClick={() => setCurrentPage(currentPage - 1)}
                                        >
                                            <RiArrowLeftSLine size={20} /> 
                                        </CButton>

                                        <span>Page {currentPage} of {totalPages}</span>

                                        <CButton 
                                            color="warning" 
                                            disabled={currentPage === totalPages || betsData.bets.length < itemsPerPage} 
                                            onClick={() => setCurrentPage(currentPage + 1)}
                                        >
                                            <RiArrowRightSLine size={20} />
                                        </CButton>
                                    </div>
                                </>
                            )}
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    );
};

export default AllBets;