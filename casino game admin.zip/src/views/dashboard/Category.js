import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import {
  CAvatar,
  CButton,
  CCard,
  CCardBody,
  CCol,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react';
import {CIcon}from '@coreui/icons-react'
import { IoMdAdd } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEdit } from "react-icons/fa";


import {
  cilPeople,
} from '@coreui/icons'
import { Navigate } from 'react-router-dom';
const Category = () => {
  const [formData, setFormData] = useState({
    image: null,
    name: '',
    status: '',
    slug: '',
    description: '',
  });

  const navigate = useNavigate();
  const [previewImage, setPreviewImage] = useState('');
  const [message, setMessage] = useState('');
  const [gameCategory, setGameCategory] = useState([]);
  const isLoading = useRef(false);
  const [loading, setLoading] = useState(false);
  const user_id = localStorage.getItem("user_id");
  const [slug, setSlug] = useState('');

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle image upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const fetchGameCategory = async () => {
    try {
      isLoading.current = true;
      setLoading(true);

      const url = `https://apicolorgame.a2logicgroup.com/api/admin/game-category-list`;

      const config = {
        method: "POST",
        url: url,
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          user_id: user_id,
        },
      };

      const response = await axios(config);

      if (response.data?.success === "1" && Array.isArray(response.data.data)) {
        setGameCategory(response.data.data);
        setSlug(response.data.data[0].slug);
        localStorage.setItem("Category_slug", response.data.data[0].slug);
        console.log("Fetched Users:", response.data.data);
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error fetching user data:", error.message);
    } finally {
      isLoading.current = false; // Ensure cleanup in the finally block
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGameCategory();
  }, []);


  const fetchDelete = async(slug) => {
    try {
      isLoading.current = true;
      setLoading(true);
  
      const url = `https://apicolorgame.a2logicgroup.com/api/admin/delete-category/${slug}`;
  
      const config = {
        method: "POST",
        url: url,
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          user_id: user_id,
        },
      };
      const response = await axios(config);
  
      if (response.data?.success === "1") {
        setMessage(response.data.message);
        fetchGameCategory();
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error fetching user data:", error.message);
    }
  }

  //  const handleEdit = async(slug) => {
  //   navigate(`/UpdateCategory/${slug}`);
    

  const handleEdit = (slug) => {
    navigate(`/UpdateCategory/${slug}`);
  };


  return (
<>
        <CRow>
          <CCol xs>
            <CCard className="mb-4">
              <CCardBody>
                <h4 className="d-inline">Category List</h4>
                <Link to="/AddCategory">
                <CButton color="primary" className="float-end">
                  <IoMdAdd className="me-2" />
                  Add Category
                </CButton>
                </Link>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
    <CRow>
            <CCol xs>
        <CCard className="mb-4">
          <CCardBody>
            <CTable align="middle" className="mb-0 border" hover responsive>
              <CTableHead className="text-nowrap">
                <CTableRow>
                  {/* <CTableHeaderCell className="bg-body-tertiary text-center">
                    <CIcon icon={cilPeople} />
                  </CTableHeaderCell> */}
                  <CTableHeaderCell className="bg-body-tertiary text-center">
                  <CIcon icon={cilPeople} />
                  </CTableHeaderCell>
                  <CTableHeaderCell className="bg-body-tertiary text-center">
                    Name
                  </CTableHeaderCell>
                  {/* <CTableHeaderCell className="bg-body-tertiary text-center">
                    Slug
                  </CTableHeaderCell> */}
                  <CTableHeaderCell className="bg-body-tertiary text-center">
                    Description
                  </CTableHeaderCell>
                  <CTableHeaderCell className="bg-body-tertiary text-center">
                    Status
                  </CTableHeaderCell>
                  <CTableHeaderCell className="bg-body-tertiary text-center">Action</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {gameCategory.map((item, index) => (
                  <CTableRow key={index}>
                    {/* Avatar */}
                    <CTableDataCell className="text-center">
                      <CAvatar
                        size="md"
                        src={`${"https://apicolorgame.a2logicgroup.com"}/${item.image}` || "default-avatar.png"}
                      />
                    </CTableDataCell>

                    {/* Name */}
                    <CTableDataCell>
                      <div className="text-center">{item.name}</div>
                    </CTableDataCell>

                    {/* Slug */}
                    {/* <CTableDataCell>
                      <div className="text-center">{item.slug}</div>
                    </CTableDataCell> */}

                    {/* Description */}
                    <CTableDataCell>
                      <div className="text-center">
                        <div dangerouslySetInnerHTML={{ __html: item.description }} />
                      </div>
                    </CTableDataCell>

                    {/* Status */}
                    <CTableDataCell className="text-center">
                      <span style={{ color: item.status === "1" ? "green" : "red" }}>
                        {item.status === "1" ? "Active" : "Inactive"}
                      </span>
                    </CTableDataCell>
                    <CTableDataCell className='text-center'>
                      {/* <Link to={`/AddCategory/${item._id}`}>
                    <CButton
                    color="primary"
                    size="sm"
                    className="me-2 text-white"
                  >
                    <IoMdAdd />
                  </CButton>
                  </Link> */}

                    <CButton
                    color="warning"
                    size="sm"
                    className="me-2 text-white"
                    onClick={() => handleEdit(item.slug)}
                  >
                    <FaEdit />
                  </CButton>
                  <CButton
                    color="danger"
                    size="sm"
                    className="me-2 text-white"
                    onClick={() => fetchDelete(item.slug)}
                  >
                    <RiDeleteBin6Line />
                  </CButton>

                    </CTableDataCell>
                    
                  </CTableRow>
                ))}
              </CTableBody>

            </CTable>
          </CCardBody>
        </CCard>
      </CCol>

    </CRow>
    </>
  );
};

export default Category;
