// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import {
//   CAvatar,
//   CBadge,
//   CDropdown,
//   CDropdownDivider,
//   CDropdownHeader,
//   CDropdownItem,
//   CDropdownMenu,
//   CDropdownToggle,
// } from '@coreui/react'
// import {
//   cilBell,
//   cilCreditCard,
//   cilCommentSquare,
//   cilEnvelopeOpen,
//   cilFile,
//   cilLockLocked,
//   cilSettings,
//   cilTask,
//   cilUser,
// } from '@coreui/icons'
// import CIcon from '@coreui/icons-react'

// import avatar8 from './../../assets/images/avatars/8.jpg'

// const AppHeaderDropdown = () => {
//   const userId = localStorage.getItem("_id");
//   const token = localStorage.getItem("token");
//   const role = localStorage.getItem("role");
//   const [ProfileImage, setProfileImage] = useState();
 
//   const resultDataLoad = async () => {
//     if (!token) {
//       console.error("Access denied: Token not found in localStorage.");
//       return;
//     }
  
//     try {
//       const response = await axios.post(
//         `http://localhost:5000/api/admin/AdminProfile`, // Use POST method
//         {
//           userId, // Include userId in the request body
//           role,   // Include role in the request body
//         },
//         {
//           headers: {
//             Authorization: `Bearer ${token}`, // Add token here
//           },
//         }
//       );
  
//       if (response.data.success) {
//         setProfileImage(response.data.user.ProfileImage);
//       } else {
//         console.error("Error fetching results:", response.data.message);
//       }
//     } catch (err) {
//       console.error("Error fetching data:", err.response?.data || err.message);
//     }
//   };
  

//   useEffect(() => {
//     resultDataLoad();
//   }, []);
//   return (
//     <CDropdown variant="nav-item">
//       <CDropdownToggle placement="bottom-end" className="py-0 pe-0" caret={false}>
//         <CAvatar src={`http://localhost:5000${ProfileImage}`} size="md" />
//       </CDropdownToggle>
//       <CDropdownMenu className="pt-0" placement="bottom-end">
//         <CDropdownHeader className="bg-body-secondary fw-semibold mb-2">Account</CDropdownHeader>

      
//         <CDropdownItem href="#">
//           <CIcon icon={cilUser} className="me-2" />
//           Profile
//         </CDropdownItem>
//         <CDropdownItem href="#">
//           <CIcon icon={cilSettings} className="me-2" />
//           Settings
//         </CDropdownItem>
//         <CDropdownItem href="#">
//           <CIcon icon={cilCreditCard} className="me-2" />
//           Payments
//           <CBadge color="secondary" className="ms-2">
//             42
//           </CBadge>
//         </CDropdownItem>
     
//         <CDropdownDivider />
//         <CDropdownItem href="#">
//           <CIcon icon={cilLockLocked} className="me-2" />
//           Lock Account
//         </CDropdownItem>
//       </CDropdownMenu>
//     </CDropdown>
//   )
// }

// export default AppHeaderDropdown
import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  CAvatar,
  CBadge,
  CDropdown,
  CDropdownDivider,
  CDropdownHeader,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from "@coreui/react";
import {
  cilBell,
  cilCreditCard,
  cilCommentSquare,
  cilEnvelopeOpen,
  cilFile,
  cilLockLocked,
  cilSettings,
  cilTask,
  cilUser,
  cilExitToApp,
} from "@coreui/icons";
import CIcon from "@coreui/icons-react";

import avatar8 from "./../../assets/images/avatars/8.jpg";
import { useNavigate } from "react-router-dom";

const AppHeaderDropdown = () => {
  const userId = localStorage.getItem("_id");
  // const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");
  const [ProfileImage, setProfileImage] = useState();
  const navigate = useNavigate();

  const resultDataLoad = async () => {
    // if (!token) {
    //   console.error("Access denied: Token not found in localStorage.");
    //   return;
    // }

    try {
      const response = await axios.post(
        `http://localhost:5000/api/admin/AdminProfile`, // Use POST method
        {
          userId, // Include userId in the request body
          role, // Include role in the request body
        },
        {
          headers: {
            Authorization: `Bearer ${token}`, // Add token here
          },
        }
      );

      if (response.data.success) {
        setProfileImage(response.data.user.ProfileImage);
      } else {
        console.error("Error fetching results:", response.data.message);
      }
    } catch (err) {
      console.error("Error fetching data:", err.response?.data || err.message);
    }
  };

  const handleLogout = () => {
    // Clear local storage
    let result = confirm("Are you sure you want to delete this item?");
  if (result) {
    // alert("Item deleted.");
    localStorage.clear();

    // Navigate to login page
    navigate("/login");
    // Add your delete logic here
  } else {
    alert("Action canceled.");
  }
  };

  useEffect(() => {
    resultDataLoad();
  }, []);

  return (
    <CDropdown variant="nav-item">
      <CDropdownToggle placement="bottom-end" className="py-0 pe-0" caret={false}>
        <CAvatar src={avatar8} size="md" />
      </CDropdownToggle>
      <CDropdownMenu className="pt-0" placement="bottom-end">
        <CDropdownHeader className="bg-body-secondary fw-semibold mb-2">Account</CDropdownHeader>

        {/* <CDropdownItem href="#">
          <CIcon icon={cilUser} className="me-2" />
          Profile
        </CDropdownItem> */}
        {/* <CDropdownItem href="#">
          <CIcon icon={cilSettings} className="me-2" />
          Settings
        </CDropdownItem> */}
        {/* <CDropdownItem href="#">
          <CIcon icon={cilCreditCard} className="me-2" />
          Payments
          <CBadge color="secondary" className="ms-2">
            42
          </CBadge>
        </CDropdownItem> */}

      
        <CDropdownItem onClick={handleLogout} style={{cursor:"pointer"}}>
          <CIcon icon={cilExitToApp} className="me-2 " />
          Log Out
        </CDropdownItem>
      </CDropdownMenu>
    </CDropdown>
  );
};

export default AppHeaderDropdown;
