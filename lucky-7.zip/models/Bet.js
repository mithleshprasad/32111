const mongoose = require('mongoose');

const betSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  gameRoundId: { type: mongoose.Schema.Types.ObjectId, ref: 'GameRound', required: true },
  amount: { type: Number, required: true },
  betType: { type: String, enum: ['below7', 'lucky7', 'above7'], required: true },
  payout: { type: Number, default: 0 },
  status: { type: String, enum: ['pending', 'won', 'lost'], default: 'pending' },
  odds: { type: Number, default: 1 },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Bet', betSchema);