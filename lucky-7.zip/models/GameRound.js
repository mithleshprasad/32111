const mongoose = require('mongoose');

const cardSchema = new mongoose.Schema({
  value: { type: String, required: true },
  suit: { type: String, required: true },
});

const gameRoundSchema = new mongoose.Schema({
  roundNumber: { type: Number, required: true },
  status: {
    type: String,
    enum: ['accepting_bets', 'no_more_bets', 'dealing', 'result'],
    default: 'accepting_bets',
  },
  bettingEndTime: { type: Date },
  cards: [cardSchema],
  total: { type: Number },
  result: { type: String, enum: ['below7', 'lucky7', 'above7', null] },
  winnerAnnouncedTime: { type: Date },
  bets: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Bet' }],
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('GameRound', gameRoundSchema);