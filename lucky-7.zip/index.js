const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();
const http = require('http');
const connectDB = require('./config/db');
const path = require('path');
const WebSocket = require('ws');
// const betRoutes = require('./routes/betRoutes');
// const userRoutes = require('./routes/userRoutes');
const GameRound = require('./models/GameRound');
const Bet = require('./models/Bet');
const User = require('./models/User');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
// app.use('/api/bets', betRoutes);
// app.use('/api/user', userRoutes);

// Deck configuration
const cardValues = {
  '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14,
};
const suits = ['S', 'H', 'D', 'C'];
const values = ['7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
let deck = [];

function resetDeck() {
  deck = [];
  for (const suit of suits) {
    for (const value of values) {
      deck.push({ value, suit });
    }
  }
  // Shuffle deck
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
}

// WebSocket handling
wss.on('connection', (ws) => {
  console.log('New client connected');
  ws.send(JSON.stringify({
    type: 'connection',
    message: 'Welcome to Lucky 7 WebSocket Server',
  }));

  ws.on('message', async (message) => {
    try {
      const data = JSON.parse(message);
      if (data.type === 'placeBet') {
        const round = await GameRound.findOne({ status: 'accepting_bets' });
        if (!round) {
          return ws.send(JSON.stringify({
            type: 'error',
            message: 'No active betting round',
          }));
        }
        const user = await User.findById(data.userId);
        if (!user) {
          return ws.send(JSON.stringify({
            type: 'error',
            message: 'User not found',
          }));
        }
        if (data.amount > user.balance) {
          return ws.send(JSON.stringify({
            type: 'error',
            message: 'Insufficient balance',
          }));
        }
        if (!['below7', 'lucky7', 'above7'].includes(data.betType)) {
          return ws.send(JSON.stringify({
            type: 'error',
            message: 'Invalid bet type',
          }));
        }

        // Deduct balance
        user.balance -= data.amount;
        await user.save();

        // Create bet
        const odds = data.betType === 'lucky7' ? 4 : 1;
        const bet = new Bet({
          userId: data.userId,
          gameRoundId: round._id,
          amount: data.amount,
          betType: data.betType,
          odds,
        });
        await bet.save();

        round.bets.push(bet._id);
        await round.save();

        ws.send(JSON.stringify({
          type: 'betPlaced',
          betId: bet._id,
          roundNumber: round.roundNumber,
          betType: data.betType,
          amount: data.amount,
        }));
      }
    } catch (error) {
      console.error('Error handling WebSocket message:', error);
      ws.send(JSON.stringify({
        type: 'error',
        message: error.message,
      }));
    }
  });

  ws.on('close', () => console.log('Client disconnected'));
});

let currentRound = null;

async function startNewRound() {
  try {
    const lastRound = await GameRound.findOne().sort({ roundNumber: -1 });
    const roundNumber = lastRound ? lastRound.roundNumber + 1 : 1;

    resetDeck();
    currentRound = new GameRound({
      roundNumber,
      status: 'accepting_bets',
      bettingEndTime: new Date(Date.now() + 30000), // 30 seconds for betting
    });
    await currentRound.save();
    console.log(`Starting new round: ${roundNumber}`);

    broadcast({
      type: 'newRound',
      roundNumber: currentRound.roundNumber,
      status: currentRound.status,
      bettingEndTime: currentRound.bettingEndTime,
    });

    // Close betting after 30 seconds
    setTimeout(async () => {
      currentRound.status = 'no_more_bets';
      await currentRound.save();

      broadcast({
        type: 'bettingClosed',
        roundNumber: currentRound.roundNumber,
      });

      // Deal three cards
      const cards = deck.splice(0, 3);
      const total = cards.reduce((sum, card) => sum + cardValues[card.value], 0);
      const result = total < 7 ? 'below7' : total === 7 ? 'lucky7' : 'above7';

      currentRound.status = 'dealing';
      currentRound.cards = cards;
      currentRound.total = total;
      currentRound.result = result;
      await currentRound.save();

      broadcast({
        type: 'cardsDealt',
        roundNumber: currentRound.roundNumber,
        cards,
        total,
        result,
      });

      // Process bets after showing cards
      setTimeout(async () => {
        await processBets(currentRound._id, result);
        currentRound.status = 'result';
        currentRound.winnerAnnouncedTime = new Date();
        await currentRound.save();

        broadcast({
          type: 'roundResult',
          roundNumber: currentRound.roundNumber,
          result,
          total,
          cards,
          winnerAnnouncedTime: currentRound.winnerAnnouncedTime,
        });

        // Start new round after 10 seconds
        setTimeout(startNewRound, 10000);
      }, 5000);
    }, 30000);
  } catch (error) {
    console.error('Error in game round:', error);
    broadcast({
      type: 'error',
      message: 'Error in game round',
    });
    setTimeout(startNewRound, 5000);
  }
}

async function processBets(roundId, result) {
  try {
    const bets = await Bet.find({ gameRoundId: roundId, status: 'pending' });
    for (const bet of bets) {
      if (bet.betType === result) {
        const payout = bet.amount * (bet.odds + 1); // Include original bet
        bet.payout = payout;
        bet.status = 'won';
        await User.findByIdAndUpdate(bet.userId, { $inc: { balance: payout } });
      } else {
        bet.payout = 0;
        bet.status = 'lost';
      }
      await bet.save();
    }
  } catch (error) {
    console.error('Error processing bets:', error);
  }
}

function broadcast(message) {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  });
}

// Start server
const PORT = process.env.PORT || 5000;
connectDB().then(() => {
  startNewRound();
  server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}).catch((error) => {
  console.error('Failed to connect to database:', error);
});