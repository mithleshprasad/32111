// Game state
 const userId = localStorage.getItem('userId');

const gameState = {
  balance: 0,
  currentBet: 0,
  selectedBet: null,
  gameInProgress: false,
  soundEnabled: true,
  gameHistory: [],
 userId: userId,  roundNumber: 0,
};
 
// DOM elements
const elements = {
  balance: document.getElementById('balance'),
  betAmountInput: document.getElementById('amount'),
  betBelow7: document.getElementById('bet-below7'),
  betLucky7: document.getElementById('bet-lucky7'),
  betAbove7: document.getElementById('bet-above7'),
  playerCards: [
    document.getElementById('player-card-1'),
    document.getElementById('player-card-2'),
    document.getElementById('player-card-3'),
  ],
  resultDisplay: document.getElementById('result'),
  dealBtn: document.getElementById('deal-btn'),
  resetBtn: document.getElementById('reset-btn'),
  currentBetAmount: document.getElementById('current-bet-amount'),
  currentBetType: document.getElementById('current-bet-type'),
  historyItems: document.getElementById('history-items'),
  soundToggle: document.getElementById('sound-toggle'),
  helpBtn: document.getElementById('help-btn'),
  chips: document.querySelectorAll('.chip'),
};

// Audio elements
const audio = {
  deal: document.getElementById('dealSound'),
  win: document.getElementById('winSound'),
  lose: document.getElementById('loseSound'),
  chip: document.getElementById('chipSound'),
  seven: document.getElementById('sevenSound'),
};

// WebSocket connection
const ws = new WebSocket('ws://localhost:5000');

ws.onopen = () => {
  console.log('Connected to WebSocket server');
  fetchBalance();
  fetchBetHistory();
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('WebSocket message:', data);

  switch (data.type) {
    case 'newRound':
      gameState.roundNumber = data.roundNumber;
      resetGame();
      elements.resultDisplay.textContent = `Round ${data.roundNumber}: Place your bet!`;
      break;

    case 'bettingClosed':
      gameState.gameInProgress = true;
      elements.dealBtn.disabled = true;
      elements.resultDisplay.textContent = 'Betting closed, dealing cards...';
      break;

    case 'cardsDealt':
      displayCards(data.cards, data.total, data.result);
      break;

    case 'roundResult':
      handleRoundResult(data.result, data.total, data.cards);
      fetchBalance(); // Update balance after payout
      fetchBetHistory(); // Update history
      break;

    case 'betPlaced':
      gameState.currentBet = data.amount;
      elements.currentBetAmount.textContent = gameState.currentBet.toLocaleString();
      elements.currentBetType.textContent = data.betType === 'below7' ? 'Below 7' : data.betType === 'lucky7' ? 'Lucky 7' : 'Above 7';
      elements.dealBtn.disabled = false;
      break;

    case 'error':
      showResult(data.message, 'lose');
      playSound(audio.lose);
      if (data.message.includes('Insufficient balance')) {
        gameState.selectedBet = null;
        document.getElementById(`bet-${gameState.selectedBet}`)?.classList.remove('selected');
        elements.currentBetAmount.textContent = '0';
        elements.currentBetType.textContent = '-';
      }
      break;
  }
};

ws.onclose = () => {
  console.log('Disconnected from WebSocket server');
};

// Fetch user balance
async function fetchBalance() {
  try {
    const response = await fetch(`http://localhost:5000/api/user/balance/${gameState.userId}`);
    const data = await response.json();
    if (data.error) throw new Error(data.error);
    gameState.balance = data.balance;
    updateBalance();
  } catch (error) {
    console.error('Error fetching balance:', error);
    showResult('Error fetching balance', 'lose');
  }
}

// Fetch bet history
async function fetchBetHistory() {
  try {
    const response = await fetch(`http://localhost:5000/api/user/bets/${gameState.userId}`);
    const data = await response.json();
    if (data.error) throw new Error(data.error);
    elements.historyItems.innerHTML = '';
    data.bets.forEach((bet) => {
      const total = bet.gameRoundId?.total || 0;
      const outcome = bet.status;
      addToHistory(total, outcome);
    });
  } catch (error) {
    console.error('Error fetching bet history:', error);
  }
}

// Place a bet
function placeBet(betType) {
  if (gameState.gameInProgress) return;

  playSound(audio.chip);

  if (gameState.selectedBet) {
    document.getElementById(`bet-${gameState.selectedBet}`).classList.remove('selected');
  }

  gameState.selectedBet = betType;
  const betElement = document.getElementById(`bet-${gameState.selectedBet}`);
  betElement.classList.add('selected');
  betElement.classList.add('animate__animated', 'animate__pulse');

  setTimeout(() => {
    betElement.classList.remove('animate__animated', 'animate__pulse');
  }, 1000);

  let betValue = parseInt(elements.betAmountInput.value);
  if (isNaN(betValue)) {
    betValue = 100;
    elements.betAmountInput.value = 100;
  }
  if (betValue < 50) {
    betValue = 50;
    elements.betAmountInput.value = 50;
  } else if (betValue > 10000) {
    betValue = 10000;
    elements.betAmountInput.value = 10000;
  }

  ws.send(JSON.stringify({
    type: 'placeBet',
    userId: gameState.userId,
    amount: betValue,
    betType,
  }));
}

// Display dealt cards
function displayCards(cards, total, result) {
  elements.playerCards.forEach((card, index) => {
    card.src = 'https://deckofcardsapi.com/static/img/back.png';
    card.classList.add('card-deal');
  });

  playSound(audio.deal);

  setTimeout(() => {
    elements.playerCards.forEach((card, index) => {
      setTimeout(() => {
        card.classList.remove('card-deal');
        card.src = `https://deckofcardsapi.com/static/img/${cards[index].value}${cards[index].suit}.png`;
        playSound(audio.deal);
      }, index * 200);
    });

    setTimeout(() => {
      elements.resultDisplay.textContent = `Total: ${total} (${result === 'below7' ? 'Below 7' : result === 'lucky7' ? 'Lucky 7' : 'Above 7'})`;
    }, 1000);
  }, 500);
}

// Handle round result
function handleRoundResult(result, total, cards) {
  let message = '';
  let outcomeClass = '';
  let isWin = false;

  if (gameState.selectedBet === result) {
    const odds = gameState.selectedBet === 'lucky7' ? 4 : 1;
    const winnings = gameState.currentBet * (odds + 1);
    message = `Total: ${total} (${result === 'below7' ? 'Below 7' : result === 'lucky7' ? 'Lucky 7' : 'Above 7'})! You win ${formatCurrency(winnings)}!`;
    outcomeClass = 'win';
    isWin = true;
    if (result === 'lucky7') playSound(audio.seven);
    else playSound(audio.win);
  } else {
    message = `Total: ${total} (${result === 'below7' ? 'Below 7' : result === 'lucky7' ? 'Lucky 7' : 'Above 7'})! You lose ${formatCurrency(gameState.currentBet)}`;
    outcomeClass = 'lose';
    playSound(audio.lose);
  }

  showResult(message, outcomeClass);
  addToHistory(total, outcomeClass);

  if (isWin) {
    elements.resultDisplay.classList.add('animate__animated', 'animate__tada');
    setTimeout(() => {
      elements.resultDisplay.classList.remove('animate__animated', 'animate__tada');
    }, 1000);
  }

  elements.resetBtn.disabled = false;
}

// Reset the game
function resetGame() {
  elements.playerCards.forEach((card) => {
    card.src = 'https://deckofcardsapi.com/static/img/back.png';
  });

  if (gameState.selectedBet) {
    document.getElementById(`bet-${gameState.selectedBet}`).classList.remove('selected');
  }
  gameState.selectedBet = null;
  gameState.currentBet = 0;
  gameState.gameInProgress = false;

  elements.resultDisplay.textContent = '';
  elements.resultDisplay.className = 'result-display';
  elements.dealBtn.disabled = true;
  elements.resetBtn.disabled = true;
  elements.currentBetAmount.textContent = '0';
  elements.currentBetType.textContent = '-';
  elements.chips.forEach((chip) => chip.classList.remove('active'));
}

// Update balance display
function updateBalance() {
  elements.balance.textContent = gameState.balance.toLocaleString();
}

// Show result with animation
function showResult(message, type) {
  elements.resultDisplay.textContent = message;
  elements.resultDisplay.className = 'result-display';
  elements.resultDisplay.classList.add(type);
}

// Add game to history
function addToHistory(points, outcome) {
  const historyItem = document.createElement('div');
  historyItem.className = `history-item ${outcome}`;

  const pointsDisplay = document.createElement('div');
  pointsDisplay.textContent = points;
  pointsDisplay.style.fontWeight = 'bold';
  pointsDisplay.style.fontSize = '1.1rem';

  const outcomeText = document.createElement('div');
  outcomeText.className = 'outcome';
  outcomeText.textContent = outcome === 'win' ? 'Win' : 'Lose';

  historyItem.appendChild(pointsDisplay);
  historyItem.appendChild(outcomeText);

  historyItem.classList.add('animate__animated', 'animate__fadeIn');
  elements.historyItems.insertBefore(historyItem, elements.historyItems.firstChild);

  if (elements.historyItems.children.length > 10) {
    elements.historyItems.removeChild(elements.historyItems.lastChild);
  }
}

// Format currency
function formatCurrency(amount) {
  return '$' + amount.toLocaleString();
}

// Play sound
function playSound(sound) {
  if (gameState.soundEnabled) {
    sound.currentTime = 0;
    sound.play().catch((e) => console.log('Sound play prevented:', e));
  }
}

// Toggle sound
function toggleSound() {
  gameState.soundEnabled = !gameState.soundEnabled;
  elements.soundToggle.innerHTML = gameState.soundEnabled ?
    '<i class="fas fa-volume-up"></i>' :
    '<i class="fas fa-volume-mute"></i>';
}

// Show help
function showHelp() {
  alert(`Lucky 7 Game Rules:

1. Place your bet on:
   - Below 7 (total less than 7) - Pays 1:1
   - Lucky 7 (total equals 7) - Pays 4:1
   - Above 7 (total more than 7) - Pays 1:1

2. Wait for the server to deal three cards
3. Card values:
   - 7,8,9 = Face value
   - 10,J,Q,K = 10 points each
   - Ace = 11 points
4. The sum of three cards determines the winner
5. Uses standard Indian 32-card deck (7 through Ace)

Good luck!`);
}

// Event listeners
elements.betBelow7.addEventListener('click', () => placeBet('below7'));
elements.betLucky7.addEventListener('click', () => placeBet('lucky7'));
elements.betAbove7.addEventListener('click', () => placeBet('above7'));
elements.dealBtn.addEventListener('click', () => {
  showResult('Waiting for server to deal cards...', 'info');
});
elements.resetBtn.addEventListener('click', resetGame);
elements.soundToggle.addEventListener('click', toggleSound);
elements.helpBtn.addEventListener('click', showHelp);

elements.chips.forEach((chip) => {
  chip.addEventListener('click', function () {
    playSound(audio.chip);
    elements.chips.forEach((c) => c.classList.remove('active'));
    this.classList.add('active');
    const amount = parseInt(this.dataset.amount);
    elements.betAmountInput.value = amount;
    if (gameState.selectedBet) {
      placeBet(gameState.selectedBet);
    }
  });
});

elements.betAmountInput.addEventListener('input', function () {
  let value = parseInt(this.value);
  if (isNaN(value)) {
    value = 100;
  } else if (value < 50) {
    value = 50;
  } else if (value > 10000) {
    value = 10000;
  }
  this.value = value;
  if (gameState.selectedBet) {
    placeBet(gameState.selectedBet);
  }
});

// Initialize
window.addEventListener('load', () => {
  updateBalance();
});