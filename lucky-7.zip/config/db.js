// config/db.js
const mongoose = require("mongoose");

const connectDB = async () => {
  try {  
    await mongoose.connect("mongodb+srv://technomithlesh123:IwKgsfECU3XBB0t8@casino.m3zvc5e.mongodb.net/?retryWrites=true&w=majority&appName=casino",
      {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      }
    );
    console.log("MongoDB connected");
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};

module.exports = connectDB;
