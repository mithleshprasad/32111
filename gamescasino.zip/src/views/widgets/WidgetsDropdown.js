import React, { useEffect, useRef, useState } from 'react'
import PropTypes from 'prop-types'
import {
  CRow,
  CCol,
  CCard,
  CCardBody,
  CCardHeader,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
  CWidgetStatsA,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle,
} from '@coreui/react'
import { CChartBar, CChartLine, CChartDoughnut } from '@coreui/react-chartjs'
import CIcon from '@coreui/icons-react'
import { cilArrowBottom, cilArrowTop, cilOptions } from '@coreui/icons'
import axios from 'axios'

const WidgetsDropdown = (props) => {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [activeGame, setActiveGame] = useState('all') // 'all' or specific game name

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/admin/stats/all')
        setStats(response.data)
        setLoading(false)
      } catch (err) {
        setError(err.message)
        setLoading(false)
        console.error('Error fetching stats:', err)
      }
    }

    fetchStats()
  }, [])

  if (loading) return <div className="text-center py-5">Loading statistics...</div>
  if (error) return <div className="text-center py-5 text-danger">Error: {error}</div>
  if (!stats) return <div className="text-center py-5">No statistics available</div>

  // Get current game stats (all or specific)
  const currentStats = activeGame === 'all' 
    ? stats.combinedSummary 
    : stats.games.find(g => g.game === activeGame)?.summary

  const gameStats = stats.games.find(g => g.game === activeGame) || { betStats: {}, roundStats: {} }

  // Prepare data for charts
  const prepareGameDistributionData = () => {
    return {
      labels: stats.games.map(g => g.game.replace(/([a-z])([A-Z])/g, '$1 $2').toUpperCase()),
      datasets: [{
        data: stats.games.map(g => g.summary.totalBetAmount),
        backgroundColor: [
          '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'
        ]
      }]
    }
  }

  const prepareBetStatusData = () => {
    if (!gameStats.betStats.byStatus) return null
    return {
      labels: Object.keys(gameStats.betStats.byStatus).map(s => s.toUpperCase()),
      datasets: [{
        data: Object.values(gameStats.betStats.byStatus),
        backgroundColor: [
          '#4BC0C0', // won
          '#FF6384', // lost
          '#FFCE56', // pending
        ]
      }]
    }
  }

  const prepareRoundStatusData = () => {
    if (!gameStats.roundStats.byStatus) return null
    return {
      labels: Object.keys(gameStats.roundStats.byStatus).map(s => s.replace(/_/g, ' ').toUpperCase()),
      datasets: [{
        data: Object.values(gameStats.roundStats.byStatus),
        backgroundColor: [
          '#36A2EB', // accepting_bets
          '#FF9F40', // result
          '#9966FF', // dealing
          '#4BC0C0', // joker_dealt
        ]
      }]
    }
  }

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount)
  }

  return (
    <>
      {/* Game Selector Dropdown */}
      <div className="mb-4">
        <CDropdown>
          <CDropdownToggle color="secondary">
            {activeGame === 'all' ? 'All Games' : activeGame.replace(/([a-z])([A-Z])/g, '$1 $2').toUpperCase()}
          </CDropdownToggle>
          <CDropdownMenu>
            <CDropdownItem onClick={() => setActiveGame('all')}>All Games</CDropdownItem>
            {stats.games.map(game => (
              <CDropdownItem key={game.game} onClick={() => setActiveGame(game.game)}>
                {game.game.replace(/([a-z])([A-Z])/g, '$1 $2').toUpperCase()}
              </CDropdownItem>
            ))}
          </CDropdownMenu>
        </CDropdown>
      </div>

      {/* Summary Widgets */}
      <CRow className={props.className} xs={{ gutter: 4 }}>
        <CCol sm={6} xl={3}>
          <CWidgetStatsA
            color="primary"
            value={currentStats?.totalBets.toLocaleString()}
            title="TOTAL BETS"
            chart={
              <CChartLine
                className="mt-3 mx-3"
                style={{ height: '70px' }}
                data={{
                  labels: ['6d ago', '5d ago', '4d ago', '3d ago', '2d ago', 'Yesterday', 'Today'],
                  datasets: [{
                    backgroundColor: 'transparent',
                    borderColor: 'rgba(255,255,255,.55)',
                    // pointBackgroundColor: getStyle('--cui-primary'), 
                    data: [65, 59, 84, 84, 51, 55, 40],
                  }]
                }}
                options={{
                  plugins: { legend: { display: false } },
                  maintainAspectRatio: false,
                  scales: { x: { display: false }, y: { display: false } },
                  elements: {
                    line: { borderWidth: 1, tension: 0.4 },
                    point: { radius: 4, hitRadius: 10, hoverRadius: 4 }
                  }
                }}
              />
            }
          />
        </CCol>

        <CCol sm={6} xl={3}>
          <CWidgetStatsA
            color="info"
            value={formatCurrency(currentStats?.totalBetAmount)}
            title="TOTAL BET AMOUNT"
            chart={
              <CChartLine
                className="mt-3 mx-3"
                style={{ height: '70px' }}
                data={{
                  labels: ['6d ago', '5d ago', '4d ago', '3d ago', '2d ago', 'Yesterday', 'Today'],
                  datasets: [{
                    backgroundColor: 'transparent',
                    borderColor: 'rgba(255,255,255,.55)',
                    // pointBackgroundColor: getStyle('--cui-info'),
                    data: [1, 18, 9, 17, 34, 22, 11],
                  }]
                }}
                options={{
                  plugins: { legend: { display: false } },
                  maintainAspectRatio: false,
                  scales: { x: { display: false }, y: { display: false } },
                  elements: {
                    line: { borderWidth: 1, tension: 0.4 },
                    point: { radius: 4, hitRadius: 10, hoverRadius: 4 }
                  }
                }}
              />
            }
          />
        </CCol>

        <CCol sm={6} xl={3}>
          <CWidgetStatsA
            color="warning"
            value={formatCurrency(currentStats?.totalPayout)}
            title="TOTAL PAYOUT"
            chart={
              <CChartLine
                className="mt-3 mx-3"
                style={{ height: '70px' }}
                data={{
                  labels: ['6d ago', '5d ago', '4d ago', '3d ago', '2d ago', 'Yesterday', 'Today'],
                  datasets: [{
                    backgroundColor: 'transparent',
                    borderColor: 'rgba(255,255,255,.55)',
                    // pointBackgroundColor: getStyle('--cui-warning'),
                    data: [78, 81, 80, 45, 34, 12, 40],
                  }]
                }}
                options={{
                  plugins: { legend: { display: false } },
                  maintainAspectRatio: false,
                  scales: { x: { display: false }, y: { display: false } },
                  elements: {
                    line: { borderWidth: 1, tension: 0.4 },
                    point: { radius: 4, hitRadius: 10, hoverRadius: 4 }
                  }
                }}
              />
            }
          />
        </CCol>

        <CCol sm={6} xl={3}>
          <CWidgetStatsA
            color={currentStats?.netProfit >= 0 ? "success" : "danger"}
            value={formatCurrency(currentStats?.netProfit)}
            title="NET PROFIT"
            chart={
              <CChartBar
                className="mt-3 mx-3"
                style={{ height: '70px' }}
                data={{
                  labels: ['6d ago', '5d ago', '4d ago', '3d ago', '2d ago', 'Yesterday', 'Today'],
                  datasets: [{
                    backgroundColor: 'rgba(255,255,255,.2)',
                    borderColor: 'rgba(255,255,255,.55)',
                    data: [78, 81, 80, 45, 34, 12, 40],
                  }]
                }}
                options={{
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                  scales: { x: { display: false }, y: { display: false } }
                }}
              />
            }
          />
        </CCol>
      </CRow>

      {/* Detailed Statistics */}
      <CRow className="mt-4">
        {/* Game Distribution Chart */}
        <CCol md={6} lg={4}>
          <CCard>
            <CCardHeader>
              <strong>Game Distribution</strong>
            </CCardHeader>
            <CCardBody>
              <CChartDoughnut 
                data={prepareGameDistributionData()}
                options={{
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'right'
                    }
                  }
                }}
                style={{ height: '300px' }}
              />
            </CCardBody>
          </CCard>
        </CCol>

        {/* Bet Status Chart */}
        <CCol md={6} lg={4}>
          <CCard>
            <CCardHeader>
              <strong>Bet Status</strong>
            </CCardHeader>
            <CCardBody>
              {prepareBetStatusData() ? (
                <CChartDoughnut 
                  data={prepareBetStatusData()}
                  options={{
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'right'
                      }
                    }
                  }}
                  style={{ height: '300px' }}
                />
              ) : (
                <div className="text-center py-5">No bet status data available</div>
              )}
            </CCardBody>
          </CCard>
        </CCol>

        {/* Round Status Chart */}
        <CCol md={6} lg={4}>
          <CCard>
            <CCardHeader>
              <strong>Round Status</strong>
            </CCardHeader>
            <CCardBody>
              {prepareRoundStatusData() ? (
                <CChartDoughnut 
                  data={prepareRoundStatusData()}
                  options={{
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'right'
                      }
                    }
                  }}
                  style={{ height: '300px' }}
                />
              ) : (
                <div className="text-center py-5">No round status data available</div>
              )}
            </CCardBody>
          </CCard>
        </CCol>

        {/* Recent Bets Table */}
        <CCol xs={12} className="mt-4">
          <CCard>
            <CCardHeader>
              <strong>Recent Bets</strong>
            </CCardHeader>
            <CCardBody>
              <CTable striped hover responsive>
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Game</CTableHeaderCell>
                    <CTableHeaderCell>User</CTableHeaderCell>
                    <CTableHeaderCell>Amount</CTableHeaderCell>
                    <CTableHeaderCell>Type</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Payout</CTableHeaderCell>
                    <CTableHeaderCell>Date</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {stats.recentBets.slice(0, 10).map(bet => (
                    <CTableRow key={bet._id}>
                      <CTableDataCell>{bet.gameRoundId?.game || 'N/A'}</CTableDataCell>
                      <CTableDataCell>{bet.userId?._id?.slice(-6) || 'Anonymous'}</CTableDataCell>
                      <CTableDataCell>{formatCurrency(bet.amount)}</CTableDataCell>
                      <CTableDataCell>{bet.betType || bet.type || 'N/A'}</CTableDataCell>
                      <CTableDataCell>
                        <span className={`badge bg-${bet.status === 'won' ? 'success' : bet.status === 'lost' ? 'danger' : 'warning'}`}>
                          {bet.status.toUpperCase()}
                        </span>
                      </CTableDataCell>
                      <CTableDataCell>{formatCurrency(bet.payout)}</CTableDataCell>
                      <CTableDataCell>{new Date(bet.createdAt).toLocaleString()}</CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
            </CCardBody>
          </CCard>
        </CCol>

        {/* Recent Rounds Table */}
        <CCol xs={12} className="mt-4">
          <CCard>
            <CCardHeader>
              <strong>Recent Rounds</strong>
            </CCardHeader>
            <CCardBody>
              <CTable striped hover responsive>
                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell>Game</CTableHeaderCell>
                    <CTableHeaderCell>Round #</CTableHeaderCell>
                    <CTableHeaderCell>Status</CTableHeaderCell>
                    <CTableHeaderCell>Winner</CTableHeaderCell>
                    <CTableHeaderCell>Start Time</CTableHeaderCell>
                    <CTableHeaderCell>End Time</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {stats.recentRounds.slice(0, 10).map(round => (
                    <CTableRow key={round._id}>
                      <CTableDataCell>{round._id.slice(4, 8) === '96d1' ? 'Andar Bahar' : 
                                      round._id.slice(4, 8) === '68c4' ? 'Dragon Tiger' : 
                                      round._id.slice(4, 8) === 'acae' ? 'Lucky 7' : 
                                      'Other'}</CTableDataCell>
                      <CTableDataCell>{round.roundNumber}</CTableDataCell>
                      <CTableDataCell>
                        <span className={`badge bg-${round.status === 'result' ? 'success' : 
                                        round.status === 'accepting_bets' ? 'info' : 
                                        'warning'}`}>
                          {round.status.replace(/_/g, ' ').toUpperCase()}
                        </span>
                      </CTableDataCell>
                      <CTableDataCell>
                        {round.winner ? 
                          (typeof round.winner === 'string' ? round.winner.toUpperCase() : `Player ${round.winner}`) : 
                          'Pending'}
                      </CTableDataCell>
                      <CTableDataCell>{new Date(round.createdAt).toLocaleString()}</CTableDataCell>
                      <CTableDataCell>
                        {round.resultTime ? new Date(round.resultTime).toLocaleString() : 
                         round.updatedAt ? new Date(round.updatedAt).toLocaleString() : 
                         'In Progress'}
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  )
}

WidgetsDropdown.propTypes = {
  className: PropTypes.string,
}

export default WidgetsDropdown