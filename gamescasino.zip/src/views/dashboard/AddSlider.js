import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';
import {
  CAvatar,
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CFormTextarea,
  CInputGroup,
  CInputGroupText,
  CRow,

} from '@coreui/react';

const AddSlider = () => {
  const [formData, setFormData] = useState({
    image: null,
    name: '',
    status: '',
    slug: '',
    description: '',
  });

  const [previewImage, setPreviewImage] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [gameCategory, setGameCategory] = useState([]);
  const isLoading = useRef(false);
  const user_id = localStorage.getItem("user_id");

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle image upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setPreviewImage(URL.createObjectURL(file));
    }
  };


  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const data = new FormData();
      data.append('image', formData.image);
      data.append('user_id', user_id);

      const response = await axios.post('https://apicolorgame.a2logicgroup.com/api/admin/create-slider', data);

      if (response.data.success) {
        setMessage('Slider Added successfully!');
        setFormData({ image: null, });
        setPreviewImage('');
      } else {
        setMessage(response.data.message || 'Something went wrong.');
      }
    } catch (error) {
      console.error('Error creating slider:', error.message);
      setMessage('Failed to create slider. Please try again.');
    } finally {
      setLoading(false);
    }
  };



  return (
<>
    <CRow>
      <CCol xs>
        <CCard className="mb-4">
          <CCardBody>
            <CForm onSubmit={handleSubmit} encType="multipart/form-data">
              <CRow>
                {/* Image Upload Field */}
                <CCol xs={12} md={6}>
                  <CFormLabel htmlFor="imageUpload">Upload Image</CFormLabel>
                  <CInputGroup>
                    <CInputGroupText>Image</CInputGroupText>
                    <CFormInput
                      type="file"
                      id="imageUpload"
                      name="image"
                      onChange={handleImageChange}
                      required
                    />
                  </CInputGroup>
                  {previewImage && (
                    <CAvatar src={previewImage} size="lg" className="mt-2" />
                  )}
                </CCol>
                <CCol xs={12} md={6} className="text-center mt-4">
                  <CButton type="submit" color="primary" disabled={loading}>
                    {loading ? 'Submitting...' : 'Submit'}
                  </CButton>
                </CCol>
              </CRow>
              {message && (
                <CRow className="mt-3">
                  <CCol xs={12} className="text-center">
                    <div
                      style={{
                        color: message.includes('successfully') ? 'green' : 'red',
                        fontWeight: 'bold',
                      }}
                    >
                      {message}
                    </div>
                  </CCol>
                </CRow>
              )}
            </CForm>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
    </>
  );
};

export default AddSlider;
