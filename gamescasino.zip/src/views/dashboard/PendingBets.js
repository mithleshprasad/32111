import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CRow,
    CTable,
    CTableBody,
    CTableDataCell,
    CTableHead,
    CTableHeaderCell,
    CTableRow,
} from '@coreui/react';
import { IoIosClock } from "react-icons/io";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
const Category = (data) => {
    const [loading, setLoading] = useState(false);
    const [bets, setBets] = useState([]);
    const [selectedColor, setSelectedColor] = useState(null);
    const [userBetData, setGameSubCategory] = useState(null);
    const [userBetData1, setUserBetData] = useState(null);
    const user_id = localStorage.getItem("user_id");
    const category_slug = localStorage.getItem("Category_slug");
    const subcategory_slug = localStorage.getItem("subcat_slug");
    const intervalM = localStorage.getItem("selectedInterval");
    const isLoading = useRef(false);
    const startTimeRef = useRef(Math.floor(new Date(data.startTime).getTime() / 1000));
    const [scopeValues, setScopeValues] = useState([]);
    const [betMultipleValues, setBetMultipleValues] = useState([]);
    const [selectedInterval, setSelectedInterval] = useState(null);
    const [remainingSec, setRemainingSec] = useState(0);
    const [periodId, setPeriodId] = useState(0);
    const [users, setUsers] = useState([]);
    const [showFiveSecondsLeft, setShowFiveSecondsLeft] = useState(false);
    const [popupRemainingSec, setPopupRemainingSec] = useState(0);
    const [selectedTab, setSelectedTab] = useState(null);

    useEffect(() => {
        if (!isLoading.current) {
            if (intervalM) {
                fetchData(intervalM);
            }
            fetchSuperCat();
            // fetchcolorlistAndCompareResults(intervalM);
            // fetchResults(intervalM);
            // fetchColorList(intervalM);
        }
    }, [intervalM, category_slug, subcategory_slug]);

    const fetchSuperCat = async () => {
        try {
            isLoading.current = true;
            setLoading(true);

            const url = "https://apicolorgame.a2logicgroup.com/api/admin/game-super-sub-category-list";

            const config = {
                method: "POST",
                url: url,
                headers: {
                    "Content-Type": "application/json",
                },
                data: { user_id }, // Ensure user_id is passed properly
            };

            const response = await axios(config);

            if (response.data?.success && Array.isArray(response.data.data)) {
                setGameSubCategory(response.data.data);
                setUserBetData(response.data.data);
                console.log("Fetched data:", response.data.data);

                if (response.data.data.length > 0) {
                    const firstItem = response.data.data[0];

                    const scopes = firstItem.scope.split("|").map(Number);
                    const betMultiples = firstItem.betMultiple.split("|").map(Number);

                    localStorage.setItem("super_sub_cat_name", firstItem.typeName);
                    localStorage.setItem("super_sub_cat_slug", firstItem.slug);
                    localStorage.setItem("intervalM", String(firstItem.intervalM)); // Ensure stored as string
                    localStorage.setItem("typeID", String(firstItem.typeID));

                    setScopeValues(scopes);
                    setBetMultipleValues(betMultiples);
                }
            } else {
                console.error("Unexpected response structure:", response.data);
            }
        } catch (error) {
            console.error("Error fetching user data:", error);
        } finally {
            isLoading.current = false;
            setLoading(false);
        }
    };

    useEffect(() => {
        if (!isLoading.current) {
            if (intervalM) {
                fetchData(intervalM);
            }
            fetchSuperCat();
            // fetchcolorlistAndCompareResults(intervalM);
            //   fetchResults(intervalM);
            //   fetchColorList(intervalM);
        }
    }, [intervalM, category_slug, subcategory_slug]);

    /****************************************************************************/

    const fetchData = async (intervalM) => {
        try {
            isLoading.current = true;
            const url = `https://apicolorgame.a2logicgroup.com/api/admin/color-Game-Issue`;

            setLoading(true);
            const config = {
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': 'application/json',
                },
                data: { intervalM },
            };

            const response = await axios(config);
            setUsers(response.data.data);
            const { issueNumber, startTime, endTime, remainingTime } = response.data.data;
            setPeriodId(issueNumber);
            setRemainingSec(remainingTime);
            //   console.log("Remaining Time:", startTime, endTime, remainingTime);
            // Update local storage with the start time
            const startTimestamp = Math.floor(new Date(startTime).getTime() / 1000);
            const endTimestamp = Math.floor(new Date(endTime).getTime() / 1000);
            localStorage.setItem('startTime', startTimestamp);
            console.log('Start Time:', startTimestamp, 'End Time:', endTimestamp);
            updateRemainingTime(startTimestamp, endTimestamp, remainingTime);

            isLoading.current = false;
            setLoading(false);
        } catch (error) {
            isLoading.current = false;
            console.error('Error fetching user data:', error);
            setLoading(false);
        }
    };

    const formatTime = (seconds) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        const formattedMins = mins.toString().padStart(2, '0');
        const formattedSecs = secs.toString().padStart(2, '0');
        // console.log(formattedMins, formattedSecs);
        return `${formattedMins}:${formattedSecs}`;
    };

    const updateRemainingTime = (startTime, endTime, remainingTime) => {
        setRemainingSec(remainingTime);

        // Trigger popup if 5 seconds are remaining
        if (remainingTime === 5 && remainingTime > 0) {
            setShowFiveSecondsLeft(true);
            setPopupRemainingSec(5);
            //   setShowPopup(true);
            setIsopen(false);
        }

        if (remainingTime === 0) {
            setTimeout(() => {
                // setShowPopup(false);
                setShowFiveSecondsLeft(false);
                // console.log('Remaining Time:', remainingTime);
                // console.log('Is Bet Placed Successfully:', isBetPlacedSuccessfully);

                // if (isBetPlacedSuccessfully) {
                //   console.log("Bet placed successfully. Fetching color list and results...");

                //    fetchcolorlistAndCompareResults();
                // } else {
                //   console.log("Bet not placed successfully. Not calling fetchcolorlistAndCompareResults.");
                // }
                // fetchcolorlistAndCompareResults(intervalM);
                // fetchColorList(intervalM);
                if (!isLoading.current) {
                    //   fetchResults(intervalM);
                }
                fetchData(selectedInterval);
            }, 1000);
        }
    };

    // Timer to update remaining time every second
    useEffect(() => {
        const timer = setInterval(() => {
            const storedStartTime = parseInt(localStorage.getItem('startTime'), 10);
            const intervalSec = selectedInterval * 60;

            if (storedStartTime) {
                const endTime = storedStartTime + intervalSec;
                const remainingTime = Math.max(0, endTime - Math.floor(Date.now() / 1000));

                updateRemainingTime(storedStartTime, endTime, remainingTime);
            }
        }, 1000);

        return () => clearInterval(timer);
    }, [selectedInterval]);

    // Popup countdown
    //   useEffect(() => {
    //     if (showPopup) {
    //       const popupTimer = setInterval(() => {
    //         setPopupRemainingSec((prevPopupSec) => {
    //           if (prevPopupSec > 1) {
    //             return prevPopupSec - 1;
    //           } else {
    //             clearInterval(popupTimer);
    //             setShowPopup(false);
    //             return 0;
    //           }
    //         });
    //       }, 1000);

    //       return () => clearInterval(popupTimer);
    //     }
    //   }, [showPopup]);


    useEffect(() => {
        if (userBetData && userBetData.length > 0) {
            const intervalM = userBetData[0].intervalM;
            const typeID = userBetData[0].typeID;
            setSelectedInterval(intervalM);
            localStorage.setItem("selectedInterval", intervalM);
            console.log("Selected Interval:", intervalM);
            //   setSelectedTypeID(typeID);
            startTimeRef.current = Math.floor(Date.now() / 1000);
        }
    }, [userBetData]);

    useEffect(() => {
        if (userBetData && userBetData.length > 0) {
            setSelectedTab(Number(userBetData[0].intervalM)); // Set first tab as active
        }
    }, [userBetData]);

    const handleTabClick = (intervalM, typeID) => {
        setSelectedInterval(intervalM);
        fetchData(intervalM);
        fetchPendingBets(intervalM);
        setSelectedTab(intervalM);
        // if (!isLoading.current) {
        // fetchResults(intervalM);
        // fetchColorList(intervalM);
        // fetchcolorlistAndCompareResults(intervalM);
        // }
        if (!startTimeRef.current) {
            startTimeRef.current = Math.floor(Date.now() / 1000);
            localStorage.setItem('startTime', startTimeRef.current);
        }
    };

    // Fetch pending bets from API
    const fetchPendingBets = async (intervalM) => {
        try {
            setLoading(true);
            const url = `https://apicolorgame.a2logicgroup.com/api/admin/pending-bet-list`;
            const response = await axios.post(url, { user_id, category_slug, subcategory_slug, type: 1 });
console.log("ddf",response.data.data);
            if (response.data?.success === "1" && Array.isArray(response.data?.data)) {
                // Filter bets matching the selected intervalM
                const filteredBets = response.data.data.filter(
                    (bet) => Number(bet.game_type_time) === intervalM // Match intervalM with game_type_time
                );
                setBets(filteredBets);
            } else {
                setBets([]);
            }
        } catch (error) {
            console.error("Error fetching pending bets:", error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleBigsmallButtonClick = (name, color) => {
        setBigsmallAndColorInLocalStorage(name);
        // setSelectedName(name);
        // Togglepopup();
        handleButtonClick(name);
        // toggleClassamtcolor(1, color);
        setLastButtonClicked("big_small");
    };


    useEffect(() => {
        fetchPendingBets();
    }, [user_id, category_slug, subcategory_slug]);

    // Ball numbers with colors
    const balls = [
        { number: "0", colorName: "red violet", color: "linear-gradient(to right, violet, #fd565c)" },
        { number: "1", color: "green" },
        { number: "2", color: "red" },
        { number: "3", color: "green" },
        { number: "4", color: "red" },
        { number: "5", colorName: "green violet", color: "linear-gradient(to right, #40ad72, violet)" },
        { number: "6", color: "red" },
        { number: "7", color: "green" },
        { number: "8", color: "red" },
        { number: "9", color: "green" },
    ];

    const bigsmall = [
        { name: "Big", color: "#feaa57" }, //rgb(64, 157, 173)
        { name: "Small", color: "#6ea8f4" }, // #fd565c
    ];

    const normalizeColor = (color) => {
        if (color.includes("linear-gradient")) {
            if (color.includes("violet, #fd565c")) return "red violet";
            if (color.includes("#40ad72, violet")) return "green violet";
        }
        return color;
    };


    const selectColors = [
        { name: "Green", color: "green" },
        { name: "Violet", color: "violet" },
        { name: "Red", color: "red" },
    ];
    return (
        <>
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            <h4 className="d-inline">Pending Bet List</h4>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {/* Tabs Section */}
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            <Tabs>
                                <TabList className="d-flex justify-content-between pl-0  rounded p-1 list-unstyled">
                                    {userBetData &&
                                        userBetData
                                            .sort((a, b) => Number(a.intervalM) - Number(b.intervalM))
                                            .map((bet, index) => ( 
                                                <Tab
                                                    key={index}
                                                    onClick={() => handleTabClick(Number(bet.intervalM))}
                                                    className={`tab-item ${selectedTab === Number(bet.intervalM) ? "active-tab" : ""}`}
                                                >
                                                    <div className="tabs_windgo">
                                                        <div className="d-flex justify-content-center align-items-center icon_rounded">
                                                            <IoIosClock size={50} />
                                                        </div>
                                                        <p>
                                                            Win Go <span>{bet.intervalM} Min</span>
                                                        </p>
                                                    </div>
                                                </Tab>
                                            ))}
                                </TabList>
                            </Tabs>

                            {/* Color Selection Buttons */}
                            <div className="d-flex align-items-center justify-content-between mt-5">
                                <div className="d-flex gap-2">
                                    {selectColors.map((item, index) => {
                                        const matchingBet = bets.find(
                                            (bet) => bet.color === item.name
                                        );

                                        return (
                                            <button
                                                key={index}
                                                className={`button_color_game position-relative  ${selectedColor === item.color ? "selected" : ""}`}
                                                style={{ backgroundColor: item.color, color: "#fff", fontWeight: "bold" , margin:'10px'}}
                                                // onClick={() => setSelectedColor(item.color)}
                                            >
                                                {item.name}
                                                {matchingBet && (
                                                    <span
                                                        style={{
                                                            position: "absolute",
                                                            bottom: "-20px",
                                                            left: "50%",
                                                            transform: "translateX(-50%)",
                                                            fontSize: "12px",
                                                            color: "#fff",
                                                            background: "rgba(0,0,0,0.5)",
                                                            padding: "2px 5px",
                                                            borderRadius: "3px",
                                                       
                                                        }}
                                                    >
                                                        ₹{matchingBet.amount}
                                                    </span>
                                                )}
                                            </button>
                                        );
                                    })}
                                </div>


                                <div className="d-flex align-items-center justify-content-evenly mt-1">
                                    {bigsmall.map((item, index) => {
                                        const matchingBet = bets.find((bet) => bet.big_small === item.name);

                                        return (
                                            <button
                                                key={index}
                                                onClick={() => handleBigsmallButtonClick(item.name, item.color)}
                                                className="button_color_big_small position-relative"
                                                style={{ backgroundColor: item.color }}
                                            >
                                                {item.name}
                                                {matchingBet && (
                                                    <span
                                                        style={{
                                                            position: "absolute",
                                                            bottom: "-20px",
                                                            left: "50%",
                                                            transform: "translateX(-50%)",
                                                            fontSize: "12px",
                                                            color: "#fff",
                                                            background: "rgba(0,0,0,0.5)",
                                                            padding: "2px 5px",
                                                            borderRadius: "3px",
                                                                 margin: "10px",
                                                        }}
                                                    >
                                                        ₹{matchingBet.amount}
                                                    </span>
                                                )}
                                            </button>
                                        );
                                    })}
                                </div>

                                <div className="timer">
                                    <span>{formatTime(remainingSec)} Time Remaining</span><br></br>
                                    <span>{periodId}</span>
                                    
                                </div>
                            </div>

                            {/* Color Number Buttons with Amount */}
                            <div className="d-flex justify-content-between flex-wrap gap-2 mt-5">
                                {balls
                                    .filter((item) => !selectedColor || item.color === selectedColor)
                                    .map((item, index) => {
                                        const matchingBet = bets.find(
                                            (bet) =>
                                                bet.number == item.number &&
                                                Number(bet.game_type_time) === selectedInterval && // Match interval
                                                normalizeColor(bet.color) === normalizeColor(item.color)
                                        );

                                        return (
                                            <button
                                                key={index}
                                                className="button_color_game_number"
                                                style={{
                                                    background: item.color,
                                                    position: "relative",
                                                    padding: "10px 31px",
                                                    borderRadius: "5px",
                                                    color: "white",
                                                    fontWeight: "bold",
                                                    minWidth: "50px",
                                                }}
                                            >
                                                {item.number}
                                                {matchingBet && (
                                                    <span
                                                        style={{
                                                            position: "absolute",
                                                            bottom: "-20px",
                                                            left: "50%",
                                                            transform: "translateX(-50%)",
                                                            fontSize: "12px",
                                                            color: "#fff",
                                                            background: "rgba(0,0,0,0.5)",
                                                            padding: "2px 5px",
                                                            borderRadius: "3px",
                                                        }}
                                                    >
                                                        ₹{matchingBet.amount}
                                                    </span>
                                                )}
                                            </button>
                                        );
                                    })}
                            </div>


                            {/* <div className="d-flex justify-content-end mt-5">
                                {selectedColor && (
                                    (() => {
                                        // Find all matching bets for the selected color
                                        const totalAmount = bets
                                            .filter((bet) => bet.color === selectedColor)
                                            .reduce((sum, bet) => sum + (bet.amount || 0), 0);

                                        return totalAmount > 0 ? (
                                            <span
                                                style={{
                                                    fontSize: "18px",
                                                    fontWeight: "bold",
                                                    color: "#fff",
                                                    background: "rgba(0,0,0,0.5)",
                                                    padding: "5px 10px",
                                                    borderRadius: "5px",
                                                }}
                                            >
                                                Total ₹{totalAmount} for {selectedColor}
                                            </span>
                                        ) : null;
                                    })()
                                )}
                            </div> */}
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {/* Pending Bets Table */}
            <CRow className="mt-1">
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            {loading ? (
                                <p>Loading...</p>
                            ) : (
                                <CTable align="middle" className="mb-0 border" hover responsive>
                                    <CTableHead className="text-nowrap">
                                        <CTableRow>
                                            <CTableHeaderCell className="text-center">Period Id</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Game Type Time</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Color</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Number</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Big Small</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Quantity</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Amount</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Status</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">DateTime</CTableHeaderCell>
                                            <CTableHeaderCell className="text-center">Result</CTableHeaderCell>
                                        </CTableRow>
                                    </CTableHead>

                                    <CTableBody>
                                        {bets.map((item, index) => (
                                            <CTableRow key={index}>
                                                <CTableDataCell className="text-center">{item.period_id}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.game_type_time}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.color || "-"}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.number || "-"}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.big_small || "-"}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.quantity}</CTableDataCell>
                                                <CTableDataCell className="text-center">₹{item.amount}</CTableDataCell>
                                                <CTableDataCell className="text-center">
                                                    <span style={{ color: "orange" }}>Pending</span>
                                                </CTableDataCell>
                                                <CTableDataCell className="text-center">{item.datetime}</CTableDataCell>
                                                <CTableDataCell className="text-center">{item.result || "-"}</CTableDataCell>
                                            </CTableRow>
                                        ))}
                                    </CTableBody>
                                </CTable>
                            )}
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    );
};

export default Category;
