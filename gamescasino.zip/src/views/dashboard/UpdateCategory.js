import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import {
  CAvatar,
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CFormTextarea,
  CInputGroup,
  CInputGroupText,
  CRow,
} from "@coreui/react";

const UpdateCategory = () => {
  const { slug } = useParams(); // Get slug from URL
  const [formData, setFormData] = useState({
    image: null,
    name: "",
    status: "",
    description: "",
  });

  const [previewImage, setPreviewImage] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const user_id = localStorage.getItem("user_id");

  // Fetch category data when component mounts
  useEffect(() => {
    const fetchCategoryData = async () => {
      try {
        const response = await axios.get(
          `https://apicolorgame.a2logicgroup.com/api/admin/edit-category/${slug}`
        );

        if (response.data.success === "1") {
          const { name, status, description, image } = response.data.data;
          const imageUrl = image ? `https://apicolorgame.a2logicgroup.com/${image}` : "";

          setFormData({ name, status, description, image: imageUrl });
          setPreviewImage(imageUrl);
        } else {
          setMessage(response.data.message || "Category not found.");
        }
      } catch (error) {
        console.error("Error fetching category:", error.response?.data || error.message);
        setMessage("Error fetching category data.");
      }
    };

    fetchCategoryData();
  }, [slug]);

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle image upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const data = new FormData();
      
      // Append only if a new image is selected
      if (formData.image && formData.image instanceof File) {
        data.append("image", formData.image);
      }

      data.append("status", formData.status);
      data.append("description", formData.description);
      data.append("user_id", user_id);

      const response = await axios.put(
        `https://apicolorgame.a2logicgroup.com/api/admin/update-category/${slug}`,
        data,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (response.data.success === "1") {
        setMessage("Category updated successfully!");
      } else {
        setMessage(response.data.message || "Something went wrong.");
      }
    } catch (error) {
      console.error("Error updating category:", error.response?.data || error.message);
      setMessage("Failed to update category. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <CRow>
      <CCol xs>
        <CCard className="mb-4">
          <CCardBody>
            <CForm onSubmit={handleSubmit} encType="multipart/form-data">
              <CRow>
                {/* Image Upload Field */}
                <CCol xs={12} md={6}>
                  <CFormLabel htmlFor="imageUpload">Upload Image</CFormLabel>
                  <CInputGroup>
                    <CInputGroupText>Image</CInputGroupText>
                    <CFormInput
                      type="file"
                      id="imageUpload"
                      name="image"
                      accept="image/*"
                      onChange={handleImageChange}
                    />
                  </CInputGroup>
                  {previewImage && (
                    <CAvatar src={previewImage} size="lg" className="mt-2" />
                  )}
                </CCol>

                {/* Name Field (Disabled) */}
                <CCol xs={12} md={6}>
                  <CFormLabel htmlFor="name">Name</CFormLabel>
                  <CFormInput
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    disabled
                  />
                </CCol>

                {/* Status Field */}
                <CCol xs={12} md={6} className="mt-3">
                  <CFormLabel htmlFor="status">Status</CFormLabel>
                  <CFormSelect
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                  </CFormSelect>
                </CCol>

                {/* Description Field */}
                <CCol xs={12} className="mt-3">
                  <CFormLabel htmlFor="description">Description</CFormLabel>
                  <CFormTextarea
                    id="description"
                    rows="4"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    required
                  ></CFormTextarea>
                </CCol>
              </CRow>

              {/* Submit Button */}
              <CRow className="mt-4">
                <CCol xs={12} className="text-center">
                  <CButton type="submit" color="primary" disabled={loading}>
                    {loading ? "Updating..." : "Update"}
                  </CButton>
                </CCol>
              </CRow>

              {/* Success/Error Message */}
              {message && (
                <CRow className="mt-3">
                  <CCol xs={12} className="text-center">
                    <div
                      style={{
                        color: message.includes("successfully") ? "green" : "red",
                        fontWeight: "bold",
                      }}
                    >
                      {message}
                    </div>
                  </CCol>
                </CRow>
              )}
            </CForm>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default UpdateCategory;
