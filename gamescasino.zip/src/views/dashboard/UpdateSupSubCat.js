import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CForm,
    CFormInput,
    CFormLabel,
    CFormSelect,
    CRow,
} from "@coreui/react";

const UpdateSupSubCat = () => {
    const { slug } = useParams();
    const [formData, setFormData] = useState({
        status: "",
        typeName: "",
        typeID: "",
        sub_cat_slug: "",
        betMultiple: "",
        intervalM: "",
        scope: "",
    });

    const [message, setMessage] = useState("");
    const [loading, setLoading] = useState(false);
    const user_id = localStorage.getItem("user_id");

    // Fetch category data on component mount
    useEffect(() => {
        const fetchCategoryData = async () => {
            try {
                const response = await axios.get(
                    `https://apicolorgame.a2logicgroup.com/api/admin/edit-Supsubcategory/${slug}`
                );

                if (response.data.success) {
                    setFormData(response.data.data);
                } else {
                    setMessage(response.data.message || "Category not found.");
                }
            } catch (error) {
                console.error("Error fetching category:", error.response?.data || error.message);
                setMessage("Error fetching category data.");
            }
        };

        fetchCategoryData();
    }, [slug]);

    // Handle input change
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setMessage("");

        try {
            const response = await axios.put(
                `https://apicolorgame.a2logicgroup.com/api/admin/update-Supsubcategory/${slug}`,
                {
                    ...formData,
                    user_id,
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            );

            if (response.data.success === "1") {
                setMessage("Super Sub Category updated successfully!");
            } else {
                setMessage(response.data.message || "Something went wrong.");
            }
        } catch (error) {
            console.error("Error updating category:", error.response?.data || error.message);
            setMessage("Failed to update category. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <CRow>
            <CCol xs>
                <CCard className="mb-4">
                    <CCardBody>
                        <CForm onSubmit={handleSubmit}>
                            <CRow>
                                {/* Sub-Category Slug */}
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel>Sub-Category Slug</CFormLabel>
                                    <CFormInput type="text" name="sub_cat_slug" value={formData.sub_cat_slug} disabled />
                                </CCol>
                                {/* Type Name */}
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel>Type Name</CFormLabel>
                                    <CFormInput type="text" name="typeName" value={formData.typeName} disabled />
                                </CCol>
                                {/* Bet Multiple */}
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel>Bet Multiple</CFormLabel>
                                    <CFormInput type="text" name="betMultiple" value={formData.betMultiple} onChange={handleInputChange} />
                                </CCol>
                                {/* IntervalM */}
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel>Interval (Minutes)</CFormLabel>
                                    <CFormInput type="number" name="intervalM" value={formData.intervalM} onChange={handleInputChange} />
                                </CCol>
                                {/* Scope */}
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel>Scope</CFormLabel>
                                    <CFormInput type="text" name="scope" value={formData.scope} onChange={handleInputChange} />
                                </CCol>
                                {/* Type ID */}
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel>Type ID</CFormLabel>
                                    <CFormInput type="text" name="typeID" value={formData.typeID} onChange={handleInputChange} />
                                </CCol>
                                {/* Status */}
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel>Status</CFormLabel>
                                    <CFormSelect name="status" value={formData.status} onChange={handleInputChange} required>
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </CFormSelect>
                                </CCol>
                            </CRow>

                            {/* Submit Button */}
                            <CRow className="mt-4">
                                <CCol xs={12} className="text-center">
                                    <CButton type="submit" color="primary" disabled={loading}>
                                        {loading ? "Updating..." : "Update"}
                                    </CButton>
                                </CCol>
                            </CRow>
                            {message && (
                                <CRow className="mt-3">
                                    <CCol xs={12} className="text-center">
                                        <div style={{ color: message.includes("successfully") ? "green" : "red", fontWeight: "bold" }}>
                                            {message}
                                        </div>
                                    </CCol>
                                </CRow>
                            )}
                        </CForm>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    );
};

export default UpdateSupSubCat;
