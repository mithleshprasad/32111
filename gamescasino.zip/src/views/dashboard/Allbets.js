import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { CButton, CCard, CCardBody, CCol, CRow, CTable, CTableBody, CTableDataCell, CTableHead, CTableHeaderCell, CTableRow } from '@coreui/react';
import { RiArrowRightSLine, RiArrowLeftSLine } from "react-icons/ri";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEdit } from "react-icons/fa";
import { CBadge } from '@coreui/react';
const AllBets = (props) => {
  const [bets, setBets] = useState([]);
  const [loading, setLoading] = useState(false);
  const user_id = localStorage.getItem("user_id");
  const category_slug = localStorage.getItem("Category_slug");
  const subcategory_slug = localStorage.getItem("subcat_slug");


  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    fetchAllBets();
  }, [user_id, category_slug, subcategory_slug]);

  const fetchAllBets = async () => {
    try {
      setLoading(true);
      const url = `https://apicolorgame.a2logicgroup.com/api/admin/color-bet-list`;
      const response = await axios.post(url, { user_id, category_slug, subcategory_slug, type: 1 });

      if (response.data?.success && response.data.data) {
        setBets(response.data.data.list);
      }
    } catch (error) {
      console.error("Error fetching data:", error.message);
    } finally {
      setLoading(false);
    }
  };

  // Pagination Logic
  const totalPages = Math.ceil(bets.length / itemsPerPage);
  const currentBets = bets.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <>
      <CRow className="mt-4">
        <CCol xs>
          <CCard className="mb-4">
            <CCardBody>
              {loading ? (
                <p>Loading...</p>
              ) : (
                <>
                  <CTable align="middle" className="mb-0 border" hover responsive>
                    <CTableHead>
                      <CTableRow>
                        <CTableHeaderCell className="text-center">Period Id</CTableHeaderCell>
                        <CTableHeaderCell className="text-center">Game Type Time</CTableHeaderCell>
                        <CTableHeaderCell className="text-center">Color</CTableHeaderCell>
                        <CTableHeaderCell className="text-center">Number</CTableHeaderCell>
                        <CTableHeaderCell className="text-center">Quantity</CTableHeaderCell>
                        <CTableHeaderCell className="text-center">Amount</CTableHeaderCell>
                        <CTableHeaderCell className="text-center">Result</CTableHeaderCell>
                        <CTableHeaderCell className="text-center">DateTime</CTableHeaderCell>
                      </CTableRow>
                    </CTableHead>

                    <CTableBody>
                      {currentBets.map((item, index) => (
                        <CTableRow key={index}>
                          <CTableDataCell className="text-center">{item.period_id}</CTableDataCell>
                          <CTableDataCell className="text-center">{item.game_type_time}</CTableDataCell>
                          <CTableDataCell className="text-center">{item.color || "-"}</CTableDataCell>
                          <CTableDataCell className="text-center">{item.number || "-"}</CTableDataCell>
                          <CTableDataCell className="text-center">{item.quantity}</CTableDataCell>
                          <CTableDataCell className="text-center">₹{item.amount}</CTableDataCell>

                          <CTableDataCell className="text-center">
                            {item.result === "win" && <CBadge color="success">Win</CBadge>}
                            {item.result === "pending" && <CBadge color="warning">Pending</CBadge>}
                            {item.result === "loss" && <CBadge color="danger">Loss</CBadge>}
                          </CTableDataCell>
                          <CTableDataCell className="text-center">{item.datetime}</CTableDataCell>

                        </CTableRow>
                      ))}
                    </CTableBody>
                  </CTable>

                  {/* Pagination Controls */}
                  <div className="d-flex justify-content-between pagination-controls align-items-center mt-3">
                    <CButton color="warning" disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)}>
                      <RiArrowLeftSLine size={20} /> 
                    </CButton>

                    <span>Page {currentPage} of {totalPages}</span>

                    <CButton color="warning" disabled={currentPage === totalPages} onClick={() => setCurrentPage(currentPage + 1)}>
                       <RiArrowRightSLine size={20} />
                    </CButton>
                  </div>
                </>
              )}
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  );
};

export default AllBets;
