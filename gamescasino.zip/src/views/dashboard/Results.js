import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import {
    CAvatar,
    CButton,
    CCard,
    CCardBody,
    CCol,
    CRow,
    CTable,
    CTableBody,
    CTableDataCell,
    CTableHead,
    CTableHeaderCell,
    CTableRow,
} from "@coreui/react";
import CIcon from "@coreui/icons-react";
import { IoMdAdd } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEdit } from "react-icons/fa";
import { cilPeople } from "@coreui/icons";
import { RiArrowRightSLine, RiArrowLeftSLine } from "react-icons/ri";
const Results = () => {
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");
    const [totalPages, setTotalPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    const isLoading = useRef(false);
    const navigate = useNavigate();
    const user_id = localStorage.getItem("user_id");
    const intervalM = localStorage.getItem("selectedInterval");

    const fetchResults = async () => {
        if (!intervalM) {
            console.error("Interval is not set");
            return;
        }

        try {
            isLoading.current = true;
            setLoading(true);
            const url = "https://apicolorgame.a2logicgroup.com/api/admin/result-list";

            const response = await axios.post(url, {
                gametype: intervalM,
                page: currentPage,
                perpage: itemsPerPage,
            });

            if (response.data?.data) {
                setResults(response.data.data);
                setTotalPages(response.data.totalPages || 1);
            } else {
                setResults([]);
                console.warn("No data returned from API");
            }
        } catch (error) {
            console.error("Error fetching results:", error);
        } finally {
            isLoading.current = false;
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchResults();
    }, [currentPage]); // Re-fetch when current page changes

    const fetchDelete = async (slug) => {
        try {
            isLoading.current = true;
            setLoading(true);

            const url = `https://apicolorgame.a2logicgroup.com/api/admin/delete-category/${slug}`;

            const response = await axios.post(url, { user_id });

            if (response.data?.success === "1") {
                setMessage(response.data.message);
                fetchResults(); // Refresh the list after deletion
            } else {
                console.error("Unexpected response:", response.data);
            }
        } catch (error) {
            console.error("Error deleting category:", error.message);
        } finally {
            setLoading(false);
        }
    };

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    const handleEdit = (slug) => {
        navigate(`/UpdateCategory/${slug}`);
    };

    return (
        <>
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            <h4 className="d-inline">Result List</h4>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            <CTable align="middle" className="mb-0 border" hover responsive>
                                <CTableHead className="text-nowrap">
                                    <CTableRow>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">
                                            Period Id
                                        </CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">
                                            Number
                                        </CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">
                                            Big/Small
                                        </CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">
                                            Color
                                        </CTableHeaderCell>
                                   
                                    </CTableRow>
                                </CTableHead>

                                <CTableBody>
                                    {results.map((item, index) => (
                                        <CTableRow key={index}>
                                            {/* Period */}
                                            <CTableDataCell className="text-center">
                                                {item.periodid}
                                            </CTableDataCell>

                                            {/* Number with Color */}
                                            <CTableDataCell className="text-center">
                                                <span
                                                    className="gradient-text"
                                                    style={{
                                                        fontSize: "23px",
                                                        fontWeight: "bold",
                                                        color:
                                                            item.color &&
                                                                (item.color === "green violet" ||
                                                                    item.color === "red violet")
                                                                ? "transparent"
                                                                : item.color
                                                                    ? item.color.split(" ")[0]
                                                                    : "inherit",
                                                        backgroundImage:
                                                            item.color === "green violet"
                                                                ? "linear-gradient(180deg, #40ad72 51.48%, #b659fe 51.49%)"
                                                                : item.color === "red violet"
                                                                    ? "linear-gradient(180deg, #ff0000 51.48%, #b659fe 51.49%)"
                                                                    : "none",
                                                        WebkitBackgroundClip: "text",
                                                        backgroundClip: "text",
                                                    }}
                                                >
                                                    {typeof item.number === "number" ? item.number : "N/A"}
                                                </span>
                                            </CTableDataCell>

                                            {/* Big/Small */}
                                            <CTableDataCell className="text-center">
                                                {item.number >= 5 && item.number <= 9 ? "Big" : "Small"}
                                            </CTableDataCell>

                                            {/* Color Dots */}
                                            <CTableDataCell className="text-center">
                                                <div className="d-flex align-items-center justify-content-evenly">
                                                    {item.color?.split(" ").map((color, idx) => (
                                                        <span
                                                            key={idx}
                                                            className="w-2 h-2 rounded-full d-inline-block"
                                                            style={{ backgroundColor: color, width: "12px", height: "12px", margin: "0 3px", borderRadius: "50%" }}
                                                        ></span>
                                                    ))}
                                                </div>
                                            </CTableDataCell>

                                            {/* Actions */}
                                            
                                        </CTableRow>
                                    ))}

                                </CTableBody>
                            </CTable>
                                    <div className=" pagination-controls">
                                        <nav>
                                            <ul className="pagination m-0 d-flex align-items-center justify-content-between">
                                                {/* Previous Button */}
                                                <li className={`page-item ${currentPage === 1 ? "disabled" : ""}`}>
                                                    <CButton
                                                        color="light"
                                                        className="page-link d-flex align-items-center px-3 py-2 shadow-sm rounded"
                                                        onClick={() => paginate(currentPage - 1)}
                                                        disabled={currentPage === 1}
                                                    >
                                                        <RiArrowLeftSLine size={20} className="me-1" /> 
                                                    </CButton>
                                                </li>

                                                {/* Page Info */}
                                                <li className="page-item mx-3 ">
                                                    <span className="page-info  fs-6 text-light">
                                                        Page {currentPage} of {totalPages}
                                                    </span>
                                                </li>

                                                {/* Next Button */}
                                                <li className={`page-item ${currentPage === totalPages ? "disabled" : ""}`}>
                                                    <CButton
                                                        color="light"
                                                        className="page-link d-flex align-items-center px-3 py-2 shadow-sm rounded"
                                                        onClick={() => paginate(currentPage + 1)}
                                                        disabled={currentPage === totalPages}
                                                    >
                                                         <RiArrowRightSLine size={20} className="ms-1" />
                                                    </CButton>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>

            {/* Pagination controls */}

        </>
    );
};

export default Results;
