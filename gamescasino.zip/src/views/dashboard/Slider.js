import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import {
  CAvatar,
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CFormTextarea,
  CInputGroup,
  CInputGroupText,
  CRow,
  CTableRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,

} from '@coreui/react';
import { CIcon } from '@coreui/icons-react'
import { IoMdAdd } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEdit } from "react-icons/fa";

import {
  cilPeople,
} from '@coreui/icons'
import { Navigate } from 'react-router-dom';
const Category = () => {
  const [formData, setFormData] = useState({
    image: null,
    name: '',
    status: '',
    slug: '',
    description: '',
  });

  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [gameCategory, setGameCategory] = useState([]);
  const isLoading = useRef(false);
  const user_id = localStorage.getItem("user_id");


  const fetchDelete = async(id) => {
    try {
      isLoading.current = true;
      setLoading(true);
  
      const url = `https://apicolorgame.a2logicgroup.com/api/admin/delete-slider/${id}`;
  
      const config = {
        method: "POST",
        url: url,
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          user_id: user_id,
        },
      };
      const response = await axios(config);
  
      if (response.data?.success === "1") {
        setMessage(response.data.message);
        fetchSliderCategory();
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error fetching user data:", error.message);
    }
  }

  const fetchSliderCategory = async () => {
    try {
      isLoading.current = true;
      setLoading(true);

      const url = `https://apicolorgame.a2logicgroup.com/api/admin/get-slider-list`;

      const config = {
        method: "POST",
        url: url,
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          user_id: user_id,
        },
      };

      const response = await axios(config);

      if (response.data?.success === "1" && Array.isArray(response.data.data)) {
        setGameCategory(response.data.data);
        setSlug(response.data.data[0].slug);
        localStorage.setItem("slug", response.data.data[0].slug);
        console.log("Fetched Users:", response.data.data);
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error fetching user data:", error.message);
    } finally {
      isLoading.current = false;
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSliderCategory();
  }, []);


  return (
    <>

      <CRow>

        <CRow>
          <CCol xs>
            <CCard className="mb-4">
              <CCardBody>
                <h4 className="d-inline">Slider List</h4>
                <Link to="/AddSlider">
                <CButton color="primary" className="float-end">
                  <IoMdAdd className="me-2" />
                  Add Slider
                </CButton>
                </Link>
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>

        <CCol xs>
          <CCard className="mb-4">
            <CCardBody>
              <CTable align="middle" className="mb-0 border" hover responsive>
                <CTableHead className="text-nowrap">
                  <CTableRow>
                    {/* <CTableHeaderCell className="bg-body-tertiary text-center">
                    <CIcon icon={cilPeople} />
                  </CTableHeaderCell> */}
                    <CTableHeaderCell className="bg-body-tertiary text-center">
                      Image
                    </CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">
                      Status
                    </CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">Action</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {gameCategory.map((item, index) => (
                    <CTableRow key={index}>
                      {/* Avatar */}
                      <CTableDataCell className="text-center">
                        <img
                          className=''
                          style={{ width: "100px", height: "80px" }}
                          src={`${"https://apicolorgame.a2logicgroup.com"}/${item.image}` || "default-avatar.png"} />
                      </CTableDataCell>

                      {/* Status */}
                      <CTableDataCell className="text-center">
                        <span style={{ color: item.status === "1" ? "green" : "red" }}>
                          {item.status === "1" ? "Active" : "Inactive"}
                        </span>
                      </CTableDataCell>
                      <CTableDataCell className='text-center'>
                        {/* <Link to={`/AddSlider/${item._id}`}>
                          <CButton
                            color="primary"
                            size="sm"
                            className="me-2 text-white"
                          >
                            <IoMdAdd />
                          </CButton>
                        </Link> */}
                        <Link to={`/SliderUpdate/${item._id}`}>
                        <CButton
                          color="warning"
                          size="sm"
                          className="me-2 text-white"
                        // onClick={() => handleEdit(item._id)}
                        >
                          <FaEdit />
                        </CButton>
                        </Link>
                        <CButton
                          color="danger"
                          size="sm"
                          className="me-2 text-white"
                           onClick={() => fetchDelete(item._id)}
                        >
                          <RiDeleteBin6Line />
                        </CButton>

                      </CTableDataCell>

                    </CTableRow>
                  ))}
                </CTableBody>

              </CTable>
            </CCardBody>
          </CCard>
        </CCol>

      </CRow>

    </>
  );
};

export default Category;
