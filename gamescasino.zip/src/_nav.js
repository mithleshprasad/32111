import React from 'react'
import CIcon from '@coreui/icons-react'
import {
  cilSpeedometer,
  cilUser,
  cilListRich,
  cilPlaylistAdd,
  cilStorage

} from '@coreui/icons'
import { CNavGroup, CNavItem } from '@coreui/react'

const _nav = [
  {
    component: CNavItem,
    name: 'Dashboard',
    to: '/dashboard',
    icon: <CIcon icon={cilSpeedometer} customClassName="nav-icon" />,
    badge: {
      color: 'info',
      text: 'NEW',
    },
  },
  // {
  //   component: CNavGroup,
  //   name: 'User Management',
  //   icon: <CIcon icon={cilUser} customClassName="nav-icon" />,
  //   items: [
  //     {
  //       component: CNavItem,
  //       name: 'All Users',
  //       to: '/allUsers',
  //     },
  //     {
  //       component: CNavItem,
  //       name: 'Active Users',
  //       to: '/ActiveUsers',
  //     },
  //     {
  //       component: CNavItem,
  //       name: 'Inactive Users',
  //       to: '/InActiveUser',
  //     },
  //   ],
  // },
 {
  component: CNavGroup,
  name: 'Dragon Tiger',
  icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
  items: [
    {
      component: CNavItem,
      name: 'Bet History',
      to: '/BetHistory?game=dragontiger',
    },
    {
      component: CNavItem,
      name: 'Game History',
      to: '/GameHistory?game=dragontiger',
    }
  ],
},
{
  component: CNavGroup,
  name: '32 cards',
  icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
  items: [
    {
      component: CNavItem,
      name: 'Bet History',
      to: '/BetHistory?game=32card',
    },
    {
      component: CNavItem,
      name: 'Game History',
      to: '/GameHistory?game=32card',
    }
  ],
},
{
  component: CNavGroup,
  name: 'Lucky7',
  icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
  items: [
    {
      component: CNavItem,
      name: 'Bet History',
      to: '/BetHistory?game=lucky7',
    },
    {
      component: CNavItem,
      name: 'Game History',
      to: '/GameHistory?game=lucky7',
    }
  ],
},
{
  component: CNavGroup,
  name: 'Teen Patti',
  icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
  items: [
    {
      component: CNavItem,
      name: 'Bet History',
      to: '/BetHistory?game=teenpatti',
    },
    {
      component: CNavItem,
      name: 'Game History',
      to: '/GameHistory?game=teenpatti'
    }
  ],
},
{
  component: CNavGroup,
  name: 'Andar Bahar',
  icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
  items: [
    {
      component: CNavItem,
      name: 'Bet History',
      to: '/BetHistory?game=andarbahar',
    },
    {
      component: CNavItem,
      name: 'Game History',
      to: '/GameHistory?game=andarbahar',
    }
  ],
},
{
  component: CNavGroup,
  name: 'Muflis',
  icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
  items: [
    {
      component: CNavItem,
      name: 'Bet History',
      to: '/BetHistory?game=muflis',
    },
    {
      component: CNavItem,
      name: 'Game History',
      to: '/GameHistory?game=muflis',
    }
  ],
},
{
  component: CNavGroup,
  name: 'Chicken Road',
  icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
  items: [
    {
      component: CNavItem,
      name: 'Bet History',
      to: '/BetHistory?game=chickenroad',
    },
    {
      component: CNavItem,
      name: 'Game History',
      to: '/GameHistory?game=chickenroad',
    }
  ],
},
{
  component: CNavGroup,
  name: 'Roulette',
  icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
  items: [
    {
      component: CNavItem,
      name: 'Bet History',
      to: '/BetHistory?game=roulette',
    },
    {
      component: CNavItem,
      name: 'Game History',
      to: '/GameHistory?game=roulette',
    }
  ],
}
,
  // {
  //   component: CNavItem,
  //   name: 'Slider',
  //   to: '/slider',
  //   icon: <CIcon icon={cilStorage} customClassName="nav-icon" />,

  // },
]

export default _nav
