import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import {
  CAvatar,
  CButton,
  CCard,
  CCardBody,
  CCol,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react';
import { IoMdAdd } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEdit } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';

const Category = () => {
  const navigate = useNavigate();
  const [gameSubCategory, setGameSubCategory] = useState([]);
  const [subCategorySlug, setsubCatSlug] = useState('');
  const [loading, setLoading] = useState(false);
  const user_id = localStorage.getItem("user_id");
  const isLoading = useRef(false);
  const [message, setMessage] = useState('');

  const fetchGameSubCategory = async () => {
    try {
      setLoading(true);

      const url = `https://apicolorgame.a2logicgroup.com/api/admin/game-sub-category-list`;

      const response = await axios.post(url, { user_id });

      if (response.data?.success && Array.isArray(response.data.data)) {
        const subCategories = response.data.data[0]?.subCategories || [];
        setGameSubCategory(subCategories);

        if (subCategories.length > 0) {
          const firstSlug = subCategories[0].slug;
          setsubCatSlug(firstSlug);
          subCategories.forEach((subCategory) => {
            console.log("Slug:", subCategory.slug);
            localStorage.setItem("subcat_slug", subCategory.slug);
          });
        } else {
          console.warn("No subcategories available.");
        }
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error fetching data:", error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGameSubCategory();
  }, []);

  const fetchDelete = async (slug) => {
    try {
      setLoading(true);

      const url = `https://apicolorgame.a2logicgroup.com/api/admin/delete-subcategory/${slug}`;
      const config = {
        method: "POST",
        url: url,
        headers: { "Content-Type": "application/json" },
        data: { user_id },
      };

      const response = await axios(config);

      if (response.data?.success === "1") {
        setMessage(response.data.message);
        fetchGameSubCategory(); // Refresh the list after deletion
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error deleting subcategory:", error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (slug) => {
    navigate(`/UpdateSubCategory/${slug}`);
  };

  return (
    <>
      <CRow>
        <CCol xs>
          <CCard className="mb-4">
            <CCardBody>
              <h4 className="d-inline">Sub Category List</h4>
              <Link to="/AddSubCategory">
                <CButton color="primary" className="float-end">
                  <IoMdAdd className="me-2" />
                  Add Sub Category
                </CButton>
              </Link>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>

      <CRow>
        <CCol xs>
          <CCard className="mb-4">
            <CCardBody>
              {loading ? (
                <p>Loading...</p>
              ) : (
                <CTable align="middle" className="mb-0 border" hover responsive>
                  <CTableHead className="text-nowrap">
                    <CTableRow>
                      <CTableHeaderCell className="text-center">Image</CTableHeaderCell>
                      <CTableHeaderCell className="text-center">Name</CTableHeaderCell>
                      {/* <CTableHeaderCell className="text-center">Slug</CTableHeaderCell> */}
                      {/* <CTableHeaderCell className="text-center">Category Slug</CTableHeaderCell> */}
                      <CTableHeaderCell className="text-center">Description</CTableHeaderCell>
                      <CTableHeaderCell className="text-center">Status</CTableHeaderCell>
                      <CTableHeaderCell className="text-center">Actions</CTableHeaderCell>
                    </CTableRow>
                  </CTableHead>
                  <CTableBody>
                    {gameSubCategory.map((item) => (
                      <CTableRow key={item._id}>
                        {/* Avatar */}
                        <CTableDataCell className="text-center">
                          <CAvatar
                            size="md"
                            src={`${"https://apicolorgame.a2logicgroup.com"}/${item.image}` || "default-avatar.png"}
                          />
                        </CTableDataCell>

                        {/* Name */}
                        <CTableDataCell>
                          <div className="text-center">{item.name}</div>
                        </CTableDataCell>

                        {/* Slug */}
                        {/* <CTableDataCell>
                          <div className="text-center">{item.slug}</div>
                        </CTableDataCell>

                 
                        <CTableDataCell>
                          <div className="text-center">{item.category_slug}</div>
                        </CTableDataCell> */}

                        {/* Description */}
                        <CTableDataCell>
                          <div className="text-center">
                            <div dangerouslySetInnerHTML={{ __html: item.description }} />
                          </div>
                        </CTableDataCell>

                        {/* Status */}
                        <CTableDataCell className="text-center">
                          <span style={{ color: item.status === "1" ? "green" : "red" }}>
                            {item.status === "1" ? "Active" : "Inactive"}
                          </span>
                        </CTableDataCell>

                        {/* Actions */}
                        <CTableDataCell className="text-center">
                          <CButton 
                          color="warning" 
                          size="sm" 
                          className="me-2 text-white"
                          onClick={() => handleEdit(item.slug)}
                          >
                          <FaEdit />
                          </CButton>
                          <CButton
                            color="danger"
                            size="sm"
                            className="me-2 text-white"
                            onClick={() => fetchDelete(item.slug)}
                          >
                            <RiDeleteBin6Line />
                          </CButton>
                        </CTableDataCell>
                      </CTableRow>
                    ))}
                  </CTableBody>
                </CTable>
              )}
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  );
};

export default Category;
