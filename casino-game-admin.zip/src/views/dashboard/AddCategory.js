import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import {
  CAvatar,
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CFormTextarea,
  CInputGroup,
  CInputGroupText,
  CRow,
  CTableRow,
  
} from '@coreui/react';


import {
  cilPeople,
} from '@coreui/icons'
import { Navigate } from 'react-router-dom';
const Category = () => {
  const [formData, setFormData] = useState({
    image: null,
    name: '',
    status: '',
    // slug: '',
    description: '',
  });

  const [previewImage, setPreviewImage] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const user_id = localStorage.getItem("user_id");

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle image upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setPreviewImage(URL.createObjectURL(file));
    }
  };


  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const data = new FormData();
      data.append('image', formData.image);
      data.append('name', formData.name);
      data.append('status', formData.status);
      data.append('description', formData.description);
      data.append('user_id', user_id);

      const response = await axios.post('https://apicolorgame.a2logicgroup.com/api/admin/game-category', data);

      if (response.data.success) {
        setMessage('Category created successfully!');
        setFormData({ image: null, name: '', status: '', description: '' });
        setPreviewImage('');
      } else {
        setMessage(response.data.message || 'Something went wrong.');
      }
    } catch (error) {
      if (error.response && error.response.status === 400) {
        // Handle duplicate name error
        setMessage(error.response.data.message || 'Failed to create category. Please try again.');
      } else {
        setMessage('Failed to create category. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };


  // const handleAdd = () => {
  //   Navigate("/add-category");
  // };


  return (
<>
    <CRow>
      <CCol xs>
        <CCard className="mb-4">
          <CCardBody>
            <CForm onSubmit={handleSubmit} encType="multipart/form-data">
              <CRow>
                {/* Image Upload Field */}
                <CCol xs={12} md={6}>
                  <CFormLabel htmlFor="imageUpload">Upload Image</CFormLabel>
                  <CInputGroup>
                    <CInputGroupText>Image</CInputGroupText>
                    <CFormInput
                      type="file"
                      id="imageUpload"
                      name="image"
                      onChange={handleImageChange}
                      required
                    />
                  </CInputGroup>
                  {previewImage && (
                    <CAvatar src={previewImage} size="lg" className="mt-2" />
                  )}
                </CCol>

                {/* Name Field */}
                <CCol xs={12} md={6}>
                  <CFormLabel htmlFor="name">Name</CFormLabel>
                  <CFormInput
                    type="text"
                    id="name"
                    placeholder="Enter Name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                  />
                </CCol>

                {/* Status Field */}
                <CCol xs={12} md={6} className="mt-3">
                  <CFormLabel htmlFor="status">Status</CFormLabel>
                  <CFormSelect
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                  </CFormSelect>
                </CCol>

                {/* Slug Field */}
                {/* <CCol xs={12} md={6} className="mt-3">
                  <CFormLabel htmlFor="slug">Slug</CFormLabel>
                  <CFormInput
                    type="text"
                    id="slug"
                    placeholder="Enter Slug"
                    name="slug"
                    value={formData.slug}
                    onChange={handleInputChange}
                    required
                  />
                </CCol> */}

                {/* Description Field */}
                <CCol xs={12} className="mt-3">
                  <CFormLabel htmlFor="description">Description</CFormLabel>
                  <CFormTextarea
                    id="description"
                    rows="4"
                    placeholder="Enter Description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    required
                  ></CFormTextarea>
                </CCol>
              </CRow>

              {/* Submit Button */}
              <CRow className="mt-4">
                <CCol xs={12} className="text-center">
                  <CButton type="submit" color="primary" disabled={loading}>
                    {loading ? 'Submitting...' : 'Submit'}
                  </CButton>
                </CCol>
              </CRow>

              {/* Success/Error Message */}
              {message && (
                <CRow className="mt-3">
                  <CCol xs={12} className="text-center">
                    <div
                      style={{
                        color: message.includes('successfully') ? 'green' : 'red',
                        fontWeight: 'bold',
                      }}
                    >
                      {message}
                    </div>
                  </CCol>
                </CRow>
              )}
            </CForm>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
    </>
  );
};

export default Category;
