import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CForm,
    CFormInput,
    CFormLabel,
    CFormSelect,
    CRow,
} from '@coreui/react';

const SuperSubCategory = () => {
    const [formData, setFormData] = useState({
        name: '',
        status: '',
        // slug: '',
        betMultiplie: '',
        intervalM: '',
        scope: '',
        cat_slug: '',
        sub_cat_slug: '',
        typeID: '',
    });

    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState('');
    const [categorySlugList, setCategorySlugList] = useState([]);
    const [subcategorySlugList, setSubCategorySlugList] = useState([]);

    const user_id = localStorage.getItem('user_id');
    const cat_slug = localStorage.getItem("Category_slug");
    const sub_cat_slug = localStorage.getItem("subcat_slug");
    // alert(sub_cat_slug);

    // Handle input change
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    // Fetch category and subcategory slug lists
    useEffect(() => {
        axios
            .post('https://apicolorgame.a2logicgroup.com/api/admin/game-category-name-list', { user_id: user_id })
            .then((response) => {
                if (response.data.success === '1') {
                    setCategorySlugList(response.data.categorySlugList);
                    setSubCategorySlugList(response.data.subCategorySlugList);
                }
            })
            .catch((error) => {
                console.error('Error fetching category data:', error);
            });
    }, []);

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setMessage('');

        try {
            // Prepare the data object with the correct format
            const data = {
                user_id: user_id,
                betMultiple: formData.betMultiplie.split(',').join('|'), // Convert comma-separated to pipe-separated
                intervalM: formData.intervalM,
                scope: formData.scope.split(',').join('|'), // Convert comma-separated to pipe-separated
                typeName: formData.name,
                cat_slug: cat_slug,
                sub_cat_slug: formData.sub_cat_slug,
                status: formData.status,
                // slug: formData.slug,
                typeID: formData.typeID,
            };

            // Send API request
            const response = await axios.post(
                'https://apicolorgame.a2logicgroup.com/api/admin/game-super-sub-category',
                data
            );
            if (response.data.success) {
                setMessage('Category created successfully!');
                setFormData({
                    name: '',
                    status: '',
                    // slug: '',
                    betMultiplie: '',
                    intervalM: '',
                    scope: '',
                    cat_slug: '',
                    sub_cat_slug: '',
                    typeID: '',
                });
            } else {
                setMessage(response.data.message || 'Something went wrong.');
            }
        } catch (error) {
            if (error.response && error.response.status === 400) {
                setMessage(error.response.data.message || 'Failed to create super sub category. Please try again.');
              } else {
                setMessage('Failed to super sub create category. Please try again.');
              }
        } finally {
            setLoading(false);
        }
    };

    return (
        <CRow>
            <CCol xs>
                <CCard className="mb-4">
                    <CCardBody>
                        <CForm onSubmit={handleSubmit}>
                            <CRow>
                            {/* <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel htmlFor="cat_slug">Category Slug</CFormLabel>
                                    <CFormSelect
                                        id="cat_slug"
                                        name="cat_slug"
                                        value={formData.cat_slug}
                                        onChange={handleInputChange}
                                    >
                                        <option value="">Select Category Slug</option>
                                        {categorySlugList.map((slug, index) => (
                                            <option key={index} value={slug}>
                                                {slug}
                                            </option>
                                        ))}
                                    </CFormSelect>
                                </CCol> */}
                            <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel htmlFor="sub_cat_slug">Sub Category Slug</CFormLabel>
                                    <CFormSelect
                                        id="sub_cat_slug"
                                        name="sub_cat_slug"
                                        value={formData.sub_cat_slug}
                                        onChange={handleInputChange}
                                    >
                                        <option value="">Select Sub Category Slug</option>
                                        {subcategorySlugList.map((slug, index) => (
                                            <option key={index} value={slug}>
                                                {slug}
                                            </option>
                                        ))}
                                    </CFormSelect>
                                </CCol>
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel htmlFor="name">Type Name</CFormLabel>
                                    <CFormInput
                                        id="name"
                                        name="name"
                                        value={formData.name}
                                        onChange={handleInputChange}
                                        placeholder="Enter type name"
                                    />
                                </CCol>
                                <CCol xs={12} md={6}>
                                    <CFormLabel htmlFor="betMultiplie">Bet Multiple</CFormLabel>
                                    <CFormInput
                                        id="betMultiplie"
                                        name="betMultiplie"
                                        value={formData.betMultiplie}
                                        onChange={handleInputChange}
                                        placeholder="Enter comma-separated values"
                                    />
                                </CCol>
                                <CCol xs={12} md={6}>
                                    <CFormLabel htmlFor="intervalM">IntervalM</CFormLabel>
                                    <CFormInput
                                        id="intervalM"
                                        name="intervalM"
                                        value={formData.intervalM}
                                        onChange={handleInputChange}
                                        placeholder="Enter interval"
                                    />
                                </CCol>
                                <CCol xs={12} md={6}>
                                    <CFormLabel htmlFor="scope">Scope</CFormLabel>
                                    <CFormInput
                                        id="scope"
                                        name="scope"
                                        value={formData.scope}
                                        onChange={handleInputChange}
                                        placeholder="Enter comma-separated values"
                                    />
                                </CCol>
                                {/* <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel htmlFor="cat_slug">Category Slug</CFormLabel>
                                    <CFormSelect
                                        id="cat_slug"
                                        name="cat_slug"
                                        value={formData.cat_slug}
                                        onChange={handleInputChange}
                                    >
                                        <option value="">Select Category Slug</option>
                                        {categorySlugList.map((slug, index) => (
                                            <option key={index} value={slug}>
                                                {slug}
                                            </option>
                                        ))}
                                    </CFormSelect>
                                </CCol>
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel htmlFor="sub_cat_slug">Sub Category Slug</CFormLabel>
                                    <CFormSelect
                                        id="sub_cat_slug"
                                        name="sub_cat_slug"
                                        value={formData.sub_cat_slug}
                                        onChange={handleInputChange}
                                    >
                                        <option value="">Select Sub Category Slug</option>
                                        {subcategorySlugList.map((slug, index) => (
                                            <option key={index} value={slug}>
                                                {slug}
                                            </option>
                                        ))}
                                    </CFormSelect>
                                </CCol>
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel htmlFor="slug">Slug</CFormLabel>
                                    <CFormInput
                                        type="text"
                                        id="slug"
                                        name="slug"
                                        value={formData.slug}
                                        onChange={handleInputChange}
                                        placeholder="Enter slug"
                                    />
                                </CCol> */}
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel htmlFor="typeID">Type ID</CFormLabel>
                                    <CFormInput
                                        type="text"
                                        id="typeID"
                                        name="typeID"
                                        value={formData.typeID}
                                        onChange={handleInputChange}
                                        placeholder="Enter type ID"
                                    />
                                </CCol>
                                <CCol xs={12} md={6} className="mt-3">
                                    <CFormLabel htmlFor="status">Status</CFormLabel>
                                    <CFormSelect
                                        id="status"
                                        name="status"
                                        value={formData.status}
                                        onChange={handleInputChange}
                                    >
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </CFormSelect>
                                </CCol>
                            </CRow>
                            <CRow className="mt-4">
                                <CCol xs={12} className="text-center">
                                    <CButton type="submit" color="primary" disabled={loading}>
                                        {loading ? 'Submitting...' : 'Submit'}
                                    </CButton>
                                </CCol>
                            </CRow>
                            {message && (
                                <CRow className="mt-3">
                                    <CCol xs={12} className="text-center">
                                        <div
                                            style={{
                                                color: message.includes('successfully')
                                                    ? 'green'
                                                    : 'red',
                                                fontWeight: 'bold',
                                            }}
                                        >
                                            {message}
                                        </div>
                                    </CCol>
                                </CRow>
                            )}
                        </CForm>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    );
};

export default SuperSubCategory;
