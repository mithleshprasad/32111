import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  CAvatar,
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormLabel,
  CInputGroup,
  CInputGroupText,
  CRow,
  CFormInput,
} from '@coreui/react';
import { useParams } from 'react-router-dom';

const SliderUpdate = () => {
  const { id } = useParams();
  const [formData, setFormData] = useState({ image: null });
  const [previewImage, setPreviewImage] = useState('');
  const [currentImage, setCurrentImage] = useState({ name: '', size: 0 });
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const user_id = localStorage.getItem('user_id');

  // Fetch slider data on component mount
  useEffect(() => {
    if (id) {
      axios
        .get(`https://apicolorgame.a2logicgroup.com/api/admin/editslider/${id}`)
        .then((response) => {
          if (response.data.success) {
            const { image } = response.data.data || {};
            setFormData({
              image: image ? `https://apicolorgame.a2logicgroup.com/${image}` : null,
            });
            setPreviewImage(image ? `https://apicolorgame.a2logicgroup.com/${image}` : '');
            setCurrentImage({
              name: image?.split('/').pop() || '',
              size: 0, // Size is not available from the backend, handle on upload
            });
          } else {
            setMessage('Slider not found.');
          }
        })
        .catch((error) => {
          setMessage('Error fetching slider data.');
          console.error(error);
        });
    }
  }, [id]);

  // Handle image selection
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const allowedExtensions = /\.(jpg|jpeg|png|gif)$/i;
      if (!allowedExtensions.exec(file.name)) {
        setMessage('Invalid file type. Please upload an image file.');
        return;
      }

      // Check if the uploaded image is the same as the current one
      if (
        currentImage.name &&
        file.name === currentImage.name &&
        file.size === currentImage.size
      ) {
        setMessage('The same image is already uploaded. Please select a different image.');
        return;
      }

      setFormData({ ...formData, image: file });
      setPreviewImage(URL.createObjectURL(file));
      setMessage(''); // Clear any previous message
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
  
    try {
      // Create a new FormData object (correctly named and used)
      const data = new FormData();
  
      // Make sure user_id is defined and not empty
      if (!user_id) {
        setMessage('User ID is required');
        setLoading(false);
        return;
      }
  
      const userIdString = user_id.toString();
      // Append user_id as a string to FormData
      data.append('user_id', userIdString);
   
  
      if (!formData.image || typeof formData.image === 'string') {
        setMessage('Please upload a new image before submitting.');
        setLoading(false);
        return;
      }
  
      // Append the image file to FormData
      data.append('image', formData.image);
  
  console.warn("FormData after appending image:", userIdString,
    formData.image);
      // Sending the FormData via POST request
      const response = await axios.post(
        `https://apicolorgame.a2logicgroup.com/api/admin/update-slider/${id}`,
        {
            user_id:userIdString,
            image:formData.image
        },
        { headers: { 'Content-Type': 'multipart/form-data' } }
      );
  
      if (response.data.success === "1") {
        setMessage('Slider updated successfully!');
      } else {
        setMessage(response.data.message || 'Something went wrong.');
      }
    } catch (error) {
      console.error('Error updating slider:', error.message);
      setMessage('Failed to update slider. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <>
      <CRow>
        <CCol xs>
          <CCard className="mb-4">
            <CCardBody>
              <CForm onSubmit={handleSubmit} encType="multipart/form-data">
                <CRow>
                  <CCol xs={12} md={6}>
                    <CFormLabel htmlFor="imageUpload">Upload Image</CFormLabel>
                    <CInputGroup>
                      <CInputGroupText>Image</CInputGroupText>
                      <CFormInput
                        type="file"
                        id="imageUpload"
                        name="image"
                        accept="image/*"
                        onChange={handleImageChange}
                      />
                    </CInputGroup>
                    {previewImage && (
                      <img
                        style={{ maxWidth: '100%', marginTop: '10px' }}
                        src={previewImage}
                        alt="Preview"
                      />
                    )}
                  </CCol>

                  <CCol xs={12} md={6} className="text-center mt-4">
                    <CButton type="submit" color="primary" disabled={loading}>
                      {loading ? 'Submitting...' : 'Update'}
                    </CButton>
                  </CCol>
                </CRow>

                {message && (
                  <CRow className="mt-3">
                    <CCol xs={12} className="text-center">
                      <div
                        style={{
                          color: message.includes('successfully') ? 'green' : 'red',
                          fontWeight: 'bold',
                        }}
                      >
                        {message}
                      </div>
                    </CCol>
                  </CRow>
                )}
              </CForm>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  );
};

export default SliderUpdate;
