import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import {
    CAvatar,
    CButton,
    CButtonGroup,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CProgress,
    CRow,
    CTable,
    CTableBody,
    CTableDataCell,
    CTableHead,
    CTableHeaderCell,
    CTableRow,
    CWidgetStatsA,
    CDropdown,
    CDropdownMenu,
    CDropdownItem,
    CDropdownToggle,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';
import { cilPeople } from '@coreui/icons';
import { getStyle } from '@coreui/utils';
import { CChartBar, CChartLine } from '@coreui/react-chartjs';
import { cilArrowBottom, cilArrowTop, cilOptions } from '@coreui/icons';
import avatar1 from 'src/assets/images/avatars/1.jpg';
import { IoMdAdd } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEdit } from "react-icons/fa";

const InActiveUsers = (props) => {
    const userId = localStorage.getItem('user_id');
    const isLoading = useRef(false);
    const [loading, setLoading] = useState(false);
    const [inactiveUsers, InsetActiveUsers] = useState([]);
    const [totalUsers, setTotalUsers] = useState(0);
    const widgetChartRef1 = useRef(null);
    const widgetChartRef2 = useRef(null);

    useEffect(() => {
        document.documentElement.addEventListener('ColorSchemeChange', () => {
            if (widgetChartRef1.current) {
                setTimeout(() => {
                    widgetChartRef1.current.data.datasets[0].pointBackgroundColor = getStyle('--cui-primary');
                    widgetChartRef1.current.update();
                });
            }
            if (widgetChartRef2.current) {
                setTimeout(() => {
                    widgetChartRef2.current.data.datasets[0].pointBackgroundColor = getStyle('--cui-info');
                    widgetChartRef2.current.update();
                });
            }
        });
    }, [widgetChartRef1, widgetChartRef2]);

    const updateUserStatus = (user_id, currentStatus) => {
        const updatedStatus = currentStatus === 1 ? 0 : 1;

        axios
            .post(`https://apicolorgame.a2logicgroup.com/api/admin/user-statuss`, { user_id, user_status: updatedStatus })
            .then((res) => {
                console.log('Status updated successfully:', res.data);
                fetchAllActiveUsers();
            })
            .catch((err) => {
                console.error('Error updating user status:', err);
                alert('Failed to update the user status. Please try again.');
            });
    };

    const fetchAllInActiveUsers = async () => {
        try {
            isLoading.current = true;
            setLoading(true);

            const url = `https://apicolorgame.a2logicgroup.com/api/admin/user-inactive`;

            const config = {
                method: 'POST',
                url: url,
                headers: {
                    'Content-Type': 'application/json',
                },
            };

            const response = await axios(config);
            setTotalUsers(response.data.totalActiveUsers);
            console.warn(response.data.totalActiveUsers);

            if (response.data?.success === '1' && Array.isArray(response.data.data?.inactiveUsers)) {
                InsetActiveUsers(response.data.data.inactiveUsers);
                setTotalUsers(response.data.data.totalActiveUsers);
                console.log('Fetched Users:', response.data.data.totalActiveUsers);
            } else {
                console.error('Unexpected response structure:', response.data);
            }
        } catch (error) {
            console.error('Error fetching user data:', error.message);
        } finally {
            isLoading.current = false;
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAllInActiveUsers();
    }, []);

    
    return (
        <>
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            <CTable align="middle" className="mb-0 border" hover responsive>
                                <CTableHead className="text-nowrap">
                                    <CTableRow>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">
                                            <CIcon icon={cilPeople} />
                                        </CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary">User</CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">Mobile</CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">Password</CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">Reffer</CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary">Credit</CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">Win Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">Date</CTableHeaderCell>
                                        <CTableHeaderCell className="bg-body-tertiary text-center">Action</CTableHeaderCell>
                                    </CTableRow>
                                </CTableHead>
                                <CTableBody>
                                    {inactiveUsers.map((item, index) => (
                                        <CTableRow key={index}>
                                            <CTableDataCell className="text-center">
                                                <CAvatar size="md" src={item.avatar?.src || avatar1} />
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div>{item.name || 'N/A'}</div>
                                                <div className="small text-body-secondary text-nowrap">
                                                    <span style={{ color: item.user_status === 1 ? 'green' : 'red' }}>
                                                        {item.user_status === 1 ? 'Active' : 'Inactive'}
                                                    </span>{' '}
                                                    | User ID: {item.user_id}
                                                </div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div className="text-center">{item.mobile}</div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div className="text-center">{item.password}</div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div className="text-center">{item.reffer}</div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div className="fw-semibold">{(Number(item.credit) || 0).toFixed(2)}</div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div className="fw-semibold text-center">{(Number(item.win_amount) || 0).toFixed(2)}</div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div className="fw-semibold">
                                                    {new Date(item.updated_at).toLocaleString()}
                                                </div>
                                            </CTableDataCell>
                                            {/* <CTableDataCell>
                        <input
                          type="checkbox"
                          className="toggle-switch"
                          checked={item.user_status === 1}
                          onChange={() => updateUserStatus(item.user_id, item.user_status)}
                        />
                      </CTableDataCell> */}
                                            <CTableDataCell className='text-center'>
                                                {/* <Link to={`/AddCategory/${item._id}`}>
                                          <CButton
                                          color="primary"
                                          size="sm"
                                          className="me-2 text-white"
                                        >
                                          <IoMdAdd />
                                        </CButton>
                                        </Link> */}

                                                <CButton
                                                    color="warning"
                                                    size="sm"
                                                    className="me-2 text-white"
                                                    onClick={() => handleEdit(item.slug)}
                                                >
                                                    <FaEdit />
                                                </CButton>
                                                <CButton
                                                    color="danger"
                                                    size="sm"
                                                    className="me-2 text-white"
                                                    onClick={() => fetchDelete(item.slug)}
                                                >
                                                    <RiDeleteBin6Line />
                                                </CButton>

                                            </CTableDataCell>
                                        </CTableRow>
                                    ))}
                                </CTableBody>
                            </CTable>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    );
};

export default InActiveUsers;
