import React, { useState, useRef, useEffect } from 'react'
import axios from 'axios';
import PropTypes from 'prop-types'
import Swal from 'sweetalert2';

import {
  CAvatar,
  CButton,
  CButtonGroup,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CProgress,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
  CWidgetStatsA,
  CDropdown,
  CDropdownMenu,
  CDropdownItem,
  CDropdownToggle,
  CModal,
  CModalHeader,
  CModalBody,
  CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilPeople,
} from '@coreui/icons'
import { getStyle } from '@coreui/utils'
import { CChartBar, CChartLine } from '@coreui/react-chartjs'
import { cilArrowBottom, cilArrowTop, cilOptions } from '@coreui/icons'
import { IoMdAdd } from "react-icons/io";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEdit } from "react-icons/fa";
import avatar1 from 'src/assets/images/avatars/1.jpg'

const UserManagement = (props) => {

  const userId = localStorage.getItem("user_id");
  const isLoading = useRef(false);
  const [loading, setLoading] = useState(false);
  const [allUsers, setAllUsers] = useState([]);
  const [creditAmt, setCreditAmt] = useState(0);
  const user_id = localStorage.getItem("user_id");


  const [totalUsers, setTotalUsers] = useState(0);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [DepositAmount, setDepositAmount] = useState('');

  const widgetChartRef1 = useRef(null)
  const widgetChartRef2 = useRef(null)

  const [visible, setVisible] = useState(false);
  const [formData, setFormData] = useState({
    user_id: null,
    amount: '',
    type: "Withdrawal",
    remark: "withdraw by admin",
    status: "successful",
    // bank_name: null,
    // account_number: null,
    // ifsc_code: null,

  });

  // Modal and Button Handlers
  const handleModalClick = (type, user_id, mobile, credit) => {
    setFormData((prevData) => ({
      ...prevData,
      user_id,
      status: "successful",
      mobile,
      type: type === "withdraw" ? "Withdrawal" : "Deposit",
    }));
    setCreditAmt(credit);
    setWithdrawAmount('');
    setDepositAmount('');
    setVisible(true);
  };

  const handleClose = () => {
    setVisible(false);
    setWithdrawAmount('');
    setDepositAmount('');
  };

  const handleWithdraw = async () => {
    try {
      setLoading(true);

      const url = `https://apicolorgame.a2logicgroup.com/api/admin/withdraw`;
      // const amount = formData.type === "Withdrawal" ? withdrawAmount : DepositAmount;
      const amount = Number(
        formData.type === "Withdrawal" ? withdrawAmount : DepositAmount
      ).toFixed(2);
      

      const config = {
        method: "POST",
        url: url,
        headers: {
          "Content-Type": "application/json",
        },
        data: { ...formData, amount },
      };

      const response = await axios(config);
      const responseData = response.data;

      if (responseData.success) {
        Swal.fire({
          icon: "success",
          title: "Success",
          text: responseData.message || `${formData.type} successful!`,
        });
        fetchAllUsers();
        handleClose();
      } else {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: responseData.message || `Failed to ${formData.type.toLowerCase()}. Please try again.`,
        });
      }
    } catch (error) {
      console.error(`Error processing ${formData.type}:`, error);
      Swal.fire({
        icon: "error",
        title: "Error",
        text: `Failed to ${formData.type.toLowerCase()}. Please try again.`,
      });
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    document.documentElement.addEventListener('ColorSchemeChange', () => {
      if (widgetChartRef1.current) {
        setTimeout(() => {
          widgetChartRef1.current.data.datasets[0].pointBackgroundColor = getStyle('--cui-primary')
          widgetChartRef1.current.update()
        })
      }

      if (widgetChartRef2.current) {
        setTimeout(() => {
          widgetChartRef2.current.data.datasets[0].pointBackgroundColor = getStyle('--cui-info')
          widgetChartRef2.current.update()
        })
      }
    })
  }, [widgetChartRef1, widgetChartRef2])



  const updateUserStatus = (user_id, currentStatus) => {
    const updatedStatus = currentStatus === 1 ? 0 : 1;

    axios
      .post(
        `https://apicolorgame.a2logicgroup.com/api/admin/user-statuss`,
        { user_id, user_status: updatedStatus }
      )
      .then((res) => {
        console.log("Status updated successfully:", res.data);
        fetchAllUsers();
      })
      .catch((err) => {
        console.error("Error updating user status:", err);
        alert("Failed to update the user status. Please try again.");
      });
  }

  const fetchAllUsers = async () => {
    try {
      isLoading.current = true;
      setLoading(true);

      const url = `https://apicolorgame.a2logicgroup.com/api/admin/user-list`;

      const config = {
        method: "POST",
        url: url,
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          user_id: userId,
        },
      };

      const response = await axios(config);
      setTotalUsers(response.data.AllUserActiveInactive);
      console.warn(response.data.AllUserActiveInactive);

      if (response.data?.success === "1" && Array.isArray(response.data.data?.users)) {
        setAllUsers(response.data.data.users);
        // setCreditAmt(response.data.data.users[0].credit);
        setTotalUsers(response.data.data.AllUserActiveInactive);
        console.log("Fetched Users:", response.data.data.AllUserActiveInactive);
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (error) {
      console.error("Error fetching user data:", error.message);
    } finally {
      isLoading.current = false;
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllUsers();
  }, []);



  return (
    <>
      <CRow className={props.className} xs={{ gutter: 4 }}>
        <CCol sm={6} xl={6} xxl={4}>
          <CWidgetStatsA
            color="primary"

            value={
              <>
                {totalUsers.totalUsers}
                {/* <span className="fs-6 fw-normal">
                (-12.4% <CIcon icon={cilArrowBottom} />)
              </span> */}
              </>
            }
            title="Total Users"
            action={
              <CDropdown alignment="end">
                <CDropdownToggle color="transparent" caret={false} className="text-white p-0">
                  <CIcon icon={cilOptions} />
                </CDropdownToggle>
                <CDropdownMenu>
                  <CDropdownItem>Action</CDropdownItem>
                  <CDropdownItem>Another action</CDropdownItem>
                  <CDropdownItem>Something else here...</CDropdownItem>
                  <CDropdownItem disabled>Disabled action</CDropdownItem>
                </CDropdownMenu>
              </CDropdown>
            }
            chart={
              <CChartLine
                ref={widgetChartRef1}
                className="mt-3 mx-3"
                style={{ height: '70px' }}
                data={{
                  labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                  datasets: [
                    {
                      label: 'My First dataset',
                      backgroundColor: 'transparent',
                      borderColor: 'rgba(255,255,255,.55)',
                      pointBackgroundColor: getStyle('--cui-primary'),
                      data: [65, 59, 84, 84, 51, 55, 40],
                    },
                  ],
                }}
                options={{
                  plugins: {
                    legend: {
                      display: false,
                    },
                  },
                  maintainAspectRatio: false,
                  scales: {
                    x: {
                      border: {
                        display: false,
                      },
                      grid: {
                        display: false,
                        drawBorder: false,
                      },
                      ticks: {
                        display: false,
                      },
                    },
                    y: {
                      min: 30,
                      max: 89,
                      display: false,
                      grid: {
                        display: false,
                      },
                      ticks: {
                        display: false,
                      },
                    },
                  },
                  elements: {
                    line: {
                      borderWidth: 1,
                      tension: 0.4,
                    },
                    point: {
                      radius: 4,
                      hitRadius: 10,
                      hoverRadius: 4,
                    },
                  },
                }}
              />
            }
          />
        </CCol>
        <CCol sm={6} xl={6} xxl={4}>
          <CWidgetStatsA
            color="info"
            value={
              <>
                {totalUsers.totalActiveUsers}
              </>
            }
            title="Total Active Users"
            action={
              <CDropdown alignment="end">
                <CDropdownToggle color="transparent" caret={false} className="text-white p-0">
                  <CIcon icon={cilOptions} />
                </CDropdownToggle>
                <CDropdownMenu>
                  <CDropdownItem>Action</CDropdownItem>
                  <CDropdownItem>Another action</CDropdownItem>
                  <CDropdownItem>Something else here...</CDropdownItem>
                  <CDropdownItem disabled>Disabled action</CDropdownItem>
                </CDropdownMenu>
              </CDropdown>
            }
            chart={
              <CChartLine
                ref={widgetChartRef2}
                className="mt-3 mx-3"
                style={{ height: '70px' }}
                data={{
                  labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                  datasets: [
                    {
                      label: 'My First dataset',
                      backgroundColor: 'transparent',
                      borderColor: 'rgba(255,255,255,.55)',
                      pointBackgroundColor: getStyle('--cui-info'),
                      data: [1, 18, 9, 17, 34, 22, 11],
                    },
                  ],
                }}
                options={{
                  plugins: {
                    legend: {
                      display: false,
                    },
                  },
                  maintainAspectRatio: false,
                  scales: {
                    x: {
                      border: {
                        display: false,
                      },
                      grid: {
                        display: false,
                        drawBorder: false,
                      },
                      ticks: {
                        display: false,
                      },
                    },
                    y: {
                      min: -9,
                      max: 39,
                      display: false,
                      grid: {
                        display: false,
                      },
                      ticks: {
                        display: false,
                      },
                    },
                  },
                  elements: {
                    line: {
                      borderWidth: 1,
                    },
                    point: {
                      radius: 4,
                      hitRadius: 10,
                      hoverRadius: 4,
                    },
                  },
                }}
              />
            }
          />
        </CCol>
        <CCol sm={6} xl={6} xxl={4}>
          <CWidgetStatsA
            color="danger"
            value={
              <>
                {totalUsers.totalInactiveUsers}
              </>
            }
            title="Total Inactive Users"
            action={
              <CDropdown alignment="end">
                <CDropdownToggle color="transparent" caret={false} className="text-white p-0">
                  <CIcon icon={cilOptions} />
                </CDropdownToggle>
                <CDropdownMenu>
                  <CDropdownItem>Action</CDropdownItem>
                  <CDropdownItem>Another action</CDropdownItem>
                  <CDropdownItem>Something else here...</CDropdownItem>
                  <CDropdownItem disabled>Disabled action</CDropdownItem>
                </CDropdownMenu>
              </CDropdown>
            }
            chart={
              <CChartLine
                className="mt-3"
                style={{ height: '70px' }}
                data={{
                  labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                  datasets: [
                    {
                      label: 'My First dataset',
                      backgroundColor: 'rgba(255,255,255,.2)',
                      borderColor: 'rgba(255,255,255,.55)',
                      data: [78, 81, 80, 45, 34, 12, 40],
                      fill: true,
                    },
                  ],
                }}
                options={{
                  plugins: {
                    legend: {
                      display: false,
                    },
                  },
                  maintainAspectRatio: false,
                  scales: {
                    x: {
                      display: false,
                    },
                    y: {
                      display: false,
                    },
                  },
                  elements: {
                    line: {
                      borderWidth: 2,
                      tension: 0.4,
                    },
                    point: {
                      radius: 0,
                      hitRadius: 10,
                      hoverRadius: 4,
                    },
                  },
                }}
              />
            }
          />
        </CCol>
      </CRow>




      <CRow>
        <CCol xs>
          <CCard className="mb-4">
            <CCardBody>
              <CTable align="middle" className="mb-0 border" hover responsive>
                <CTableHead className="text-nowrap">
                  <CTableRow>
                    <CTableHeaderCell className="bg-body-tertiary text-center">
                      <CIcon icon={cilPeople} />
                    </CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary">User</CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">
                      Mobile
                    </CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">
                      Password
                    </CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">
                      Reffer
                    </CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary">Credit</CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">
                      Win Amount
                    </CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">Date</CTableHeaderCell>
                    {/* <CTableHeaderCell className="bg-body-tertiary text-center">Status</CTableHeaderCell> */}
                    <CTableHeaderCell className="bg-body-tertiary text-center">Action</CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">Withdraw</CTableHeaderCell>
                    <CTableHeaderCell className="bg-body-tertiary text-center">Deposit</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {allUsers.map((item, index) => (
                    <CTableRow key={index}>
                      <CTableDataCell className="text-center">
                        <CAvatar size="md" src={item.avatar?.src || avatar1} />
                      </CTableDataCell>
                      <CTableDataCell>
                        <div>{item.name || "N/A"}</div>
                        <div className="small text-body-secondary text-nowrap">
                          <span
                            style={{
                              color: item.user_status === 1 ? "green" : "red",
                            }}
                          >
                            {item.user_status === 1 ? "Active" : "Inactive"}
                          </span>{" "}
                          | User ID: {item.user_id}
                        </div>
                      </CTableDataCell>
                      <CTableDataCell>
                                            <div className="text-center">{item.Phone}</div>
                                          </CTableDataCell>
                                          <CTableDataCell>
                                            <div className="text-center">{item.Password}</div>
                                          </CTableDataCell>
                                          <CTableDataCell>
                                            <div className="text-center">{item.reffer}</div>
                                          </CTableDataCell>
                                          <CTableDataCell>
                                            <div className="fw-semibold">{(Number(item.Wallet_balance) || 0).toFixed(2)}</div>
                                          </CTableDataCell>
                      <CTableDataCell>
                        <div className="fw-semibold text-center">
                          {(Number(item.win_amount) || 0).toFixed(2)}
                        </div>
                      </CTableDataCell>
                      <CTableDataCell>
                        <div className="fw-semibold">
                          {new Date(item.updated_at).toLocaleString()}
                        </div>
                      </CTableDataCell>
                      <CTableDataCell className="text-center">
                        <input
                          type="checkbox"
                          className="toggle-switch"
                          checked={item.user_status === 1}
                          onChange={() => updateUserStatus(item.user_id, item.user_status)}
                        />

                      </CTableDataCell>
                      <CTableDataCell className="text-center">
                        <button
                          type="button"
                          className="btn btn-sm me-2 text-white btn-warning"
                          onClick={() => handleModalClick("withdraw", item.user_id, item.mobile, item.credit)}
                        >
                          Withdraw
                        </button>
                      </CTableDataCell>
                      <CTableDataCell className="text-center">
                        <button
                          type="button"
                          className="btn btn-sm me-2 text-white btn-success"
                          onClick={() => handleModalClick("deposit", item.user_id, item.mobile, item.credit)}
                        >
                          Deposit
                        </button>
                      </CTableDataCell>
                    </CTableRow>
                  ))}

                </CTableBody>
              </CTable>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>


      <CModal visible={visible} onClose={handleClose}>
  <CModalHeader>{formData.type} Confirmation</CModalHeader>
  <CModalBody>
    {formData.type === "Withdrawal" && (
      <h4 style={{ marginBottom: "20px" }}>
        Total Amount: {(Number(creditAmt) || 0).toFixed(2)}
      </h4>
    )}
    <label
      htmlFor="amount"
      style={{
        fontWeight: "bold",
        marginBottom: "10px",
        display: "block",
      }}
    >
      Enter Amount:
    </label>
    <input
      type="text"
      id="amount"
      placeholder="Enter amount"
      value={
        formData.type === "Withdrawal" ? withdrawAmount : DepositAmount
      }
      onChange={(e) =>
        formData.type === "Withdrawal"
          ? setWithdrawAmount(e.target.value)
          : setDepositAmount(e.target.value)
      }
      style={{
        width: "100%",
        padding: "10px",
        border: "1px solid #ccc",
        borderRadius: "5px",
        fontSize: "16px",
        marginBottom: "20px",
      }}
    />
  </CModalBody>
  <CModalFooter>
    <CButton color="secondary" onClick={handleClose}>
      Cancel
    </CButton>
    <CButton
      color="primary"
      onClick={() =>
        formData.type === "Withdrawal"
          ? handleWithdraw(withdrawAmount)
          : handleWithdraw(DepositAmount)
      }
      disabled={
        (formData.type === "Withdrawal" && !withdrawAmount) ||
        (formData.type === "Deposit" && !DepositAmount)
      }
    >
      {formData.type}
    </CButton>
  </CModalFooter>
</CModal>
    </>
  )
}

export default UserManagement



