import React from 'react'
import CIcon from '@coreui/icons-react'
import {
  cilSpeedometer,
  cilUser,
  cilListRich,
  cilPlaylistAdd,
  cilStorage

} from '@coreui/icons'
import { CNavGroup, CNavItem } from '@coreui/react'

const _nav = [
  // {
  //   component: CNavItem,
  //   name: 'Dashboard',
  //   to: '/dashboard',
  //   icon: <CIcon icon={cilSpeedometer} customClassName="nav-icon" />,
  //   badge: {
  //     color: 'info',
  //     text: 'NEW',
  //   },
  // },
  {
    component: CNavGroup,
    name: 'User Management',
    icon: <CIcon icon={cilUser} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'All Users',
        to: '/allUsers',
      },
      {
        component: CNavItem,
        name: 'Active Users',
        to: '/ActiveUsers',
      },
      {
        component: CNavItem,
        name: 'Inactive Users',
        to: '/InActiveUser',
      },
    ],
  },
  {
    component: CNavGroup,
    name: 'Categories',
    icon: <CIcon icon={cilListRich} customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'Category',
        to: '/Category',
      },
      {
        component: CNavItem,
        name: 'Sub Category',
        to: '/SubCategory',
      },
      {
        component: CNavItem,
        name: 'Super Sub Category',
        to: '/SuperSubCategory',
      },
    ],
  },
  {
    component: CNavGroup,
    name: 'Bet Management',
    icon: <CIcon icon={cilPlaylistAdd
    } customClassName="nav-icon" />,
    items: [
      {
        component: CNavItem,
        name: 'All Bets',
        to: '/allBets',
      },
      {
        component: CNavItem,
        name: 'Active Bets',
        to: '/activeBets',
      },
      {
        component: CNavItem,
        name: 'Inactive Bets',
        to: '/inactiveBets',
      },
      {
        component: CNavItem,
        name: 'Pending Bets',
        to: '/PendingBets',
      },
      {
        component: CNavItem,
        name: 'Results',
        to: '/results',
      },
    ],
  },
  {
    component: CNavItem,
    name: 'Slider',
    to: '/slider',
    icon: <CIcon icon={cilStorage} customClassName="nav-icon" />,

  },
]

export default _nav
