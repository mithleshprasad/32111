const http = require('http');
const { WebSocketServer } = require('ws');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const app = require('./app');
const setupWebSocketGames = require('./services/webSocketServices');

dotenv.config();

const PORT = process.env.PORT || 5000;
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

async function startServer() {
  try {
    await connectDB();
    console.log('Connected to database');

    setupWebSocketGames(wss); // Setup all games & logic

    server.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
  }
}

startServer();
