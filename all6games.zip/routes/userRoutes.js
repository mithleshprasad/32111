const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Lucky7Bet = require('../games/lucky7/models/LuckyBet');
const Bet32Card = require('../games/32card/models/Bet');
const DragonTigerBet = require('../games/dragontiger/models/Bet');
const AndarBaharBet = require('../games/andar_bahar/models/Bet');
const TeenPattiBet = require('../games/teenpatti/models/Bet'); 
const Lucky7GameRound = require('../games/lucky7/models/LuckyGameRound');
const GameRound32Card = require('../games/32card/models/GameRound');
const DragonTigerGameRound = require('../games/dragontiger/models/GameRound');
const AndarBaharGameRound = require('../games/andar_bahar/models/GameRound');
const TeenPattiGameRound = require('../games/teenpatti/models/GameRound');

router.get('/balance/:userId', async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) return res.status(404).json({ message: 'User not found' });
        res.json({ balance: user.balance });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

router.get('/my_bet_history/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const lucky7Bets = await Lucky7Bet.find({ userId });
        const bets32Card = await Bet32Card.find({ userId });
        const dragonTigerBets = await DragonTigerBet.find({ userId });
        const andarBaharBets = await AndarBaharBet.find({ userId });

        const bets = [
            ...lucky7Bets.map(bet => ({
                ...bet._doc,
                game: 'lucky7',
                winAmount: bet.status === 'won' ? bet.amount * (bet.odds + 1) : 0,
                lossAmount: bet.status === 'lost' ? bet.amount : 0
            })),
            ...bets32Card.map(bet => ({
                ...bet._doc,
                game: '32card',
                winAmount: bet.status === 'won' ? bet.amount * (bet.odds + 1) : 0,
                lossAmount: bet.status === 'lost' ? bet.amount : 0
            })),
            ...dragonTigerBets.map(bet => ({
                ...bet._doc,
                game: 'dragontiger',
                winAmount: bet.status === 'won' ? bet.amount * (bet.odds + 1) : 0,
                lossAmount: bet.status === 'lost' ? bet.amount : 0
            })),
            ...andarBaharBets.map(bet => ({
                ...bet._doc,
                game: 'andarbahar',
                winAmount: bet.status === 'won' ? bet.amount * (bet.odds + 1) : 0,
                lossAmount: bet.status === 'lost' ? bet.amount : 0,
                winner: bet.status === 'won' ? bet.betType : (bet.betType === 'andar' ? 'bahar' : 'andar') 
            })),
            ...TeenPattiBet.find({ userId }).map(bet => ({
                ...bet._doc,
                game: 'teenpatti',
                winAmount: bet.status === 'won' ? bet.amount * (bet.odds + 1) : 0,
                lossAmount: bet.status === 'lost' ? bet.amount : 0
            }))
        ].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        res.json({ bets });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});
router.get('/current-round/:game', async (req, res) => {
    try {
        const game = req.params.game;
        let round;
        if (game === 'lucky7') {
            round = await Lucky7GameRound.findOne().sort({ createdAt: -1 });
        } else if (game === '32card') {
            round = await GameRound32Card.findOne().sort({ createdAt: -1 });
        } else if (game === 'dragontiger') {
            round = await DragonTigerGameRound.findOne().sort({ createdAt: -1 });
        } else if (game === 'andarbahar') {
            round = await AndarBaharGameRound.findOne().sort({ createdAt: -1 });
        } else if (game === 'teenpatti') {
            round = await TeenPattiGameRound.findOne().sort({ createdAt: -1 });
        }else {
            return res.status(400).json({ message: 'Invalid game' });
        }

        if (!round) return res.status(404).json({ message: 'No active round' });
        res.json(round);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;