const User = require('../models/User');

// Bet Models
const Card32Bet = require('../games/32card/models/Bet');
const DragonTigerBet = require('../games/dragontiger/models/Bet');
const AndarBaharBet = require('../games/andar_bahar/models/Bet');
const TeenPattiBet = require('../games/teenpatti/models/Bet');
const Lucky7Bet = require('../games/lucky7/models/LuckyBet');
const MuflisBet = require('../games/muflis/models/Bet');


const Card32GameRound = require('../games/32card/models/GameRound');
const DragonTigerGameRound = require('../games/dragontiger/models/GameRound');
const AndarBaharGameRound = require('../games/andar_bahar/models/GameRound');
const TeenPattiGameRound = require('../games/teenpatti/models/GameRound');
const Lucky7GameRound = require('../games/lucky7/models/LuckyGameRound');
const MuflisGameRound = require('../games/muflis/models/GameRound');

exports.getAllGameRoundsForGame = async (req, res) => {
    const { game } = req.params;
    const { userId, user_type, page = 1, limit = 10 } = req.body;
    
    if (!userId || !user_type) {
        return res.status(400).json({ message: 'User ID and user type are required' });
    }
    if (!['admin'].includes(user_type)) {
        return res.status(400).json({ message: 'Invalid user type' });
    }
    if (!page || isNaN(page) || page < 1) {
        return res.status(400).json({ message: 'Invalid page number' });
    }
    
    try {
        const gameRounds = await fetchGameRoundsByGame(game, userId, user_type, Number(page), Number(limit));
        res.status(200).json(gameRounds);
    } catch (error) {
        console.error(`Error fetching game rounds for ${game}:`, error);
        res.status(500).json({ message: 'Internal server error', error: error.message });
    }
    }
    
    async function fetchGameRoundsByGame(game, userId, user_type, page, limit) {
        if (!userId) throw new Error('User ID is required');
        if (user_type !== 'admin') throw new Error('Unauthorized: Only admin can access this');
        if (!['32card', 'dragontiger', 'andarbahar', 'teenpatti', 'lucky7', 'muflis'].includes(game)) {
            throw new Error('Invalid game type');
        }

        const user = await User.findById(userId);
        if (!user) throw new Error('Admin user not found');

        const skip = (page - 1) * limit;

        const gameModels = {
            '32card': Card32GameRound,
            'dragontiger': DragonTigerGameRound,
            'andarbahar': AndarBaharGameRound,
            'teenpatti': TeenPattiGameRound,
            'lucky7': Lucky7GameRound,
            'muflis': MuflisGameRound
        };

        const GameRoundModel = gameModels[game];
        if (!GameRoundModel) throw new Error('Invalid game type');

        const totalRounds = await GameRoundModel.countDocuments();
        const rounds = await GameRoundModel.find({})
            .skip(skip)
            .limit(limit)
            .sort({ createdAt: -1 });

        return {
            totalRounds,
            rounds,
            page,
            limit
        };
    }