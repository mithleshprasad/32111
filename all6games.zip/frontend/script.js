// Game state
const userId = localStorage.getItem('userId') || 'test-user'; // Replace with authenticated user ID in production
const gameState = {
  balance: 0,
  currentBet: 0,
  selectedBetType: null,
  gameInProgress: false,
  userId,
  results: [],
  countdown: null,
  soundEnabled: true,
};

// DOM elements
const elements = {
  dealBtn: document.getElementById('deal-btn'),
  resetBtn: document.getElementById('reset-btn'),
  result: document.getElementById('result'),
  betOptions: document.querySelectorAll('.bet-option'),
  amountInput: document.getElementById('amount'),
  currentBetAmount: document.getElementById('current-bet-amount'),
  currentBetType: document.getElementById('current-bet-type'),
  balance: document.getElementById('balance'),
  chips: document.querySelectorAll('.chip'),
  historyItems: document.getElementById('history-items'),
  dragonCard: document.getElementById('dragon-card'),
  tigerCard: document.getElementById('tiger-card'),
  helpBtn: document.getElementById('help-btn'),
  soundToggle: document.getElementById('sound-toggle'),
};

// Audio elements
const sounds = {
  deal: document.getElementById('dealSound'),
  win: document.getElementById('winSound'),
  lose: document.getElementById('loseSound'),
  chip: document.getElementById('chipSound'),
};

// WebSocket connection
const ws = new WebSocket('ws://localhost:5000');
ws.onopen = async () => {
  console.log('Connected to WebSocket server');
  try {
    await fetchBalance();
    await fetchCurrentRound();
    showToast('Connected to Dragon Tiger', 'success');
  } catch (error) {
    console.error('Error initializing:', error);
    showToast('Error initializing game', 'error');
  }
};

ws.onmessage = (event) => {
  try {
    const data = JSON.parse(event.data);
    if (data.game !== 'dragontiger') return; // Ignore messages for other games
    handleWebSocketMessage(data);
  } catch (error) {
    console.error('Error parsing WebSocket message:', error);
    showToast('Invalid server message', 'error');
  }
};

ws.onclose = () => {
  console.error('WebSocket connection closed');
  showToast('Connection lost, please refresh', 'error');
  clearCountdown();
};

ws.onerror = (error) => {
  console.error('WebSocket error:', error);
  showToast('Connection error, please refresh', 'error');
  clearCountdown();
};

// Toast notification
function showToast(message, type = 'error') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 100);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Fetch user balance
async function fetchBalance() {
  try {
    const response = await fetch(`http://localhost:5000/api/balance/${gameState.userId}`);
    if (!response.ok) throw new Error('Failed to fetch balance');
    const data = await response.json();
    gameState.balance = data.balance || 0;
    updateUI();
  } catch (error) {
    console.error('Error fetching balance:', error);
    showToast('Error fetching balance', 'error');
  }
}

// Fetch current round
async function fetchCurrentRound() {
  try {
    const response = await fetch(`http://localhost:5000/api/current-round/dragontiger`);
    if (!response.ok) throw new Error('Failed to fetch round');
    const data = await response.json();
    if (data.status === 'accepting_bets') {
      elements.dealBtn.disabled = false;
      elements.dealBtn.textContent = 'Place Bet';
      startCountdown(Math.floor((new Date(data.bettingEndTime) - Date.now()) / 1000));
    } else {
      elements.dealBtn.disabled = true;
      elements.dealBtn.textContent = 'Waiting for Round...';
      gameState.gameInProgress = true;
    }
    setRound(data);
  } catch (error) {
    console.error('Error fetching round:', error);
    showToast('Error fetching round', 'error');
  }
}

// Handle WebSocket messages
async function handleWebSocketMessage(data) {
  switch (data.type) {
    case 'connection':
      showToast(data.message, 'success');
      break;
    case 'newRound':
      resetGame();
      elements.dealBtn.disabled = false;
      elements.dealBtn.textContent = 'Place Bet';
      gameState.gameInProgress = false;
      startCountdown(30);
      showToast(`New Round ${data.roundNumber}`, 'success');
      setRound(data);
      break;
    case 'bettingClosed':
      elements.dealBtn.disabled = true;
      elements.dealBtn.textContent = 'Waiting for Round...';
      gameState.gameInProgress = true;
      clearCountdown();
      showToast(`Betting closed for Round ${data.roundNumber}`, 'error');
      setRound(data);
      break;
    case 'cardsDealt':
      updateCards(data.cards);
      elements.result.textContent = `Dragon: ${data.dragonValue}, Tiger: ${data.tigerValue}`;
      setRound(data);
      break;
    case 'roundResult':
      await updateResult(data);
      await fetchBalance();
      await fetchBetHistory();
      elements.resetBtn.disabled = false;
      setRound(data);
      break;
    case 'betPlaced':
      gameState.currentBet = data.amount;
      showToast(`Bet of ${data.amount} placed on ${data.betType}`, 'success');
      await fetchBalance();
      updateUI();
      break;
    case 'error':
      showToast(data.message, 'error');
      if (data.message === 'No active betting round') {
        resetGame();
      }
      clearCountdown();
      break;
    default:
      console.warn('Unknown message type:', data.type);
  }
}

// Set round data
function setRound(data) {
  gameState.round = {
    roundNumber: data.roundNumber,
    status: data.status,
    cards: data.cards,
    dragonValue: data.dragonValue,
    tigerValue: data.tigerValue,
    result: data.result,
    bettingEndTime: data.bettingEndTime,
    winnerAnnouncedTime: data.winnerAnnouncedTime,
  };
}

// Countdown timer
function startCountdown(seconds) {
  if (seconds <= 0) return;
  clearCountdown();
  let timeLeft = seconds;
  elements.result.textContent = `Time to bet: ${timeLeft}s`;
  gameState.countdown = setInterval(() => {
    timeLeft--;
    elements.result.textContent = `Time to bet: ${timeLeft}s`;
    if (timeLeft <= 0) {
      clearCountdown();
      elements.dealBtn.disabled = true;
      elements.dealBtn.textContent = 'Waiting for Round...';
      gameState.gameInProgress = true;
    }
  }, 1000);
}

function clearCountdown() {
  if (gameState.countdown) {
    clearInterval(gameState.countdown);
    gameState.countdown = null;
  }
  if (!elements.result.textContent.includes('Result:')) {
    elements.result.textContent = '';
  }
}

// Place a bet
function placeBet(betType) {
  if (gameState.gameInProgress) {
    showToast('Betting is closed for this round', 'error');
    return;
  }
  const betAmount = parseInt(elements.amountInput.value);
  if (isNaN(betAmount) || betAmount < 50) {
    showToast('Minimum bet is 50', 'error');
    return;
  }
  if (betAmount > gameState.balance) {
    showToast('Insufficient balance', 'error');
    return;
  }
  const validBetTypes = ['dragon', 'tiger', 'tie'];
  if (!validBetTypes.includes(betType)) {
    showToast('Invalid bet type', 'error');
    return;
  }
  gameState.selectedBetType = betType;
  elements.betOptions.forEach(opt => opt.classList.remove('selected'));
  document.getElementById(`bet-${betType}`).classList.add('selected');
  elements.currentBetAmount.textContent = betAmount;
  elements.currentBetType.textContent = betType.charAt(0).toUpperCase() + betType.slice(1);
  ws.send(JSON.stringify({
    game: 'dragontiger',
    type: 'placeBet',
    userId: gameState.userId,
    amount: betAmount,
    betType,
  }));
  if (gameState.soundEnabled) sounds.chip.play();
}

// Update cards
function updateCards(cards) {
  if (!cards || cards.length !== 2) return;
  const [dragonCard, tigerCard] = cards;
  const dragonValue = dragonCard.value.replace('10', '0');
  const tigerValue = tigerCard.value.replace('10', '0');
  elements.dragonCard.src = `https://deckofcardsapi.com/static/img/${dragonValue}${dragonCard.suit}.png`;
  elements.tigerCard.src = `https://deckofcardsapi.com/static/img/${tigerValue}${tigerCard.suit}.png`;
  elements.dragonCard.classList.add('animate__animated', 'animate__flipInY');
  elements.tigerCard.classList.add('animate__animated', 'animate__flipInY');
  setTimeout(() => {
    elements.dragonCard.classList.remove('animate__animated', 'animate__flipInY');
    elements.tigerCard.classList.remove('animate__animated', 'animate__flipInY');
  }, 1000);
  if (gameState.soundEnabled) sounds.deal.play();
}

// Update result
async function updateResult(data) {
  const playerWon = data.result.toLowerCase() === gameState.selectedBetType?.toLowerCase();
  let resultText = `Result: ${data.result} (Dragon: ${data.dragonValue}, Tiger: ${data.tigerValue})`;
  let resultClass = playerWon ? 'win' : 'lose';
  if (playerWon && gameState.currentBet > 0) {
    const odds = { dragon: 1, tiger: 1, tie: 8 }[gameState.selectedBetType.toLowerCase()];
    const winnings = gameState.currentBet * (odds + 1);
    resultText += ` - You win ${winnings}!`;
    if (gameState.soundEnabled) sounds.win.play();
  } else if (gameState.currentBet > 0) {
    resultText += ` - You lose ${gameState.currentBet}`;
    if (gameState.soundEnabled) sounds.lose.play();
  }
  elements.result.textContent = resultText;
  elements.result.className = `result-display ${resultClass}`;
}

// Reset game
function resetGame() {
  gameState.currentBet = 0;
  gameState.selectedBetType = null;
  gameState.gameInProgress = false;
  elements.dealBtn.disabled = true;
  elements.dealBtn.textContent = 'Waiting for Round...';
  elements.resetBtn.disabled = true;
  elements.currentBetAmount.textContent = '0';
  elements.currentBetType.textContent = '-';
  elements.betOptions.forEach(opt => opt.classList.remove('selected'));
  elements.result.textContent = '';
  elements.result.className = 'result-display';
  elements.dragonCard.src = 'https://deckofcardsapi.com/static/img/back.png';
  elements.tigerCard.src = 'https://deckofcardsapi.com/static/img/back.png';
  clearCountdown();
}

// Update UI
function updateUI() {
  elements.balance.textContent = gameState.balance;
  elements.balance.classList.add('animate__animated', 'animate__pulse');
  setTimeout(() => elements.balance.classList.remove('animate__animated', 'animate__pulse'), 500);
}

// Update history
function updateHistory() {
  elements.historyItems.innerHTML = '';
  for (let i = 0; i < Math.min(5, gameState.results.length); i++) {
    const result = gameState.results[i];
    if (result.game !== 'dragontiger') continue;
    const item = document.createElement('div');
    item.className = `history-item ${result.outcome}`;
    item.textContent = result.outcome === 'won' ? `+${result.amount}` : result.amount;
    elements.historyItems.appendChild(item);
  }
}

// Fetch bet history
async function fetchBetHistory() {
  try {
    const response = await fetch(`http://localhost:5000/api/my_bet_history/${gameState.userId}`);
    if (!response.ok) throw new Error('Failed to fetch bet history');
    const data = await response.json();
    gameState.results = data.bets.map(bet => ({
      game: bet.game,
      outcome: bet.outcome,
      amount: bet.amount,
      betType: bet.betType,
      createdAt: bet.createdAt,
    }));
    updateHistory();
  } catch (error) {
    console.error('Error fetching bet history:', error);
    showToast('Error fetching bet history', 'error');
  }
}

// Sound toggle
function toggleSound() {
  gameState.soundEnabled = !gameState.soundEnabled;
  elements.soundToggle.innerHTML = `<i class="fas fa-volume-${gameState.soundEnabled ? 'up' : 'mute'}"></i>`;
  Object.values(sounds).forEach(sound => {
    sound.muted = !gameState.soundEnabled;
  });
}

// Event listeners
elements.betOptions.forEach(option => {
  option.addEventListener('click', () => {
    if (!gameState.gameInProgress) {
      const betType = option.id.replace('bet-', '');
      placeBet(betType);
    }
  });
});

elements.chips.forEach(chip => {
  chip.addEventListener('click', () => {
    elements.amountInput.value = chip.dataset.amount;
    chip.classList.add('active');
    setTimeout(() => chip.classList.remove('active'), 200);
    if (gameState.selectedBetType) placeBet(gameState.selectedBetType);
    if (gameState.soundEnabled) sounds.chip.play();
  });
});

elements.amountInput.addEventListener('input', function () {
  let value = parseInt(this.value);
  if (isNaN(value)) value = 50;
  else if (value < 50) value = 50;
  else if (value > gameState.balance) value = gameState.balance;
  this.value = value;
});

elements.dealBtn.addEventListener('click', () => {
  if (gameState.selectedBetType) placeBet(gameState.selectedBetType);
  else showToast('Please select a bet type', 'error');
});

elements.resetBtn.addEventListener('click', resetGame);

elements.helpBtn.addEventListener('click', () => {
  alert('Dragon Tiger: Bet on whether Dragon or Tiger will have the higher card, or if they will tie. Dragon/Tiger pays 1:1, Tie pays 8:1.');
});

elements.soundToggle.addEventListener('click', toggleSound);

// Initialize history
fetchBetHistory();