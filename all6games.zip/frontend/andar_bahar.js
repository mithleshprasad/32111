   
        // Game state
        const userId = localStorage.getItem('userId') || 'test-user';
        const gameState = {
            balance: 0,
            currentBet: 0,
            selectedBet: null,
            gameInProgress: false,
            userId,
            gameHistory: [],
            jokerCard: null,
            gamePhase: 'accepting_bets',
            andarCards: [],
            baharCards: [],
            soundEnabled: true,
            countdown: null
        };

        // DOM elements
        const elements = {
            balance: document.getElementById('balance'),
            betAmountInput: document.getElementById('amount'),
            betAndar: document.getElementById('bet-andar'),
            betBahar: document.getElementById('bet-bahar'),
            jokerCard: document.getElementById('joker-card'),
            andarCards: document.getElementById('andar-cards'),
            baharCards: document.getElementById('bahar-cards'),
            andarCounter: document.getElementById('andar-counter'),
            baharCounter: document.getElementById('bahar-counter'),
            resultDisplay: document.getElementById('result'),
            currentBetAmount: document.getElementById('current-bet-amount'),
            currentBetType: document.getElementById('current-bet-type'),
            betHistoryModal: document.getElementById('bet-history-modal'),
            gameHistoryModal: document.getElementById('game-history-modal'),
            betHistoryItems: document.getElementById('bet-history-items'),
            gameHistoryItems: document.getElementById('game-history-items'),
            soundToggle: document.getElementById('sound-toggle'),
            helpBtn: document.getElementById('help-btn'),
            betHistoryBtn: document.getElementById('bet-history-btn'),
            gameHistoryBtn: document.getElementById('game-history-btn'),
            closeBetHistory: document.getElementById('close-bet-history'),
            closeGameHistory: document.getElementById('close-game-history'),
            chips: document.querySelectorAll('.chip')
        };

        // Audio elements
        const audio = {
            deal: document.getElementById('dealSound'),
            win: document.getElementById('winSound'),
            lose: document.getElementById('loseSound'),
            chip: document.getElementById('chipSound')
        };

        // WebSocket connection
        const ws = new WebSocket('ws://localhost:5000');
        ws.onopen = async () => {
            console.log('Connected to WebSocket server');
            try {
                await fetchBalance();
                await fetchCurrentRound();
                await fetchBetHistory();
                showToast('Connected to Andar Bahar', 'success');
            } catch (error) {
                console.error('Error initializing:', error);
                showToast('Error initializing game', 'error');
            }
        };

        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (data.game !== 'andarbahar') return;
                handleWebSocketMessage(data);
            } catch (error) {
                console.error('Error parsing WebSocket message:', error);
                showToast('Invalid server message', 'error');
            }
        };

        ws.onclose = () => {
            console.error('WebSocket connection closed');
            showToast('Connection lost, please refresh', 'error');
            clearCountdown();
        };

        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            showToast('Connection error, please refresh', 'error');
            clearCountdown();
        };

        // Toast notification
        function showToast(message, type = 'error') {
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.textContent = message;
            document.body.appendChild(toast);
            setTimeout(() => toast.classList.add('show'), 100);
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        // Fetch user balance
        async function fetchBalance() {
            try {
                const response = await fetch(`http://localhost:5000/api/balance/${gameState.userId}`);
                if (!response.ok) throw new Error('Failed to fetch balance');
                const data = await response.json();
                gameState.balance = data.balance || 0;
                updateBalance();
            } catch (error) {
                console.error('Error fetching balance:', error);
                showToast('Error fetching balance', 'error');
            }
        }

        // Fetch current round
        async function fetchCurrentRound() {
            try {
                const response = await fetch(`http://localhost:5000/api/current-round/andarbahar`);
                if (!response.ok) throw new Error('Failed to fetch round');
                const data = await response.json();
                gameState.jokerCard = data.jokerCard;
                gameState.andarCards = data.cards ? data.cards.filter(c => c.side === 'andar').map(c => c.card) : [];
                gameState.baharCards = data.cards ? data.cards.filter(c => c.side === 'bahar').map(c => c.card) : [];
                gameState.gamePhase = data.status;
                setRound(data);
                updateJokerCard();
                updateCards();
                if (data.status === 'accepting_bets') {
                    startCountdown(Math.floor((new Date(data.bettingEndTime) - Date.now()) / 1000));
                } else if (data.status === 'no_more_bets') {
                } else if (data.status === 'joker_dealt') {
                } else if (data.status === 'result') {
                    updateResult(data);
                }
            } catch (error) {
                console.error('Error fetching round:', error);
                showToast('Error fetching round', 'error');
            }
        }

        // Handle WebSocket messages
        function handleWebSocketMessage(data) {
            switch (data.type) {
                case 'connection':
                    showToast(data.message, 'success');
                    break;
                case 'newRound':
                    resetGame();
                    gameState.gameInProgress = false;
                    gameState.gamePhase = 'accepting_bets';
                    startCountdown(30);
                    showToast(`New Round ${data.roundNumber}`, 'success');
                    setRound(data);
                    break;
                case 'bettingClosed':
                    gameState.gameInProgress = true;
                    gameState.gamePhase = 'no_more_bets';
                    clearCountdown();
                    showToast(`Betting closed for Round ${data.roundNumber}`, 'error');
                    setRound(data);
                    break;
                case 'jokerDealt':
                    gameState.jokerCard = data.jokerCard;
                    gameState.gamePhase = 'joker_dealt';
                    updateJokerCard();
                    showToast('Joker card dealt', 'success');
                    setRound(data);
                    break;
                case 'cardDealt':
                    gameState.gamePhase = 'joker_dealt';
                    gameState.andarCards = data.cards.filter(c => c.side === 'andar').map(c => c.card);
                    gameState.baharCards = data.cards.filter(c => c.side === 'bahar').map(c => c.card);
                    updateCards();
                    showToast(`Card dealt to ${data.currentSide}`, 'success');
                    playSound(audio.deal);
                    setRound(data);
                    break;
                case 'roundResult':
                    gameState.gamePhase = 'result';
                    gameState.andarCards = data.cards.filter(c => c.side === 'andar').map(c => c.card);
                    gameState.baharCards = data.cards.filter(c => c.side === 'bahar').map(c => c.card);
                    updateCards();
                    updateResult(data);
                    fetchBalance();
                    fetchBetHistory();
                    showToast(`Round ${data.roundNumber} Result: ${data.winner.toUpperCase()} wins!`, 'success');
                    setRound(data);
                    break;
                case 'betPlaced':
                    gameState.currentBet = data.amount;
                    gameState.selectedBet = data.betType;
                    showToast(`Bet of ${data.amount} placed on ${data.betType}`, 'success');
                    fetchBalance();
                    updateBalance();
                    break;
                case 'error':
                    showToast(data.message, 'error');
                    if (data.message === 'No active betting round') {
                        resetGame();
                    }
                    break;
                default:
                    console.warn('Unknown message type:', data.type);
            }
        }

        // Set round data
        function setRound(data) {
            gameState.round = {
                roundNumber: data.roundNumber,
                status: data.status,
                jokerCard: data.jokerCard,
                cards: data.cards || [],
                winner: data.winner,
                bettingEndTime: data.bettingEndTime,
                resultTime: data.resultTime
            };
        }

        // Countdown timer
        function startCountdown(seconds) {
            if (seconds <= 0) return;
            clearCountdown();
            let timeLeft = seconds;
            elements.resultDisplay.textContent = `Time to bet: ${timeLeft}s`;
            gameState.countdown = setInterval(() => {
                timeLeft--;
                elements.resultDisplay.textContent = `Time to bet: ${timeLeft}s`;
                if (timeLeft <= 0) {
                    clearCountdown();
                    gameState.gameInProgress = true;
                }
            }, 1000);
        }

        function clearCountdown() {
            if (gameState.countdown) {
                clearInterval(gameState.countdown);
                gameState.countdown = null;
            }
            if (!elements.resultDisplay.textContent.includes('Result:')) {
                elements.resultDisplay.textContent = '';
            }
        }

        // Place a bet
        function placeBet(betType) {
            if (gameState.gameInProgress && gameState.gamePhase !== 'accepting_bets') {
                showToast('Betting is closed for this round', 'error');
                return;
            }
            const betAmount = parseInt(elements.betAmountInput.value);
            if (isNaN(betAmount) || betAmount < 50) {
                showToast('Minimum bet is 50', 'error');
                return;
            }
            if (betAmount > gameState.balance) {
                showToast('Insufficient balance', 'error');
                return;
            }
            const validBetTypes = ['andar', 'bahar'];
            if (!validBetTypes.includes(betType)) {
                showToast('Invalid bet type', 'error');
                return;
            }
            gameState.selectedBet = betType;
            elements.betAndar.classList.remove('selected');
            elements.betBahar.classList.remove('selected');
            document.getElementById(`bet-${betType}`).classList.add('selected', 'animate__animated', 'animate__pulse');
            setTimeout(() => document.getElementById(`bet-${betType}`).classList.remove('animate__animated', 'animate__pulse'), 1000);
            elements.currentBetAmount.textContent = betAmount.toLocaleString();
            elements.currentBetType.textContent = betType.charAt(0).toUpperCase() + betType.slice(1);
            ws.send(JSON.stringify({
                game: 'andarbahar',
                type: 'placeBet',
                userId: gameState.userId,
                amount: betAmount,
                betType
            }));
            playSound(audio.chip);
        }

        // Update joker card
        function updateJokerCard() {
            if (gameState.jokerCard) {
                const cardValue = gameState.jokerCard.value === '10' ? '0' : gameState.jokerCard.value;
                elements.jokerCard.src = `https://deckofcardsapi.com/static/img/${cardValue}${gameState.jokerCard.suit}.png`;
                elements.jokerCard.classList.add('card-deal', 'animate__animated', 'animate__flipInY');
                setTimeout(() => elements.jokerCard.classList.remove('card-deal', 'animate__animated', 'animate__flipInY'), 1000);
                playSound(audio.deal);
            }
        }

        // Update cards
        function updateCards() {
            elements.andarCards.innerHTML = '';
            elements.baharCards.innerHTML = '';
            gameState.andarCards.forEach((card, index) => {
                const cardSlot = document.createElement('div');
                cardSlot.className = 'card-slot';
                cardSlot.style.zIndex = String(0 + index);
                const img = document.createElement('img');
                const cardValue = card.value === '10' ? '0' : card.value;
                img.src = `https://deckofcardsapi.com/static/img/${cardValue}${card.suit}.png`;
                img.altvoitement
                img.alt = `${card.value} of ${card.suit}`;
                img.classList.add('card-deal', 'animate__animated', 'animate__flipInY');
                cardSlot.appendChild(img);
                elements.andarCards.appendChild(cardSlot);
                setTimeout(() => img.classList.remove('card-deal', 'animate__animated', 'animate__flipInY'), 1000);
            });
            gameState.baharCards.forEach((card, index) => {
                const cardSlot = document.createElement('div');
                cardSlot.className = 'card-slot';
                cardSlot.style.zIndex = String(0 + index);
                const img = document.createElement('img');
                const cardValue = card.value === '10' ? '0' : card.value;
                img.src = `https://deckofcardsapi.com/static/img/${cardValue}${card.suit}.png`;
                img.alt = `${card.value} of ${card.suit}`;
                img.classList.add('card-deal', 'animate__animated', 'animate__flipInY');
                cardSlot.appendChild(img);
                elements.baharCards.appendChild(cardSlot);
                setTimeout(() => img.classList.remove('card-deal', 'animate__animated', 'animate__flipInY'), 1000);
            });
            elements.andarCounter.textContent = `Cards: ${gameState.andarCards.length}`;
            elements.baharCounter.textContent = `Cards: ${gameState.baharCards.length}`;
            if (gameState.andarCards.length > 0 || gameState.baharCards.length > 0) {
                playSound(audio.deal);
            }
        }

        // Update result
        function updateResult(data) {
            const playerWon = data.winner === gameState.selectedBet;
            let resultText = `Result: ${data.winner.toUpperCase()} wins!`;
            let resultClass = playerWon ? 'win' : 'lose';
            if (playerWon && gameState.currentBet > 0) {
                const winnings = gameState.currentBet * 2;
                resultText += ` - You win ${winnings.toLocaleString()}!`;
                playSound(audio.win);
                elements.resultDisplay.classList.add('animate__animated', 'animate__tada');
            } else if (gameState.currentBet > 0) {
                resultText += ` - You lose ${gameState.currentBet.toLocaleString()}`;
                playSound(audio.lose);
            }
            elements.resultDisplay.textContent = resultText;
            elements.resultDisplay.className = `result-display ${resultClass}`;
            setTimeout(() => elements.resultDisplay.classList.remove('animate__animated', 'animate__tada'), 1000);
            addToHistory(data.winner, resultClass);
        }

        // Reset game
        function resetGame() {
            gameState.currentBet = 0;
            gameState.selectedBet = null;
            gameState.gameInProgress = false;
            gameState.gamePhase = 'accepting_bets';
            gameState.jokerCard = null;
            gameState.andarCards = [];
            gameState.baharCards = [];
            elements.currentBetAmount.textContent = '0';
            elements.currentBetType.textContent = '-';
            elements.betAndar.classList.remove('selected');
            elements.betBahar.classList.remove('selected');
            elements.resultDisplay.textContent = '';
            elements.resultDisplay.className = 'result-display';
            elements.jokerCard.src = 'https://deckofcardsapi.com/static/img/back.png';
            elements.andarCards.innerHTML = '';
            elements.baharCards.innerHTML = '';
            elements.andarCounter.textContent = 'Cards: 0';
            elements.baharCounter.textContent = 'Cards: 0';
            elements.chips.forEach(chip => chip.classList.remove('active'));
            clearCountdown();
        }

        // Update balance
        function updateBalance() {
            elements.balance.textContent = gameState.balance.toLocaleString();
            elements.balance.parentElement.classList.add('animate__animated', 'animate__pulse');
            setTimeout(() => elements.balance.parentElement.classList.remove('animate__animated', 'animate__pulse'), 500);
        }

        // Add to history
        function addToHistory(winner, outcome) {
            const historyItem = document.createElement('div');
            historyItem.className = `history-item ${outcome}`;
            const icon = document.createElement('i');
            icon.className = winner === 'andar' ? 'fas fa-arrow-left' : 'fas fa-arrow-right';
            const outcomeText = document.createElement('div');
            outcomeText.className = 'outcome';
            outcomeText.textContent = outcome === 'win' ? 'Win' : 'Lose';
            historyItem.appendChild(icon);
            historyItem.appendChild(outcomeText);
            historyItem.classList.add('animate__animated', 'animate__fadeIn');
            elements.gameHistoryItems.insertBefore(historyItem, elements.gameHistoryItems.firstChild);
            if (elements.gameHistoryItems.children.length > 10) {
                elements.gameHistoryItems.removeChild(elements.gameHistoryItems.lastChild);
            }
        }

        // Fetch bet history
        async function fetchBetHistory() {
            try {
                const response = await fetch(`http://localhost:5000/api/my_bet_history/${gameState.userId}`);
                if (!response.ok) throw new Error('Failed to fetch bet history');
                const data = await response.json();
                console.log('Fetched bet history:', data);
                gameState.gameHistory = data.bets
                    .filter(bet => bet.game === 'andarbahar')
                    .map(bet => ({
                        winner: bet.status === 'won' ? bet.betType : (bet.betType === 'andar' ? 'bahar' : 'andar'),
                        outcome: bet.status === 'won' ? 'win' : 'lose',
                        winLossAmount: bet.winAmount == 0 ? -bet.lossAmount : bet.winAmount,
                    }));
                updateHistory();
            } catch (error) {
                console.error('Error fetching bet history:', error);
                showToast('Error fetching bet history', 'error');
            }
        }

        // Update history
        function updateHistory() {
            elements.betHistoryItems.innerHTML = '';
            elements.gameHistoryItems.innerHTML = '';
            for (let i = 0; i < Math.min(10, gameState.gameHistory.length); i++) {
                const { winner, outcome, winLossAmount } = gameState.gameHistory[i];
                const betHistoryItem = document.createElement('div');
                betHistoryItem.className = `history-item ${outcome}`;
                const betIcon = document.createElement('i');
                betIcon.className = winner === 'andar' ? 'fas fa-arrow-left' : 'fas fa-arrow-right';
                const betOutcomeText = document.createElement('div');
                betOutcomeText.className = 'outcome';
                betOutcomeText.textContent = `${outcome === 'win' ? 'Win' : 'Lose'} ${winLossAmount}`;
                betHistoryItem.appendChild(betIcon);
                betHistoryItem.appendChild(betOutcomeText);
                elements.betHistoryItems.appendChild(betHistoryItem);

                const gameHistoryItem = document.createElement('div');
                gameHistoryItem.className = `history-item ${outcome}`;
                const gameIcon = document.createElement('i');
                gameIcon.className = winner === 'andar' ? 'fas fa-arrow-left' : 'fas fa-arrow-right';
                const gameOutcomeText = document.createElement('div');
                gameOutcomeText.className = 'outcome';
                gameOutcomeText.textContent = outcome === 'win' ? 'Win' : 'Lose';
                gameHistoryItem.appendChild(gameIcon);
                gameHistoryItem.appendChild(gameOutcomeText);
                elements.gameHistoryItems.appendChild(gameHistoryItem);
            }
        }

        // Play sound
        function playSound(sound) {
            if (gameState.soundEnabled) {
                sound.currentTime = 0;
                sound.play().catch(e => console.log('Sound play prevented:', e));
            }
        }

        // Toggle sound
        function toggleSound() {
            gameState.soundEnabled = !gameState.soundEnabled;
            elements.soundToggle.innerHTML = `<i class="fas fa-volume-${gameState.soundEnabled ? 'up' : 'mute'}"></i>`;
        }

        // Show help
        function showHelp() {
            alert(`Andar Bahar Game Rules:\n\n1. Place your bet on Andar (left) or Bahar (right)\n2. The dealer reveals a joker card\n3. Cards are dealt alternately to Andar and Bahar\n4. The game continues until a card matches the joker's value\n5. If the match is on your chosen side, you win!\n6. Payouts:\n   - Andar/Bahar: 1:1\n\nNote: The first card always goes to Andar\n\nGood luck!`);
        }

        // Modal controls
        function openModal(modal) {
            modal.style.display = 'flex';
        }

        function closeModal(modal) {
            modal.style.display = 'none';
        }

        // Event listeners
        elements.betAndar.addEventListener('click', () => placeBet('andar'));
        elements.betBahar.addEventListener('click', () => placeBet('bahar'));
        elements.betHistoryBtn.addEventListener('click', () => openModal(elements.betHistoryModal));
        elements.gameHistoryBtn.addEventListener('click', () => openModal(elements.gameHistoryModal));
        elements.closeBetHistory.addEventListener('click', () => closeModal(elements.betHistoryModal));
        elements.closeGameHistory.addEventListener('click', () => closeModal(elements.gameHistoryModal));
        elements.soundToggle.addEventListener('click', toggleSound);
        elements.helpBtn.addEventListener('click', showHelp);

        elements.chips.forEach(chip => {
            chip.addEventListener('click', () => {
                playSound(audio.chip);
                elements.chips.forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                elements.betAmountInput.value = chip.dataset.amount;
                if (gameState.selectedBet) placeBet(gameState.selectedBet);
            });
        });

        elements.betAmountInput.addEventListener('input', () => {
            let value = parseInt(elements.betAmountInput.value);
            if (isNaN(value)) value = 50;
            else if (value < 50) value = 50;
            else if (value > gameState.balance) value = gameState.balance;
            elements.betAmountInput.value = value;
            if (gameState.selectedBet) placeBet(gameState.selectedBet);
        });

        // Initialize bet history
        window.addEventListener('load', fetchBetHistory);
  