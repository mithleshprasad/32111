const LuckyGameRound = require('./models/LuckyGameRound');
const LuckyBet = require('./models/LuckyBet');
const User = require('../../models/User');
const { cardValues, resetDeck, getDeck } = require('./deck');
const WebSocket = require('ws');
function broadcast(wss, message, game = 'lucky7') {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ ...message, game }));
    }
  });
}

async function processBets(roundId, result, color, isOdd) {
  try {
    const bets = await LuckyBet.find({ gameRoundId: roundId, status: 'pending' });
    for (const bet of bets) {
      let winCondition = false;
      if (bet.betType.toLowerCase() === result.toLowerCase()) winCondition = true;
      else if (['red', 'black'].includes(bet.betType.toLowerCase()) && bet.betType.toLowerCase() === color) winCondition = true;
      else if (['odd', 'even'].includes(bet.betType.toLowerCase()) && (bet.betType.toLowerCase() === 'odd' ? isOdd : !isOdd)) winCondition = true;

      if (winCondition) {
        const payout = bet.amount * (bet.odds + 1);
        bet.payout = payout;
        bet.status = 'won';
        await User.findByIdAndUpdate(bet.userId, { $inc: { balance: payout } });
        console.log(`Lucky7 Bet ${bet._id} won: ${bet.betType}, payout: ${payout}`);
      } else {
        bet.payout = 0;
        bet.status = 'lost';
        console.log(`Lucky7 Bet ${bet._id} lost: ${bet.betType}`);
      }
      await bet.save();
    }
  } catch (error) {
    console.error('Error processing Lucky7 bets:', error);
  }
}

async function startNewRound(wss) {
  try {
    const lastRound = await LuckyGameRound.findOne().sort({ roundNumber: -1 });
    const roundNumber = lastRound ? lastRound.roundNumber + 1 : 1;

    resetDeck();
    const currentRound = new LuckyGameRound({
      roundNumber,
      status: 'accepting_bets',
      bettingEndTime: new Date(Date.now() + 30000),
    });
    await currentRound.save();
    console.log(`Starting new Lucky7 round: ${roundNumber}`);

    broadcast(wss, {
      type: 'newRound',
      roundNumber: currentRound.roundNumber,
      status: currentRound.status,
      bettingEndTime: currentRound.bettingEndTime,
    });

    setTimeout(async () => {
      currentRound.status = 'no_more_bets';
      await currentRound.save();

      broadcast(wss, {
        type: 'bettingClosed',
        roundNumber: currentRound.roundNumber,
      });

      const bets = await LuckyBet.find({ gameRoundId: currentRound._id, status: 'pending' });
      const betTotals = {
        '7up': 0, '7down': 0, 'lucky7': 0, 'red': 0, 'black': 0, 'odd': 0, 'even': 0,
      };

      bets.forEach(bet => {
        betTotals[bet.betType.toLowerCase()] += bet.amount;
      });

      let maxBetType = null;
      let maxBetAmount = 0;
      for (const [betType, total] of Object.entries(betTotals)) {
        if (total > maxBetAmount) {
          maxBetAmount = total;
          maxBetType = betType;
        }
      }

      let card, total, result, color, isOdd;
      const deck = getDeck();
      if (!maxBetType) {
        maxBetType = ['7up', '7down', 'lucky7'][Math.floor(Math.random() * 3)];
        card = deck.splice(0, 1)[0];
        total = cardValues[card.value];
        result = total === 7 ? 'lucky7' : total < 7 ? '7down' : '7up';
        color = { 'H': 'red', 'D': 'red', 'S': 'black', 'C': 'black' }[card.suit];
        isOdd = total % 2 !== 0;
      } else {
        const validCards = deck.filter(c => {
          const val = cardValues[c.value];
          if (maxBetType === '7up') return val < 7;
          if (maxBetType === '7down') return val > 7;
          if (maxBetType === 'lucky7') return val !== 7;
          if (maxBetType === 'red') return ['S', 'C'].includes(c.suit);
          if (maxBetType === 'black') return ['H', 'D'].includes(c.suit);
          if (maxBetType === 'odd') return val % 2 === 0;
          if (maxBetType === 'even') return val % 2 !== 0;
          return false;
        });

        card = validCards[Math.floor(Math.random() * validCards.length)] || deck[0];
        deck.splice(deck.indexOf(card), 1);
        total = cardValues[card.value];
        result = total === 7 ? 'lucky7' : total < 7 ? '7down' : '7up';
        color = { 'H': 'red', 'D': 'red', 'S': 'black', 'C': 'black' }[card.suit];
        isOdd = total % 2 !== 0;
      }

      currentRound.status = 'dealing';
      currentRound.cards = [card];
      currentRound.total = total;
      currentRound.result = result;
      await currentRound.save();

      broadcast(wss, {
        type: 'cardsDealt',
        roundNumber: currentRound.roundNumber,
        cards: [card],
        total,
        result,
        color,
        isOdd,
      });

      setTimeout(async () => {
        await processBets(currentRound._id, result, color, isOdd);
        currentRound.status = 'result';
        currentRound.winnerAnnouncedTime = new Date();
        await currentRound.save();

        broadcast(wss, {
          type: 'roundResult',
          roundNumber: currentRound.roundNumber,
          result,
          total,
          cards: [card],
          color,
          isOdd,
          winnerAnnouncedTime: currentRound.winnerAnnouncedTime,
        });

        setTimeout(() => startNewRound(wss), 10000);
      }, 5000);
    }, 30000);
  } catch (error) {
    console.error(`Error in Lucky7 round ${roundNumber}:`, error);
    broadcast(wss, {
      type: 'error',
      message: 'Error in game round',
    });
    setTimeout(() => startNewRound(wss), 5000);
  }
}

module.exports = { startNewRound, processBets, broadcast };