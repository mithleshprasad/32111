const mongoose = require('mongoose');

const LuckyBetSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  gameRoundId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'LuckyGameRound',
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  betType: {
    type: String,
    enum: ['7up', '7down', 'lucky7', 'red', 'black', 'odd', 'even'],
    required: true,
  },
  odds: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
    enum: ['pending', 'won', 'lost'],
    default: 'pending',
  },
  payout: {
    type: Number,
    default: 0,
  },
}, { timestamps: true });

module.exports = mongoose.model('LuckyBet', LuckyBetSchema);