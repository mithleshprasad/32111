const LuckyGameRound = require('./models/LuckyGameRound');
const LuckyBet = require('./models/LuckyBet');
const User = require('../../models/User');

function setupWebSocket(wss, game = 'lucky7') {
  wss.on('connection', (ws) => {
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message);
        if (data.game !== game || data.type !== 'placeBet') return;

        const round = await LuckyGameRound.findOne({ status: 'accepting_bets' }).sort({ createdAt: -1 });
        if (!round) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'No active betting round',
          }));
        }
        const user = await User.findById(data.userId);
        if (!user) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'User not found',
          }));
        }
        if (data.amount > user.balance) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'Insufficient balance',
          }));
        }
        const validBetTypes = ['7up', '7down', 'lucky7', 'red', 'black', 'odd', 'even'];
        if (!validBetTypes.includes(data.betType.toLowerCase())) {
          return ws.send(JSON.stringify({
            game,
            type: 'error',
            message: 'Invalid bet type',
          }));
        }
        user.balance -= data.amount;
        await user.save();

        const odds = { '7up': 1, '7down': 1, 'lucky7': 11, 'red': 0.9, 'black': 0.9, 'odd': 0.8, 'even': 0.8 }[data.betType.toLowerCase()];
        const bet = new LuckyBet({
          userId: data.userId,
          gameRoundId: round._id,
          amount: data.amount,
          betType: data.betType.toLowerCase(),
          odds,
          status: 'pending',
        });
        await bet.save();

        ws.send(JSON.stringify({
          game,
          type: 'betPlaced',
          betId: bet._id,
          roundNumber: round.roundNumber,
          betType: data.betType,
          amount: data.amount,
        }));
      } catch (error) {
        console.error(`Error handling ${game} WebSocket message:`, error);
        ws.send(JSON.stringify({
          game,
          type: 'error',
          message: error.message,
        }));
      }
    });
  });
}

module.exports = { setupWebSocket };