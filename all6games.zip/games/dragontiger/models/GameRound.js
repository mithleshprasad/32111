const mongoose = require('mongoose');

const GameRoundSchema = new mongoose.Schema({
  roundNumber: {
    type: Number,
    required: true,
    unique: true,
  },
  status: {
    type: String,
    enum: ['accepting_bets', 'no_more_bets', 'result'],
    default: 'accepting_bets',
  },
  bettingEndTime: Date,
  winner: {
    type: String,
    enum: ['dragon', 'tiger', 'tie'],
  },
  cards: [{
    side: String,
    card: { value: String, suit: String },
    value: Number,
  }],
  bets: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'DragonTigerBet',
  }],
  resultTime: Date,
}, { timestamps: true });

module.exports = mongoose.model('DragonTigerGameRound', GameRoundSchema);