const GameRound = require('./models/GameRound');
const Bet = require('./models/Bet');
const User = require('../../models/User');
const { cardValues, resetDeck, getDeck } = require('./deck');
const WebSocket = require('ws');
function broadcast(wss, message, game = '32card') {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ ...message, game }));
    }
  });
}

async function processBets(roundId, winningPlayer) {
  try {
    const bets = await Bet.find({ gameRoundId: roundId, status: 'pending' });
    for (const bet of bets) {
      if (bet.selectedPlayer === winningPlayer) {
        const payout = bet.amount * (bet.odds + 1);
        bet.payout = payout;
        bet.status = 'won';
        await User.findByIdAndUpdate(bet.userId, { $inc: { balance: payout } });
        console.log(`32Card Bet ${bet._id} won: Player ${bet.selectedPlayer}, payout: ${payout}`);
      } else {
        bet.payout = 0;
        bet.status = 'lost';
        console.log(`32Card Bet ${bet._id} lost: Player ${bet.selectedPlayer}`);
      }
      await bet.save();
    }
  } catch (error) {
    console.error('Error processing 32Card bets:', error);
  }
}

async function reDealForTied(wss, tiedPlayers, currentRound) {
  try {
    broadcast(wss, {
      type: 'tieDetected',
      roundNumber: currentRound.roundNumber,
      tiedPlayers,
    });

    const deck = getDeck();
    const newCards = deck.splice(0, tiedPlayers.length);
    const newTotals = {};
    for (let i = 0; i < tiedPlayers.length; i++) {
      const playerNum = tiedPlayers[i];
      const cardValue = cardValues[newCards[i].value];
      newTotals[playerNum] = playerNum + cardValue;
    }

    broadcast(wss, {
      type: 'reDealCards',
      roundNumber: currentRound.roundNumber,
      cards: newCards.map((card, i) => ({
        player: tiedPlayers[i],
        card: { value: card.value, suit: card.suit },
        total: newTotals[tiedPlayers[i]],
      })),
    });

    setTimeout(async () => {
      let maxNewTotal = -1;
      let newWinners = [];
      for (const [playerNum, total] of Object.entries(newTotals)) {
        if (total > maxNewTotal) {
          maxNewTotal = total;
          newWinners = [parseInt(playerNum)];
        } else if (total === maxNewTotal) {
          newWinners.push(parseInt(playerNum));
        }
      }

      if (newWinners.length > 1) {
        await reDealForTied(wss, newWinners, currentRound);
        return;
      }

      currentRound.status = 'result';
      currentRound.winner = newWinners[0];
      currentRound.resultTime = new Date();
      await currentRound.save();

      await processBets(currentRound._id, newWinners[0]);

      broadcast(wss, {
        type: 'roundResult',
        roundNumber: currentRound.roundNumber,
        winner: newWinners[0],
        totals: newTotals,
        cards: newCards.map((card, i) => ({
          player: tiedPlayers[i],
          card: { value: card.value, suit: card.suit },
          total: newTotals[tiedPlayers[i]],
        })),
        resultTime: currentRound.resultTime,
      });

      setTimeout(() => startNewRound(wss), 10000);
    }, 5000);
  } catch (error) {
    console.error('Error in 32Card re-deal:', error);
    broadcast(wss, {
      type: 'error',
      message: 'Error in re-deal',
    });
    setTimeout(() => startNewRound(wss), 5000);
  }
}

async function startNewRound(wss) {
  try {
    const lastRound = await GameRound.findOne().sort({ roundNumber: -1 });
    const roundNumber = lastRound ? lastRound.roundNumber + 1 : 1;

    resetDeck();
    const currentRound = new GameRound({
      roundNumber,
      status: 'accepting_bets',
      bettingEndTime: new Date(Date.now() + 30000),
    });
    await currentRound.save();
    console.log(`Starting new 32Card round: ${roundNumber}`);

    broadcast(wss, {
      type: 'newRound',
      roundNumber: currentRound.roundNumber,
      status: currentRound.status,
      bettingEndTime: currentRound.bettingEndTime,
    });

    setTimeout(async () => {
      currentRound.status = 'no_more_bets';
      await currentRound.save();

      broadcast(wss, {
        type: 'bettingClosed',
        roundNumber: currentRound.roundNumber,
      });

      const deck = getDeck();
      const cards = deck.splice(0, 4);
      const playerTotals = {};
      for (let i = 0; i < 4; i++) {
        const playerNum = 8 + i;
        const cardValue = cardValues[cards[i].value];
        playerTotals[playerNum] = playerNum + cardValue;
      }

      currentRound.status = 'dealing';
      currentRound.cards = cards.map((card, i) => ({
        player: 8 + i,
        card: { value: card.value, suit: card.suit },
        total: playerTotals[8 + i],
      }));
      await currentRound.save();

      broadcast(wss, {
        type: 'cardsDealt',
        roundNumber: currentRound.roundNumber,
        cards: currentRound.cards,
      });

      setTimeout(async () => {
        let maxTotal = -1;
        let winners = [];
        for (const [playerNum, total] of Object.entries(playerTotals)) {
          if (total > maxTotal) {
            maxTotal = total;
            winners = [parseInt(playerNum)];
          } else if (total === maxTotal) {
            winners.push(parseInt(playerNum));
          }
        }

        if (winners.length > 1) {
          await reDealForTied(wss, winners, currentRound);
          return;
        }

        currentRound.status = 'result';
        currentRound.winner = winners[0];
        currentRound.resultTime = new Date();
        await currentRound.save();

        await processBets(currentRound._id, winners[0]);

        broadcast(wss, {
          type: 'roundResult',
          roundNumber: currentRound.roundNumber,
          winner: winners[0],
          totals: playerTotals,
          cards: currentRound.cards,
          resultTime: currentRound.resultTime,
        });

        setTimeout(() => startNewRound(wss), 10000);
      }, 5000);
    }, 30000);
  } catch (error) {
    console.error(`Error in 32Card round ${roundNumber}:`, error);
    broadcast(wss, {
      type: 'error',
      message: 'Error in game round',
    });
    setTimeout(() => startNewRound(wss), 5000);
  }
}

module.exports = { startNewRound, processBets, broadcast };