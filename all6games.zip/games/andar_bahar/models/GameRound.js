const mongoose = require('mongoose');

const andarBaharGameRoundSchema = new mongoose.Schema({
    roundNumber: { type: Number, required: true },
    status: { type: String, enum: ['accepting_bets', 'no_more_bets','joker_dealt', 'playing', 'result'], default: 'accepting_bets' },
    jokerCard: { type: Object, default: null }, // { value, suit }
    andarCards: [{ value: String, suit: String }],
    baharCards: [{ value: String, suit: String }],
     cards: [{
    side: String,
    card: { value: String, suit: String },
    value: Number,
  }],
    currentSide: { type: String, enum: ['andar', 'bahar'], default: 'andar' },
    matchFound: { type: Boolean, default: false },
    winner: { type: String, enum: ['andar', 'bahar', null], default: null },
    bettingEndTime: { type: Date },
    winnerAnnouncedTime: { type: Date }
}, { timestamps: true });

module.exports = mongoose.model('AndarBaharGameRound', andarBaharGameRoundSchema);