const mongoose = require('mongoose');

const andarBaharBetSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    gameRoundId: { type: mongoose.Schema.Types.ObjectId, ref: 'AndarBaharGameRound', required: true },
    roundNumber: { type: Number, required: true },
    amount: { type: Number, required: true },
    betType: { type: String, enum: ['andar', 'bahar'], required: true },
    odds: { type: Number, required: true },
    status: { type: String, enum: ['pending', 'won', 'lost'], default: 'pending' },
    payout: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('AndarBaharBet', andarBaharBetSchema);