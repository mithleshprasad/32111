const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const gameRoundSchema = new Schema({
  roundNumber: {
    type: Number,
    required: true,
    unique: true
  },
  status: {
    type: String,
    enum: ['accepting_bets', 'no_more_bets', 'wheel_spinning', 'completed'],
    default: 'accepting_bets'
  },
  winningNumber: {
    type: Number,
    min: 0,
    max: 36
  },
  bets: [{
    type: Schema.Types.ObjectId,
    ref: 'RouletteBet'
  }],
  startTime: {
    type: Date,
    default: Date.now
  },
  endTime: Date,
  bettingEndTime: Date,  // When betting phase ends
  wheelSpinTime: Date,   // When wheel starts spinning
  resultTime: Date,      // When result is declared
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Add methods to handle the game flow
gameRoundSchema.methods.startBettingPhase = function() {
  this.status = 'accepting_bets';
  this.startTime = new Date();
  this.bettingEndTime = new Date(Date.now() + 15000); // 15 seconds from now
  return this.save();
};

gameRoundSchema.methods.startWheelSpin = function() {
  this.status = 'wheel_spinning';
  this.wheelSpinTime = new Date();
  return this.save();
};

gameRoundSchema.methods.declareResult = function(winningNumber) {
  this.status = 'completed';
  this.winningNumber = winningNumber;
  this.endTime = new Date();
  this.resultTime = new Date(Date.now() + 10000); // 10 seconds from now
  return this.save();
};

module.exports = mongoose.model('GameRound', gameRoundSchema);