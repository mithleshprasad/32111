const mongoose = require('mongoose');

const BetSchema = new mongoose.Schema({
  userId: { 
    type: mongoose.Schema.Types.ObjectId,  
    ref: 'User',                         
    required: true
  },
  betAmount: {
    type: Number,
    required: true
  },
  cashOutMultiplier: {
    type: Number,
    default: null
  },
  Multiplier: {
    type: Number,
    default: null
  },
  gameRoundId:  { 
    type: String,
    required: true
  },
  betType: { type: String, enum: ['normal', 'auto'], default: 'normal' }, 
  hasCashedOut: {
    type: Boolean,
    default: false
  },
  winnings: {
    type: Number,
    default: 0
  },
  betStatus: {
    type: String,
    enum: ['active', 'canceled', 'cashed out'],
    default: 'active'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Bettleaviator', BetSchema);
