const mongoose = require('mongoose');

const betSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  gameRoundId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'GameRound',
    required: true
  },
  amount: {
    type: Number,
    required: true,
    min: 10
  },
  type: {
    type: String,
    enum: ['player'],
    required: true
  },
  selectedPlayer: {
    type: Number, // Player number (8, 9, 10, or 11)
    required: true
  },
  odds: {
    type: Number,
    default: 1 // 1:1 payout
  },
  payout: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    enum: ['pending', 'won', 'lost'],
    default: 'pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Bet', betSchema);