const mongoose = require('mongoose');

const gameRoundSchema = new mongoose.Schema({
  roundNumber: {
    type: Number,
    required: true,
    unique: true
  },
  status: {
    type: String,
    enum: ['accepting_bets', 'no_more_bets', 'dealing', 'result'],
    default: 'accepting_bets'
  },
  bettingEndTime: {
    type: Date
  },
  winner: {
    type: Number, // Player number (8, 9, 10, or 11)
    default: null
  },
  cards: [{
    player: Number, // Player number (8, 9, 10, or 11)
    card: {
      value: String, // e.g., '7', '8', 'A'
      suit: String // 'S', 'H', 'D', 'C'
    },
    total: Number // Player number + card value
  }],
  bets: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bet'
  }],
  resultTime: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('GameRound', gameRoundSchema);