const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");

const userSchema = new mongoose.Schema(
  {
    user_type: {
      type: String,
    },
    Name: {
      type: String,
    },
    otp: {
      type: String,
      default: "",
    },
    Email: {
      type: String,
      default: null,
    },
    Email_varified_at: {
      type: Date,
      default: null,
    },
    Phone: {
     type: String,
    },
    Mobile_varified_at: {
      type: Date,
      default: null,
    },
    Password: {
      type: String,
    },
    Referred_By: {
      type: Number,
      default: null,
    },
    Register_by: {
      type: String,
      default: "Self",
    },
    balance: {
      type: Number,
      default: 0,
    },
    hold_balanceAviator: {
      type: Number,
      default: 0,
    },
    balanceAviatorwin: {
      type: Number,
      default: 0,
    },
    turnamentAmount: {
      type: Number,
      default: 0,
    },
    turnamentWinAmount: {
      type: Number,
      default: 0,
    },
    user_status: {
      type: Number,
      default: 1,
    },
    user_status: {
      type: Number,
      default: 1,
    },

    device_key: {
      type: String,
      default: null,
    },
    ref_Commision: {
      type: Number,
      default: 1,
    },
    temp_token: {
      type: String,
      default: null,
    },
    LKID: {
      type: Number,
      default: null,
    },
    referral: {
      type: String,
      default: null,
    },
    referral_code: {
      type: String,
    
    },
    referral_earning: {
      type: Number,
      default: 0,
    },
    referral_wallet: {
      type: Number,
      default: 0,
    },
    holder_name: {
      type: String,
      default: null,
    },
    upi_id: {
      type: String,
      default: null,
    },
    account_number: {
      type: String,
      default: null,
    },
    ifsc_code: {
      type: String,
      default: null,
    },
    wonAmount: {
      type: Number,
      default: 0,
    },
    loseAmount: {
      type: Number,
      default: 0,
    },
    totalDeposit: {
      type: Number,
      default: 0,
    },
    totalBonus: {
      type: Number,
      default: 0,
    },
    totalPenalty: {
      type: Number,
      default: 0,
    },
    totalWithdrawl: {
      type: Number,
      default: 0,
    },
    block_reason: {
      type: String,
      default: null,
    },
    bap_reason: {
      type: String,
      default: null,
    },
    verified: {
      type: String,
      default: "unverified",
    },
    action_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null, //Added By team
    },
    withdrawAmount: {
      type: Number,
      default: 0,
      min: 0,
    },
    creatorWithdrawDeducted: {
      type: Number,
      default: null,
    },
    acceptorWithdrawDeducted: {
      type: Number,
      default: null,
    },
    withdraw_holdbalance: {
      type: Number,
      default: 0,
      min: 0,
    },
    avatar: {
      type: String,
    },

    cashOutCount: {
      type: Number,
      default: 0
    },
    cashOutAmount: {
      type: Number,
      default: 0
    },
    lossAmountAviator: {
      type: Number,
      default: 0
    },

    Permissions: [
      {
        Permission: {
          type: String,
          default: null,
        },
        Status: {
          type: Boolean,
          default: false,
        },
      },
    ],
    lastWitdrawl: {
      type: Number,
      default: null,
    },
    ipAddress: {
      type: String,
    },
    tokens: [
      {
        token: {
          type: String,
        },
      },
    ],
  },
  { timestamps: true }
);

userSchema.methods.genAuthToken = async function () {
  const user = this;
  const token = jwt.sign({ _id: user._id.toString() }, "qwertyuiopasdfghjkl");
  user.tokens = [{ token }];
  await user.save();
  return token;
};

const User = mongoose.model("User", userSchema);

module.exports = User;

