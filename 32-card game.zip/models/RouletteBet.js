const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const rouletteBetSchema = new Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  gameRoundId: {
    type: Schema.Types.ObjectId,
    ref: 'GameRound'
  },
  amount: {
    type: Number,
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['straight', 'split', 'street', 'corner', 'line', 'dozen', 'column', 'even_money']
  },
  odds: {
    type: Number,
    required: true
  },
  numbers: {
    type: [Number],
    required: true
  },
  payout: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    enum: ['pending', 'won', 'lost'],
    default: 'pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('RouletteBet', rouletteBetSchema);