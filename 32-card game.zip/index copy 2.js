const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
require("dotenv").config();
const http = require("http");
const connectDB = require("./config/db");
const path = require("path");
const WebSocket = require("ws");
const mongoose = require('mongoose');
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
const betRoutes = require("./routes/betRoutes");
const userRoutes = require("./routes/userRoutes");
const  GameRound = require("./models/GameRoundroll")
const Bet = require("./models/Betroll")
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
  console.log('New client connected');
  
  ws.send(JSON.stringify({
    type: 'connection',
    message: 'Welcome to Roulette WebSocket Server'
  }));

  ws.on('message', async (message) => {
    try {
      const data = JSON.parse(message);
      
      if (data.type === 'placeBet') {
        const round = await GameRound.findOne({ status: 'accepting_bets' });
        if (!round) {
          return ws.send(JSON.stringify({
            type: 'error',
            message: 'No active betting round'
          }));
        }
        const bet = new Bet({
          userId: data.userId,
          gameRoundId: round._id,
          amount: data.amount,
          type: data.betType,
          odds: data.odds,
          numbers: data.numbers
        });
        await bet.save();
        round.bets.push(bet._id);
        await round.save();
        ws.send(JSON.stringify({
          type: 'betPlaced',
          betId: bet._id,
          roundNumber: round.roundNumber
        }));
      }
    } catch (error) {
      console.error('Error handling message:', error);
      ws.send(JSON.stringify({
        type: 'error',
        message: error.message
      }));
    }
  });

  ws.on('close', () => console.log('Client disconnected'));
});
let currentRound = null;
async function startNewRound() {
  try {
    const lastRound = await GameRound.findOne().sort({ roundNumber: -1 });
    const roundNumber = lastRound ? lastRound.roundNumber + 1 : 1;
    
    currentRound = new GameRound({ roundNumber });
    await currentRound.startBettingPhase();
    
    broadcast({
      type: 'newRound',
      roundNumber: currentRound.roundNumber,
      status: currentRound.status,
      bettingEndTime: currentRound.bettingEndTime
    });

    setTimeout(async () => {
      currentRound.status = 'no_more_bets';
      await currentRound.save();
      
      broadcast({
        type: 'bettingClosed',
        roundNumber: currentRound.roundNumber
      });
     const winningNumber = Math.floor(Math.random() * 37);
     console.log("winningNumber",winningNumber)
      await currentRound.startWheelSpin();
      broadcast({
        type: 'wheelSpinning',
        winningNumber,
        roundNumber: currentRound.roundNumber
      });

      setTimeout(async () => {
       
        await currentRound.declareResult(winningNumber);
        await processBets(currentRound._id, winningNumber);
        
        broadcast({
          type: 'roundResult',
          roundNumber: currentRound.roundNumber,
          winningNumber,
          resultTime: currentRound.resultTime
        });

         setTimeout(startNewRound, 10000); 
      }, 5000);
    }, 30000);
  } catch (error) {
    console.error('Error in game round:', error);
    setTimeout(startNewRound, 5000);
  }
}

async function processBets(roundId, winningNumber) {
  const bets = await Bet.find({ gameRoundId: roundId });
  
  for (const bet of bets) {
    if (bet.numbers.includes(winningNumber)) {
      bet.payout = bet.amount * bet.odds;
      bet.status = 'won';
    } else {
      bet.payout = 0;
      bet.status = 'lost';
    }
    await bet.save();
  }
}

function broadcast(message) {
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  });
}
app.use("/api/bets", betRoutes);
app.use("/api/user", userRoutes);
// app.get('/api/bets', async (req, res) => {
//   try {
//     const { userId } = req.query;
//     const currentRound = await GameRound.findOne().sort({ createdAt: -1 });
    
//     if (!currentRound) {
//       return res.json([]);
//     }

//     const bets = await Bet.find({ 
//       userId,
//       gameRoundId: currentRound._id 
//     }).sort({ createdAt: -1 });

//     res.json(bets);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });
app.get('/api/current-round', async (req, res) => {
  try {
    const round = await GameRound.findOne().sort({ createdAt: -1 });
    res.json(round);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
app.use(express.static(path.join(__dirname, 'public')));
const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  // Start the game loop after DB connection
  startNewRound();
  
  server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});