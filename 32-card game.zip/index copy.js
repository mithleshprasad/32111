const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
require("dotenv").config();
const http = require("http");
const connectDB = require("./config/db");
// const authRoutes = require("./routes/auth");
const app = express();
const betRoutes = require("./routes/betRoutes");
// const gameRoutes = require("./routes/gameRoutes");
const path = require("path");
// const Bet = require('./models/Bet');
const WebSocket = require("ws");
const dotenv = require("dotenv");
// const adminRoutes = require("./routes/adminRoutes");
const userRoutes = require("./routes/userRoutes");
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
dotenv.config();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(bodyParser.json());
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

wss.on("connection", (ws) => {
  console.log("hddhdh")
  ws.on("message", (message) => {
    const data = JSON.parse(message);
    console.log("Client connected");
    if (data.type === "startGame") {

    }
  });

  ws.on("close", () => console.log("Client disconnected"));
});


const PORT = process.env.PORT || 5000;


app.use("/api/bets", betRoutes);
// app.use("/api/game", gameRoutes);
// app.use("/api/auth", authRoutes);
// app.use("/api/profile", authRoutes);
// app.use("/api/admin", adminRoutes);
app.use("/api/user",userRoutes);
connectDB().then(() => {
  server.listen(PORT, () => {
    console.log(`Server running on port in aws serversss ${PORT}`);
  });
});
