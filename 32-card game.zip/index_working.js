const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
require("dotenv").config();
const http = require("http");
const connectDB = require("./config/db");
const path = require("path");
const WebSocket = require("ws");
const mongoose = require('mongoose');
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(path.join(__dirname, "Uploads")));
const betRoutes = require("./routes/betRoutes");
const userRoutes = require("./routes/userRoutes");
const GameRound = require("./models/GameRoundroll");
const Bet = require("./models/Betroll");
const User = require("./models/User");

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const cardValues = {
    '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
};

const suits = ['S', 'H', 'D', 'C'];
const values = ['7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
let deck = [];
function resetDeck() {
    deck = [];
    for (const suit of suits) {
        for (const value of values) {
            deck.push({ value, suit });
        }
    }
    
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
}

wss.on('connection', (ws) => {
    console.log('New client connected');
    
    ws.send(JSON.stringify({
        type: 'connection',
        message: 'Welcome to 32-Card Showdown WebSocket Server'
    }));

    ws.on('message', async (message) => {
        try {
            const data = JSON.parse(message);
            
            if (data.type === 'placeBet') {
                const round = await GameRound.findOne({ status: 'accepting_bets' });
                if (!round) {
                    return ws.send(JSON.stringify({
                        type: 'error',
                        message: 'No active betting round'
                    }));
                }
                const user = await User.findById(data.userId);

                if (!user) {
                    return ws.send(JSON.stringify({
                        type: 'error',
                        message: 'User not found'
                    }));
                }
                if (data.amount > user.balance) {
                    return ws.send(JSON.stringify({
                        type: 'error',
                        message: 'Insufficient balance'
                    }));
                }
                await User.findByIdAndUpdate(data.userId, { $inc: { balance: -data.amount } });
                const bet = new Bet({
                    userId: data.userId,
                    gameRoundId: round._id,
                    amount: data.amount,
                    type: 'player',
                    selectedPlayer: data.selectedPlayer,
                    odds: 1
                });
                await bet.save();
                round.bets.push(bet._id);
                await round.save();
                ws.send(JSON.stringify({
                    type: 'betPlaced',
                    betId: bet._id,
                    roundNumber: round.roundNumber,
                    selectedPlayer: data.selectedPlayer
                }));
            }
        } catch (error) {
            console.error('Error handling message:', error);
            ws.send(JSON.stringify({
                type: 'error',
                message: error.message
            }));
        }
    });

    ws.on('close', () => console.log('Client disconnected'));
});

let currentRound = null;

async function startNewRound() {
    try {
        const lastRound = await GameRound.findOne().sort({ roundNumber: -1 });
        const roundNumber = lastRound ? lastRound.roundNumber + 1 : 1;
        
        resetDeck();
        currentRound = new GameRound({ 
            roundNumber, 
            status: 'accepting_bets',
            bettingEndTime: new Date(Date.now() + 30000)
        });
        await currentRound.save();
        console.log(`Starting new round: ${roundNumber}`);
        broadcast({
            type: 'newRound',
            roundNumber: currentRound.roundNumber,
            status: currentRound.status,
            bettingEndTime: currentRound.bettingEndTime
        });

        setTimeout(async () => {
            currentRound.status = 'no_more_bets';
            await currentRound.save();
            
            broadcast({
                type: 'bettingClosed',
                roundNumber: currentRound.roundNumber
            });

            const cards = deck.splice(0, 4);
            const playerTotals = {};
            for (let i = 0; i < 4; i++) {
                const playerNum = 8 + i;
                const cardValue = cardValues[cards[i].value];
                playerTotals[playerNum] = playerNum + cardValue;
            }

            currentRound.status = 'dealing';
            currentRound.cards = cards.map((card, i) => ({
                player: 8 + i,
                card: { value: card.value, suit: card.suit },
                total: playerTotals[8 + i]
            }));
            await currentRound.save();
            
            broadcast({
                type: 'cardsDealt',
                roundNumber: currentRound.roundNumber,
                cards: currentRound.cards
            });

            setTimeout(async () => {
                await determineWinner(playerTotals, cards);
            }, 5000);
        }, 30000);
    } catch (error) {
        console.error('Error in game round:', error);
        setTimeout(startNewRound, 5000);
    }
}

async function determineWinner(playerTotals, dealtCards) {
    try {
        let maxTotal = -1;
        let winners = [];
        for (const [playerNum, total] of Object.entries(playerTotals)) {
            if (total > maxTotal) {
                maxTotal = total;
                winners = [parseInt(playerNum)];
            } else if (total === maxTotal) {
                winners.push(parseInt(playerNum));
            }
        }

        if (winners.length > 1) {
            await reDealForTied(winners);
            return;
        }

        currentRound.status = 'result';
        currentRound.winner = winners[0];
        currentRound.resultTime = new Date();
        console.log(`Round ${currentRound.roundNumber} winner: Player ${winners[0]}`);
        console.log('Player Totals:', playerTotals);
        await currentRound.save();

        await processBets(currentRound._id, winners[0]);

        broadcast({
            type: 'roundResult',
            roundNumber: currentRound.roundNumber,
            winner: winners[0],
            totals: playerTotals,
            cards: dealtCards.map((card, i) => ({
                player: 8 + i,
                card: { value: card.value, suit: card.suit },
                total: playerTotals[8 + i]
            })),
            resultTime: currentRound.resultTime
        });

        setTimeout(startNewRound, 10000);
    } catch (error) {
        console.error('Error determining winner:', error);
        broadcast({
            type: 'error',
            message: 'Error determining winner'
        });
        setTimeout(startNewRound, 5000);
    }
}

async function reDealForTied(tiedPlayers) {
    try {
        broadcast({
            type: 'tieDetected',
            roundNumber: currentRound.roundNumber,
            tiedPlayers
        });

        const newCards = deck.splice(0, tiedPlayers.length);
        const newTotals = {};
        for (let i = 0; i < tiedPlayers.length; i++) {
            const playerNum = tiedPlayers[i];
            const cardValue = cardValues[newCards[i].value];
            newTotals[playerNum] = playerNum + cardValue;
        }

        broadcast({
            type: 'reDealCards',
            roundNumber: currentRound.roundNumber,
            cards: newCards.map((card, i) => ({
                player: tiedPlayers[i],
                card: { value: card.value, suit: card.suit },
                total: newTotals[tiedPlayers[i]]
            }))
        });

        setTimeout(async () => {
            let maxNewTotal = -1;
            let newWinners = [];
            for (const [playerNum, total] of Object.entries(newTotals)) {
                if (total > maxNewTotal) {
                    maxNewTotal = total;
                    newWinners = [parseInt(playerNum)];
                } else if (total === maxNewTotal) {
                    newWinners.push(parseInt(playerNum));
                }
            }

            if (newWinners.length > 1) {
                await reDealForTied(newWinners);
                return;
            }

            currentRound.status = 'result';
            currentRound.winner = newWinners[0];
            currentRound.resultTime = new Date();
            await currentRound.save();

            await processBets(currentRound._id, newWinners[0]);

            broadcast({
                type: 'roundResult',
                roundNumber: currentRound.roundNumber,
                winner: newWinners[0],
                totals: newTotals,
                cards: newCards.map((card, i) => ({
                    player: tiedPlayers[i],
                    card: { value: card.value, suit: card.suit },
                    total: newTotals[tiedPlayers[i]]
                })),
                resultTime: currentRound.resultTime
            });

            setTimeout(startNewRound, 10000);
        }, 5000);
    } catch (error) {
        console.error('Error in re-deal:', error);
        broadcast({
            type: 'error',
            message: 'Error in re-deal'
        });
        setTimeout(startNewRound, 5000);
    }
}

async function processBets(roundId, winningPlayer) {
    console.log(`Processing bets for round ${roundId}`);
    try {
        const bets = await Bet.find({status:"pending"});
        console.log("bets",bets.length)
        for (const bet of bets) {
            if (bet.selectedPlayer === winningPlayer) {
                bet.payout = bet.amount * 2;
                bet.status = 'won';
                await User.findByIdAndUpdate(bet.userId, { $inc: { balance: bet.payout } });
            } else {
                bet.payout = 0;
                bet.status = 'lost';
            }
            await bet.save();
        }
    } catch (error) {
        console.error('Error processing bets:', error);
    }
}

function broadcast(message) {
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
        }
    });
}

app.use("/api/bets", betRoutes);
app.use("/api/user", userRoutes);

app.get('/api/current-round', async (req, res) => {
    try {
        const round = await GameRound.findOne().sort({ createdAt: -1 });
        res.json(round);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.get('/api/user/balance/:userId', async (req, res) => {
    try {
        const user = await User.findById(req.params.userId).select('balance');
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json({ balance: user.balance });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.get('/api/my_bet_history/:userId', async (req, res) => {
    
    try {
        const bets = await Bet.find({ userId: req.params.userId }).sort({ createdAt: -1 }).limit(10);
        if (!bets || bets.length === 0) {
            return res.status(404).json({ error: 'No bets found for this user' });
        }
        res.json({ bets });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.get('/api/game_round_history/:userId', async (req, res) => {
    
    try {
        const gamerounds = await GameRound.find().sort({ createdAt: -1 }).limit(10);
        if (!gamerounds || gamerounds.length === 0) {
            return res.status(404).json({ error: 'No gamerounds found for this user' });
        }
        res.json({ gamerounds });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
    startNewRound();
    server.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
    });
}).catch((error) => {
    console.error('Failed to connect to database:', error);
});