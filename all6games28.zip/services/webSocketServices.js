const { startNewRound: startLucky7 } = require('../games/lucky7/gameLogic');
const { startNewRound: start32Card } = require('../games/32card/gameLogic');
const { startNewRound: startTeenPatii } = require('../games/teenpatti/gameLogic');
const { startNewRound: startDragonTiger } = require('../games/dragontiger/gameLogic');
const { startNewRound: startAndarBaharRound } = require('../games/andar_bahar/gameLogic');
const { startNewRound: startMuflis } = require('../games/muflis/gameLogic');

const { setupWebSocket: setupLucky7WS } = require('../games/lucky7/websocketHandler');
const { setupWebSocket: setup32CardWS } = require('../games/32card/websocketHandler');
const { setupWebSocket: setupDragonTigerWS } = require('../games/dragontiger/websocketHandler');
const { setupWebSocket: setupTeenPatiiWS } = require('../games/teenpatti/websocketHandler');
const { setupWebSocket: setupAndarBaharWebSocket } = require('../games/andar_bahar/websocketHandler');
const { setupWebSocket: setupMuflisWS } = require('../games/muflis/websocketHandler');

function setupWebSocketGames(wss) {
    setupLucky7WS(wss, 'lucky7');
    setup32CardWS(wss, '32card');
    setupDragonTigerWS(wss, 'dragontiger');
    setupTeenPatiiWS(wss, 'teenpatti');
    setupAndarBaharWebSocket(wss, 'andarbahar');
    setupMuflisWS(wss, 'muflis');

    startLucky7(wss);
    start32Card(wss);
    startDragonTiger(wss);
    startAndarBaharRound(wss);
    startTeenPatii(wss);
    startMuflis(wss);
}

module.exports = setupWebSocketGames;
