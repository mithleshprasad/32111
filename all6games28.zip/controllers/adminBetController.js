const User = require('../models/User');

// Bet Models
const Card32Bet = require('../games/32card/models/Bet');
const DragonTigerBet = require('../games/dragontiger/models/Bet');
const AndarBaharBet = require('../games/andar_bahar/models/Bet');
const TeenPattiBet = require('../games/teenpatti/models/Bet');
const Lucky7Bet = require('../games/lucky7/models/LuckyBet');
const MuflisBet = require('../games/muflis/models/Bet');

// GameRound Models (optional - not used here)
const Card32GameRound = require('../games/32card/models/GameRound');
const DragonTigerGameRound = require('../games/dragontiger/models/GameRound');
const AndarBaharGameRound = require('../games/andar_bahar/models/GameRound');
const TeenPattiGameRound = require('../games/teenpatti/models/GameRound');
const Lucky7GameRound = require('../games/lucky7/models/LuckyGameRound');
const MuflisGameRound = require('../games/muflis/models/GameRound');

/**
 * API Controller: Get all bets for a specific game (with pagination)
 */
exports.getAllBetsForGame = async (req, res) => {
  const { game } = req.params;
  const { userId, user_type } = req.body;

  if (!userId) {
    return res.status(400).json({ message: 'User ID  are required' });
  }

  // if (user_type !== 'admin') {
  //   return res.status(400).json({ message: 'Invalid user type' });
  // }


  try {
    const bets = await fetchBetsByGame(game, userId);
    res.status(200).json(bets);
  } catch (error) {
    console.error(`Error fetching bets for ${game}:`, error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};


/**
 * Service function to get all bets with pagination and optimization
 */
async function fetchBetsByGame(game, userId) {
  if (!userId) throw new Error('User ID is required');
  // if (user_type !== 'admin') throw new Error('Unauthorized: Only admin can access this');

  const validGames = ['32card', 'dragontiger', 'andarbahar', 'teenpatti', 'lucky7', 'muflis'];
  if (!validGames.includes(game)) {
    throw new Error('Invalid game type');
  }

  const user = await User.findById(userId);
  if (!user) throw new Error('Admin user not found');

  const gameModels = {
    '32card': Card32Bet,
    'dragontiger': DragonTigerBet,
    'andarbahar': AndarBaharBet,
    'teenpatti': TeenPattiBet,
    'lucky7': Lucky7Bet,
    'muflis': MuflisBet,
  };

  const BetModel = gameModels[game];
  if (!BetModel) throw new Error('Bet model not found');

  const bets = await BetModel.find({})
    .populate('userId', 'name email')
    .sort({ createdAt: -1 }) // Optional: newest first
    .lean();

  return {
    game,
    total: bets.length,
    bets
  };
}


/**
 * API Controller: Get combined statistics for all games
 */
exports.getGamesStats = async (req, res) => {
  const { userId, startDate, endDate, status, betType } = req.query;

  try {
    const stats = await fetchAllGamesStats({
      userId,
      startDate,
      endDate,
      status,
      betType
    });
    res.status(200).json(stats);
  } catch (error) {
    console.error('Error fetching combined game stats:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};

/**
 * Service function to get combined statistics for all games
 */
async function fetchAllGamesStats(filters = {}) {
  const { userId, startDate, endDate, status, betType } = filters;

  // Define all game models
  const gameModels = {
    '32card': { Bet: Card32Bet, GameRound: Card32GameRound },
    'dragontiger': { Bet: DragonTigerBet, GameRound: DragonTigerGameRound },
    'andarbahar': { Bet: AndarBaharBet, GameRound: AndarBaharGameRound },
    'teenpatti': { Bet: TeenPattiBet, GameRound: TeenPattiGameRound },
    'lucky7': { Bet: Lucky7Bet, GameRound: Lucky7GameRound },
    'muflis': { Bet: MuflisBet, GameRound: MuflisGameRound },
  };

  // Build base query for bets
  const betQuery = {};
  if (userId) betQuery.userId = userId;
  if (status) betQuery.status = status;
  if (betType) betQuery.betType = betType;
  if (startDate || endDate) {
    betQuery.createdAt = {};
    if (startDate) betQuery.createdAt.$gte = new Date(startDate);
    if (endDate) betQuery.createdAt.$lte = new Date(endDate);
  }

  // Build base query for rounds
  const roundQuery = {};
  if (startDate || endDate) {
    roundQuery.createdAt = {};
    if (startDate) roundQuery.createdAt.$gte = new Date(startDate);
    if (endDate) roundQuery.createdAt.$lte = new Date(endDate);
  }

  // Process all games in parallel
  const gameStats = await Promise.all(
    Object.entries(gameModels).map(async ([gameName, { Bet, GameRound }]) => {
      const [bets, rounds] = await Promise.all([
        Bet.find(betQuery)
          .populate('userId', 'name email')
          .sort({ createdAt: -1 })
          .lean(),
        GameRound.find(roundQuery)
          .sort({ createdAt: -1 })
          .lean()
      ]);

      const totalBets = bets.length;
      const totalRounds = rounds.length;
      const totalBetAmount = bets.reduce((sum, bet) => sum + bet.amount, 0);
      const totalPayout = bets.reduce((sum, bet) => sum + (bet.payout || 0), 0);

      return {
        game: gameName,
        summary: {
          totalBets,
          totalRounds,
          totalBetAmount,
          totalPayout,
          netProfit: totalBetAmount - totalPayout
        },
        betStats: {
          byStatus: bets.reduce((acc, bet) => {
            acc[bet.status] = (acc[bet.status] || 0) + 1;
            return acc;
          }, {}),
          byType: bets.reduce((acc, bet) => {
            acc[bet.betType] = (acc[bet.betType] || 0) + 1;
            return acc;
          }, {})
        },
        roundStats: {
          byStatus: rounds.reduce((acc, round) => {
            acc[round.status] = (acc[round.status] || 0) + 1;
            return acc;
          }, {})
        }
      };
    })
  );

  // Calculate combined totals
  const combinedSummary = gameStats.reduce((acc, game) => {
    acc.totalBets += game.summary.totalBets;
    acc.totalRounds += game.summary.totalRounds;
    acc.totalBetAmount += game.summary.totalBetAmount;
    acc.totalPayout += game.summary.totalPayout;
    acc.netProfit += game.summary.netProfit;
    return acc;
  }, {
    totalBets: 0,
    totalRounds: 0,
    totalBetAmount: 0,
    totalPayout: 0,
    netProfit: 0
  });

  return {
    combinedSummary,
    games: gameStats,
    // Optional: include recent activity across all games
    recentBets: (await Promise.all(
      Object.values(gameModels).map(model => 
        model.Bet.find(betQuery)
          .populate('userId', 'name email')
          .sort({ createdAt: -1 })
          .limit(5)
          .lean()
      )
    )).flat().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 10),
    recentRounds: (await Promise.all(
      Object.values(gameModels).map(model => 
        model.GameRound.find(roundQuery)
          .sort({ createdAt: -1 })
          .limit(5)
          .lean()
      )
    )).flat().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 10)
  };
}