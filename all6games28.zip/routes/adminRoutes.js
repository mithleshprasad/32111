// routes/adminRoutes.js
const express = require('express');
const router = express.Router();
// const adminController = require('../controllers/adminController');
const adminBetController = require('../controllers/adminBetController');
const adminGameRoundController = require('../controllers/adminGameRoundController');
// const authMiddleware = require('../middleware/auth'); 
// const roleMiddleware = require('../middleware/role'); 

// router.use(authMiddleware);
// router.use(roleMiddleware('admin')); 

// router.get('/users', adminController.getAllUsers);
// router.get('/users/active', adminController.getActiveUsers);
// router.get('/users/inactive', adminController.getInactiveUsers);
// router.get('/users/:userId', adminController.getUserDetails);
// router.put('/users/:userId/status', adminController.updateUserStatus);
// router.delete('/users/:userId', adminController.deleteUser);

router.post('/bets/:game', adminBetController.getAllBetsForGame);
router.get('/stats/:game', adminBetController.getGamesStats);
router.post('/game-rounds/:game', adminGameRoundController.getAllGameRoundsForGame);
// router.get('/bets', adminController.getAllBets);
// router.get('/bets/active', adminController.getActiveBets);
// router.get('/bets/inactive', adminController.getInactiveBets);
// router.get('/bets/:betId', adminController.getBetDetails);
// router.put('/bets/:betId/status', adminController.updateBetStatus);

// router.get('/game-rounds/active', adminController.getAllGameRounds);
// router.get('/game-rounds/inactive', adminController.getActiveGameRounds);
// router.get('/game-rounds', adminController.getInactiveGameRounds);
// router.get('/game-rounds/:roundId', adminController.getGameRoundDetails);
// router.put('/game-rounds/:roundId/status', adminController.updateGameRoundStatus);


// router.get('/stats', adminController.getSystemStats);

module.exports = router;
