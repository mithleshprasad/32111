const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const UserSchema = new mongoose.Schema({
  user_type: {
    type: String,
    default: "User"
  },
  username: {
    type: String,
    required: true
  },
  email: {
    type: String,
    lowercase: true,
    trim: true
  },
  Phone: {
    type: String,
    required: true,
    unique: true
  },
  Password: {
    type: String,
    required: true
  },
  balance: {
    type: Number,
    default: 0
  },
  hold_balance: {
    type: Number,
    default: 0
  },
  referral_code: String,
  verified: {
    type: String,
    enum: ['pending', 'verified', 'rejected'],
    default: 'pending'
  },
  tokens: [{
    token: {
      type: String,
      required: true
    }
  }],
  // Add other fields from your sample document
  avatar: String,
  user_status: {
    type: Number,
    default: 1
  },
  totalDeposit: {
    type: Number,
    default: 0
  },
  totalWithdrawl: {
    type: Number,
    default: 0
  },
  // ... add other fields as needed
}, { 
  timestamps: true,
  
  
});


const User = mongoose.model('User', UserSchema);
module.exports = User;