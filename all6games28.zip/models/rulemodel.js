  const mongoose = require('mongoose');
  
  const GameRuleSchema = new mongoose.Schema({
  gameName: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  game_slug: {
    type: String,
    required: true,
    unique: true,

  },
  instructions: {
    type: String,
    required: true
  },
  loadEvent: {
    type: Boolean,
    required: true,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});
module.exports = mongoose.model('gamerule', GameRuleSchema);