const mongoose = require('mongoose');

const BetSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  gameRoundId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'DragonTigerGameRound',
    required: true,
  },
  roundNumber: Number,
  amount: {
    type: Number,
    required: true,
    min: 10,
  },
  betType: {
    type: String,
    enum: ['dragon', 'tiger', 'tie'],
    required: true,
  },
  odds: {
    type: Number,
    required: true,
  },
  payout: {
    type: Number,
    default: 0,
  },
  status: {
    type: String,
    enum: ['pending', 'won', 'lost'],
    default: 'pending',
  },
}, { timestamps: true });

module.exports = mongoose.model('DragonTigerBet', BetSchema);