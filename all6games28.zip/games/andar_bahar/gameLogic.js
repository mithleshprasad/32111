const WebSocket = require('ws');
const { generateRandomCard, getCardValue } = require('./deck');
const GameRound = require('./models/GameRound');
const Bet = require('./models/Bet');
const User = require('../../models/User');

function broadcast(wss, message, game = 'andarbahar') {
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ ...message, game }));
        }
    });
}

async function processBets(roundId, winner) {
    try {
        const bets = await Bet.find({ gameRoundId: roundId, status: 'pending' });
        for (const bet of bets) {
            const user = await User.findById(bet.userId);
            if (!user) continue;

            if (bet.betType === winner) {
                const payout = bet.amount * (bet.odds + 1);
                bet.payout = payout;
                bet.status = 'won';
                user.balance += payout;
                console.log(`AndarBahar Bet ${bet._id} won: ${bet.betType}, payout: ${payout}`);
            } else {
                bet.payout = 0;
                bet.status = 'lost';
                console.log(`AndarBahar Bet ${bet._id} lost: ${bet.betType}`);
            }
            await bet.save();
            await user.save();
        }
    } catch (error) {
        console.error('Error processing AndarBahar bets:', error);
    }
}

async function startNewRound(wss) {
    try {
        const lastRound = await GameRound.findOne().sort({ roundNumber: -1 });
        const roundNumber = lastRound ? lastRound.roundNumber + 1 : 1;

        const currentRound = new GameRound({
            roundNumber,
            status: 'accepting_bets',
            bettingEndTime: new Date(Date.now() + 30000),
        });
        await currentRound.save();
        console.log(`Starting new AndarBahar round: ${roundNumber}`);

        broadcast(wss, {
            type: 'newRound',
            roundNumber: currentRound.roundNumber,
            status: currentRound.status,
            bettingEndTime: currentRound.bettingEndTime,
        });

        setTimeout(async () => {
            currentRound.status = 'no_more_bets';
            await currentRound.save();

            broadcast(wss, {
                type: 'bettingClosed',
                roundNumber: currentRound.roundNumber,
            });

            const jokerCard = generateRandomCard();
            currentRound.jokerCard = jokerCard;
            currentRound.status = 'joker_dealt';
            await currentRound.save();

            broadcast(wss, {
                type: 'jokerDealt',
                roundNumber: currentRound.roundNumber,
                jokerCard: currentRound.jokerCard,
                status: currentRound.status,
            });

            let currentSide = 'andar';
            let matchFound = false;
            let winner = null;

            const dealNextCard = async () => {
                if (matchFound) return;

                const card = generateRandomCard();
                const cardValue = getCardValue(card);
                const jokerValue = getCardValue(currentRound.jokerCard);
                currentRound.cards.push({ side: currentSide, card, value: cardValue });
                await currentRound.save();

                broadcast(wss, {
                    type: 'cardDealt',
                    roundNumber: currentRound.roundNumber,
                    cards: currentRound.cards,
                    currentSide,
                    jokerCard: currentRound.jokerCard,
                    status: 'joker_dealt',
                });

                if (cardValue === jokerValue) {
                    matchFound = true;
                    winner = currentSide;
                    currentRound.winner = winner;
                    currentRound.status = 'result';
                    currentRound.resultTime = new Date();
                    await currentRound.save();

                    await processBets(currentRound._id, winner);

                    broadcast(wss, {
                        type: 'roundResult',
                        roundNumber: currentRound.roundNumber,
                        winner,
                        cards: currentRound.cards,
                        jokerCard: currentRound.jokerCard,
                        resultTime: currentRound.resultTime,
                        status: currentRound.status,
                    });

                    setTimeout(() => startNewRound(wss), 10000);
                } else {
                    currentSide = currentSide === 'andar' ? 'bahar' : 'andar';
                    setTimeout(dealNextCard, 2000); 
                }
            };

            setTimeout(dealNextCard, 2000); 
        }, 30000);
    } catch (error) {
        console.error(`Error in AndarBahar round ${roundNumber}:`, error);
        broadcast(wss, {
            type: 'error',
            message: 'Error in game round',
        });
        setTimeout(() => startNewRound(wss), 5000);
    }
}

module.exports = { startNewRound, processBets, broadcast };